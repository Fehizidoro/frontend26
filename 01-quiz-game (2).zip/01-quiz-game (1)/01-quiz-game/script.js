// ELEMENTOS
const startScreen = document.getElementById("start-screen");
const quizScreen = document.getElementById("quiz-screen");
const resultScreen = document.getElementById("result-screen");

const startButton = document.getElementById("start-btn");
const restartButton = document.getElementById("restart-btn");

const questionText = document.getElementById("question-text");
const answersContainer = document.getElementById("answers-container");

const currentQuestionSpan = document.getElementById("current-question");
const totalQuestionsSpan = document.getElementById("total-questions");

const scoreSpan = document.getElementById("score");
const finalScoreSpan = document.getElementById("final-score");
const maxScoreSpan = document.getElementById("max-score");

const resultMessage = document.getElementById("result-message");
const progressBar = document.getElementById("progress");

// PERGUNTAS (15)
const quizQuestions = [
  {
    question: "Onde Tony Stark foi mantido preso?",
    answers: [
      { text: "Afeganistão", correct: true },
      { text: "Iraque", correct: false },
      { text: "Síria", correct: false },
      { text: "Paquistão", correct: false },
    ],
  },
  {
    question: "Quem controlava Loki?",
    answers: [
      { text: "Thanos", correct: true },
      { text: "Ultron", correct: false },
      { text: "Odin", correct: false },
      { text: "Ronan", correct: false },
    ],
  },
  {
    question: "Por que Thor foi banido?",
    answers: [
      { text: "Arrogância e guerra", correct: true },
      { text: "Perdeu batalha", correct: false },
      { text: "Traição", correct: false },
      { text: "Desobediência", correct: false },
    ],
  },
  {
    question: "Qual projeto criou o Capitão América?",
    answers: [
      { text: "Supersoldado", correct: true },
      { text: "Hydra", correct: false },
      { text: "Shield", correct: false },
      { text: "Vingador", correct: false },
    ],
  },
  {
    question: "O que Peter Quill roubou?",
    answers: [
      { text: "Orbe", correct: true },
      { text: "Arma", correct: false },
      { text: "Nave", correct: false },
      { text: "Joia", correct: false },
    ],
  },
  {
    question: "Quem criou Ultron?",
    answers: [
      { text: "Tony e Banner", correct: true },
      { text: "Tony", correct: false },
      { text: "Banner", correct: false },
      { text: "Shield", correct: false },
    ],
  },
  {
    question: "Vilão de De Volta ao Lar?",
    answers: [
      { text: "Abutre", correct: true },
      { text: "Electro", correct: false },
      { text: "Mistério", correct: false },
      { text: "Duende Verde", correct: false },
    ],
  },
  {
    question: "Metal de Wakanda?",
    answers: [
      { text: "Vibranium", correct: true },
      { text: "Adamantium", correct: false },
      { text: "Uru", correct: false },
      { text: "Carbonadium", correct: false },
    ],
  },
  {
    question: "Onde fica o Sanctum?",
    answers: [
      { text: "Nova York", correct: true },
      { text: "Londres", correct: false },
      { text: "Hong Kong", correct: false },
      { text: "Tóquio", correct: false },
    ],
  },
  {
    question: "Quem desaparece no estalo?",
    answers: [
      { text: "Homem-Aranha", correct: true },
      { text: "Thor", correct: false },
      { text: "Capitão América", correct: false },
      { text: "Homem de Ferro", correct: false },
    ],
  },
  {
    question: "Homem-Aranha fica do lado de quem?",
    answers: [
      { text: "Homem de Ferro", correct: true },
      { text: "Capitão América", correct: false },
      { text: "Neutro", correct: false },
      { text: "Ninguém", correct: false },
    ],
  },
  {
    question: "Filha do Homem-Formiga?",
    answers: [
      { text: "Cassie", correct: true },
      { text: "Hope", correct: false },
      { text: "Kate", correct: false },
      { text: "Wanda", correct: false },
    ],
  },
  {
    question: "Quem destrói o Mjolnir?",
    answers: [
      { text: "Hela", correct: true },
      { text: "Loki", correct: false },
      { text: "Thanos", correct: false },
      { text: "Odin", correct: false },
    ],
  },
  {
    question: "Nome da Capitã Marvel?",
    answers: [
      { text: "Carol Danvers", correct: true },
      { text: "Natasha", correct: false },
      { text: "Peggy", correct: false },
      { text: "Maria", correct: false },
    ],
  },
  {
    question: "Quem usa a manopla para salvar todos?",
    answers: [
      { text: "Hulk", correct: true },
      { text: "Thor", correct: false },
      { text: "Homem de Ferro", correct: false },
      { text: "Capitão América", correct: false },
    ],
  },
];

// ESTADO
let currentQuestionIndex = 0;
let score = 0;
let bloqueado = false;

totalQuestionsSpan.textContent = quizQuestions.length;
maxScoreSpan.textContent = quizQuestions.length;

// EVENTOS
startButton.onclick = startQuiz;
restartButton.onclick = startQuiz;

// INICIAR
function startQuiz() {
  currentQuestionIndex = 0;
  score = 0;
  scoreSpan.textContent = 0;

  startScreen.classList.remove("active");
  resultScreen.classList.remove("active");
  quizScreen.classList.add("active");

  showQuestion();
}

// MOSTRAR PERGUNTA
function showQuestion() {
  bloqueado = false;

  const q = quizQuestions[currentQuestionIndex];

  currentQuestionSpan.textContent = currentQuestionIndex + 1;

  const progress = (currentQuestionIndex / quizQuestions.length) * 100;
  progressBar.style.width = progress + "%";

  questionText.textContent = q.question;
  answersContainer.innerHTML = "";

  q.answers.forEach(ans => {
    const btn = document.createElement("button");
    btn.textContent = ans.text;
    btn.classList.add("answer-btn");

    btn.onclick = () => selectAnswer(btn, ans.correct);
    answersContainer.appendChild(btn);
  });
}

// SELECIONAR RESPOSTA
function selectAnswer(button, correct) {
  if (bloqueado) return;
  bloqueado = true;

  const botoes = answersContainer.children;

  for (let btn of botoes) {
    const texto = btn.textContent;

    const respostaCorreta = quizQuestions[currentQuestionIndex].answers.find(a => a.text === texto);

    if (respostaCorreta.correct) {
      btn.classList.add("correct");
    } else if (btn === button) {
      btn.classList.add("incorrect");
    }
  }

  if (correct) {
    score++;
    scoreSpan.textContent = score;
  }

  setTimeout(() => {
    currentQuestionIndex++;

    if (currentQuestionIndex < quizQuestions.length) {
      showQuestion();
    } else {
      showResults();
    }
  }, 1000);
}

// RESULTADO
function showResults() {
  quizScreen.classList.remove("active");
  resultScreen.classList.add("active");

  finalScoreSpan.textContent = score;

  const percent = (score / quizQuestions.length) * 100;

  if (percent >= 80) {
    resultMessage.textContent = "Mandou muito bem! Você é nível Vingador!";
  } else if (percent >= 50) {
    resultMessage.textContent =  "Foi bem! Mas dá pra melhorar!";
  } else {
    resultMessage.textContent =  "Continue treinando, herói!";
  }
}
# Sistema Web - Destino Certo Turismo

Projeto pratico de sistema web para agencia de viagens com cadastro de clientes, listagem de pacotes e controle de reservas.

## Tecnologias

- Python 3
- Flask
- SQLite
- Bootstrap 5 (via CDN)

## Funcionalidades implementadas

- Cadastro de clientes com validacao de campos obrigatorios e email unico
- Listagem de pacotes com destino, descricao, preco, duracao e vagas
- Registro de reservas com validacao de dados
- Controle de vagas por pacote (decrementa ao reservar)
- Exibicao das reservas realizadas
- Persistencia em banco de dados SQLite (`agencia.db`)

## Como executar

1. Crie um ambiente virtual:

```bash
python -m venv .venv
```

2. Ative o ambiente virtual:

- Windows (PowerShell):

```bash
.venv\Scripts\Activate.ps1
```

3. Instale as dependencias:

```bash
pip install -r requirements.txt
```

4. Inicie a aplicacao:

```bash
python app.py
```

5. Acesse no navegador:

`http://127.0.0.1:5000`

## Estrutura

- `app.py`: backend, rotas e regras de validacao
- `templates/`: paginas HTML do sistema
- `agencia.db`: banco de dados criado automaticamente ao rodar o app

-- Script SQL do sistema Destino Certo Turismo
-- Banco: SQLite (compativel com o app Flask em app.py)

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    telefone TEXT NOT NULL,
    criado_em TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pacotes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    destino TEXT NOT NULL,
    descricao TEXT NOT NULL,
    preco REAL NOT NULL CHECK(preco > 0),
    duracao_dias INTEGER NOT NULL CHECK(duracao_dias > 0),
    vagas INTEGER NOT NULL CHECK(vagas >= 0),
    imagem TEXT
);

CREATE TABLE IF NOT EXISTS reservas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER NOT NULL,
    pacote_id INTEGER NOT NULL,
    quantidade_pessoas INTEGER NOT NULL CHECK(quantidade_pessoas > 0),
    observacoes TEXT,
    criado_em TEXT NOT NULL,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    FOREIGN KEY (pacote_id) REFERENCES pacotes(id)
);

INSERT INTO pacotes (destino, descricao, preco, duracao_dias, vagas, imagem)
SELECT 'Gramado', 'Pacote romantico com hospedagem e city tour.', 1899.90, 5, 20, 'img/gramado.svg'
WHERE NOT EXISTS (SELECT 1 FROM pacotes WHERE lower(destino) = 'gramado');

INSERT INTO pacotes (destino, descricao, preco, duracao_dias, vagas, imagem)
SELECT 'Porto de Galinhas', 'Resort all inclusive com traslado.', 2790.00, 7, 15, 'img/porto-galinhas.svg'
WHERE NOT EXISTS (SELECT 1 FROM pacotes WHERE lower(destino) = 'porto de galinhas');

INSERT INTO pacotes (destino, descricao, preco, duracao_dias, vagas, imagem)
SELECT 'Buenos Aires', 'Experiencia cultural com passeios guiados.', 2450.50, 6, 18, 'img/buenos-aires.svg'
WHERE NOT EXISTS (SELECT 1 FROM pacotes WHERE lower(destino) = 'buenos aires');

INSERT INTO pacotes (destino, descricao, preco, duracao_dias, vagas, imagem)
SELECT 'Jericoacoara', 'Aventura e praias paradisicas.', 3150.00, 8, 12, 'img/jericoacoara.svg'
WHERE NOT EXISTS (SELECT 1 FROM pacotes WHERE lower(destino) = 'jericoacoara');

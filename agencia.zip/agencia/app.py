from datetime import datetime
import sqlite3
from pathlib import Path

from flask import Flask, flash, g, redirect, render_template, request, url_for


BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "agencia.db"

app = Flask(__name__)
app.config["SECRET_KEY"] = "destino-certo-secret-key"


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    cursor = db.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            telefone TEXT NOT NULL,
            criado_em TEXT NOT NULL
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS pacotes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            destino TEXT NOT NULL,
            descricao TEXT NOT NULL,
            preco REAL NOT NULL CHECK(preco > 0),
            duracao_dias INTEGER NOT NULL CHECK(duracao_dias > 0),
            vagas INTEGER NOT NULL CHECK(vagas >= 0),
            imagem TEXT
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS reservas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER NOT NULL,
            pacote_id INTEGER NOT NULL,
            quantidade_pessoas INTEGER NOT NULL CHECK(quantidade_pessoas > 0),
            observacoes TEXT,
            criado_em TEXT NOT NULL,
            FOREIGN KEY (cliente_id) REFERENCES clientes(id),
            FOREIGN KEY (pacote_id) REFERENCES pacotes(id)
        )
        """
    )

    # Migra base antiga que ainda nao possui coluna de imagem.
    colunas_pacotes = [linha[1] for linha in cursor.execute("PRAGMA table_info(pacotes)").fetchall()]
    if "imagem" not in colunas_pacotes:
        cursor.execute("ALTER TABLE pacotes ADD COLUMN imagem TEXT")

    cursor.execute("SELECT COUNT(*) FROM pacotes")
    count = cursor.fetchone()[0]
    if count == 0:
        pacotes_iniciais = [
            (
                "Gramado",
                "Pacote romantico com hospedagem e city tour.",
                1899.90,
                5,
                20,
                "img/gramado.svg",
            ),
            (
                "Porto de Galinhas",
                "Resort all inclusive com traslado.",
                2790.00,
                7,
                15,
                "img/porto-galinhas.svg",
            ),
            (
                "Buenos Aires",
                "Experiencia cultural com passeios guiados.",
                2450.50,
                6,
                18,
                "img/buenos-aires.svg",
            ),
            (
                "Jericoacoara",
                "Aventura e praias paradisicas.",
                3150.00,
                8,
                12,
                "img/jericoacoara.svg",
            ),
        ]
        cursor.executemany(
            """
            INSERT INTO pacotes (destino, descricao, preco, duracao_dias, vagas, imagem)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            pacotes_iniciais,
        )
    else:
        # Preenche imagens em bases existentes sem alterar demais dados.
        cursor.execute(
            "UPDATE pacotes SET imagem = ? WHERE lower(destino) LIKE ? AND (imagem IS NULL OR imagem = '')",
            ("img/gramado.svg", "%gramado%"),
        )
        cursor.execute(
            "UPDATE pacotes SET imagem = ? WHERE lower(destino) LIKE ? AND (imagem IS NULL OR imagem = '')",
            ("img/porto-galinhas.svg", "%porto%"),
        )
        cursor.execute(
            "UPDATE pacotes SET imagem = ? WHERE lower(destino) LIKE ? AND (imagem IS NULL OR imagem = '')",
            ("img/buenos-aires.svg", "%buenos%"),
        )
        cursor.execute(
            "UPDATE pacotes SET imagem = ? WHERE lower(destino) LIKE ? AND (imagem IS NULL OR imagem = '')",
            ("img/jericoacoara.svg", "%jericoacoara%"),
        )

    db.commit()
    db.close()


# Garante criacao/migracao do banco mesmo com "flask run"
# (sem depender do bloco __main__).
init_db()


@app.route("/")
def index():
    db = get_db()
    total_clientes = db.execute("SELECT COUNT(*) AS total FROM clientes").fetchone()["total"]
    total_pacotes = db.execute("SELECT COUNT(*) AS total FROM pacotes").fetchone()["total"]
    total_reservas = db.execute("SELECT COUNT(*) AS total FROM reservas").fetchone()["total"]

    destaques = db.execute(
        """
        SELECT destino, descricao, preco, imagem
        FROM pacotes
        ORDER BY preco DESC
        LIMIT 3
        """
    ).fetchall()

    return render_template(
        "index.html",
        total_clientes=total_clientes,
        total_pacotes=total_pacotes,
        total_reservas=total_reservas,
        destaques=destaques,
    )


@app.route("/clientes", methods=["GET", "POST"])
def clientes():
    db = get_db()

    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip().lower()
        telefone = request.form.get("telefone", "").strip()

        if not nome or not email or not telefone:
            flash("Todos os campos de cliente sao obrigatorios.", "danger")
            return redirect(url_for("clientes"))

        if "@" not in email or "." not in email:
            flash("Informe um email valido.", "danger")
            return redirect(url_for("clientes"))

        try:
            db.execute(
                """
                INSERT INTO clientes (nome, email, telefone, criado_em)
                VALUES (?, ?, ?, ?)
                """,
                (nome, email, telefone, datetime.now().isoformat()),
            )
            db.commit()
            flash("Cliente cadastrado com sucesso.", "success")
        except sqlite3.IntegrityError:
            flash("Ja existe um cliente com esse email.", "warning")

        return redirect(url_for("clientes"))

    clientes_cadastrados = db.execute(
        "SELECT id, nome, email, telefone, criado_em FROM clientes ORDER BY id DESC"
    ).fetchall()

    return render_template("clientes.html", clientes=clientes_cadastrados)


@app.route("/pacotes")
def pacotes():
    db = get_db()
    lista_pacotes = db.execute(
        """
        SELECT id, destino, descricao, preco, duracao_dias, vagas, imagem
        FROM pacotes
        ORDER BY destino
        """
    ).fetchall()
    return render_template("pacotes.html", pacotes=lista_pacotes)


@app.route("/reservas", methods=["GET", "POST"])
def reservas():
    db = get_db()

    if request.method == "POST":
        cliente_id = request.form.get("cliente_id", "").strip()
        pacote_id = request.form.get("pacote_id", "").strip()
        quantidade_pessoas = request.form.get("quantidade_pessoas", "").strip()
        observacoes = request.form.get("observacoes", "").strip()

        if not cliente_id or not pacote_id or not quantidade_pessoas:
            flash("Cliente, pacote e quantidade sao obrigatorios.", "danger")
            return redirect(url_for("reservas"))

        try:
            cliente_id_int = int(cliente_id)
            pacote_id_int = int(pacote_id)
            quantidade_int = int(quantidade_pessoas)
        except ValueError:
            flash("Dados invalidos para reserva.", "danger")
            return redirect(url_for("reservas"))

        if quantidade_int <= 0:
            flash("Quantidade de pessoas deve ser maior que zero.", "danger")
            return redirect(url_for("reservas"))

        cliente = db.execute("SELECT id FROM clientes WHERE id = ?", (cliente_id_int,)).fetchone()
        pacote = db.execute("SELECT id, vagas FROM pacotes WHERE id = ?", (pacote_id_int,)).fetchone()

        if cliente is None:
            flash("Cliente selecionado nao existe.", "danger")
            return redirect(url_for("reservas"))
        if pacote is None:
            flash("Pacote selecionado nao existe.", "danger")
            return redirect(url_for("reservas"))
        if quantidade_int > pacote["vagas"]:
            flash("Nao ha vagas suficientes nesse pacote.", "warning")
            return redirect(url_for("reservas"))

        db.execute(
            """
            INSERT INTO reservas (cliente_id, pacote_id, quantidade_pessoas, observacoes, criado_em)
            VALUES (?, ?, ?, ?, ?)
            """,
            (cliente_id_int, pacote_id_int, quantidade_int, observacoes, datetime.now().isoformat()),
        )
        db.execute("UPDATE pacotes SET vagas = vagas - ? WHERE id = ?", (quantidade_int, pacote_id_int))
        db.commit()

        flash("Reserva realizada com sucesso.", "success")
        return redirect(url_for("reservas"))

    clientes_cadastrados = db.execute("SELECT id, nome FROM clientes ORDER BY nome").fetchall()
    lista_pacotes = db.execute(
        "SELECT id, destino, preco, vagas FROM pacotes ORDER BY destino"
    ).fetchall()
    lista_reservas = db.execute(
        """
        SELECT
            r.id,
            c.nome AS cliente_nome,
            p.destino AS pacote_destino,
            r.quantidade_pessoas,
            p.preco,
            r.observacoes,
            r.criado_em
        FROM reservas r
        INNER JOIN clientes c ON c.id = r.cliente_id
        INNER JOIN pacotes p ON p.id = r.pacote_id
        ORDER BY r.id DESC
        """
    ).fetchall()

    return render_template(
        "reservas.html",
        clientes=clientes_cadastrados,
        pacotes=lista_pacotes,
        reservas=lista_reservas,
    )


if __name__ == "__main__":
    app.run(debug=True)

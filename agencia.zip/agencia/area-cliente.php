<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim((string) ($_POST['nome'] ?? ''));
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $telefone = trim((string) ($_POST['telefone'] ?? ''));
    $pacoteId = (int) ($_POST['pacote_id'] ?? 0);
    $qtd = (int) ($_POST['quantidade_pessoas'] ?? 0);
    $obs = trim((string) ($_POST['observacoes'] ?? ''));

    if ($nome === '' || $email === '' || $telefone === '' || $pacoteId <= 0 || $qtd <= 0) {
        flash('danger', 'Preencha os dados obrigatorios para solicitar a reserva.');
        header('Location: area-cliente.php');
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash('danger', 'Informe um email valido.');
        header('Location: area-cliente.php');
        exit;
    }

    $pacoteStmt = $pdo->prepare("SELECT id, vagas FROM pacotes WHERE id = ?");
    $pacoteStmt->execute([$pacoteId]);
    $pacote = $pacoteStmt->fetch();
    if (!$pacote) {
        flash('danger', 'Pacote selecionado nao encontrado.');
        header('Location: area-cliente.php');
        exit;
    }
    if ($qtd > (int) $pacote['vagas']) {
        flash('warning', 'Nao ha vagas suficientes para essa quantidade de pessoas.');
        header('Location: area-cliente.php');
        exit;
    }

    $buscaCliente = $pdo->prepare("SELECT id FROM clientes WHERE lower(email) = lower(?) LIMIT 1");
    $buscaCliente->execute([$email]);
    $cliente = $buscaCliente->fetch();
    $clienteId = 0;

    if ($cliente) {
        $clienteId = (int) $cliente['id'];
    } else {
        $insCliente = $pdo->prepare("INSERT INTO clientes (nome, email, telefone, criado_em) VALUES (?, ?, ?, ?)");
        $insCliente->execute([$nome, $email, $telefone, date('c')]);
        $clienteId = (int) $pdo->lastInsertId();
    }

    $pdo->beginTransaction();
    try {
        $insReserva = $pdo->prepare(
            "INSERT INTO reservas (cliente_id, pacote_id, quantidade_pessoas, observacoes, criado_em)
             VALUES (?, ?, ?, ?, ?)"
        );
        $insReserva->execute([$clienteId, $pacoteId, $qtd, $obs, date('c')]);

        $updVagas = $pdo->prepare("UPDATE pacotes SET vagas = vagas - ? WHERE id = ?");
        $updVagas->execute([$qtd, $pacoteId]);
        $pdo->commit();
        flash('success', 'Solicitacao enviada com sucesso. Nossa equipe entrara em contato.');
    } catch (Throwable $e) {
        $pdo->rollBack();
        flash('danger', 'Nao foi possivel concluir sua solicitacao agora.');
    }

    header('Location: area-cliente.php');
    exit;
}

$pacotes = $pdo->query("SELECT id, destino, descricao, preco, duracao_dias, vagas, imagem FROM pacotes ORDER BY destino")->fetchAll();
$pacoteSelecionado = (int) ($_GET['pacote_id'] ?? 0);
$ultimasReservas = $pdo->query(
    "SELECT c.nome AS cliente_nome, p.destino AS pacote_destino, r.quantidade_pessoas, r.criado_em
     FROM reservas r
     INNER JOIN clientes c ON c.id = r.cliente_id
     INNER JOIN pacotes p ON p.id = r.pacote_id
     ORDER BY r.id DESC
     LIMIT 6"
)->fetchAll();
$flashes = consume_flash();

$pageTitle = 'Área do Cliente - Destino Certo Turismo';
$activeNav = 'area-cliente';
$navMode = 'client';
require __DIR__ . '/partials/header.php';
?>
    <?php foreach ($flashes as $msg): ?><div class="alert alert-<?= h($msg['type']) ?>"><?= h($msg['message']) ?></div><?php endforeach; ?>

    <section class="hero-home mb-4 rounded-4 shadow-sm p-4 p-md-5">
        <div class="row align-items-center g-3">
            <div class="col-lg-8">
                <span class="hero-badge mb-3">Portal exclusivo para clientes</span>
                <h1 class="display-6 fw-bold mb-2">Escolha seu destino e solicite sua reserva</h1>
                <p class="mb-0">Nesta area voce visualiza pacotes e faz solicitacoes sem acesso as telas de administracao.</p>
            </div>
        </div>
    </section>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex flex-wrap justify-content-between gap-2 mb-3">
                        <h3 class="card-title mb-0">Destinos disponiveis</h3>
                        <input type="text" class="form-control filtro-pacotes" id="filtro-pacotes" placeholder="Buscar destino...">
                    </div>
                    <div class="row g-3" id="lista-pacotes">
                        <?php foreach ($pacotes as $pacote): ?>
                            <div class="col-md-6 pacote-item" data-destino="<?= h(strtolower((string) $pacote['destino'])) ?>">
                                <div class="card pacote-card h-100">
                                    <a class="text-decoration-none text-reset" href="destino.php?id=<?= (int) $pacote['id'] ?>">
                                        <img src="<?= h($pacote['imagem'] ?: 'static/img/default.svg') ?>" class="card-img-top pacote-img" alt="Imagem de <?= h($pacote['destino']) ?>" onerror="this.onerror=null;this.src='static/img/default.svg';">
                                    </a>
                                    <div class="card-body">
                                        <a class="text-decoration-none text-reset" href="destino.php?id=<?= (int) $pacote['id'] ?>"><h5 class="card-title"><?= h($pacote['destino']) ?></h5></a>
                                        <p class="card-text"><?= h($pacote['descricao']) ?></p>
                                        <p class="mb-1"><strong>Duracao:</strong> <?= (int) $pacote['duracao_dias'] ?> dias</p>
                                        <p class="mb-1"><strong>Vagas:</strong> <?= (int) $pacote['vagas'] ?></p>
                                        <p class="mb-2 text-success fw-semibold">R$ <?= number_format((float) $pacote['preco'], 2, ',', '.') ?></p>
                                        <a class="btn btn-sm btn-outline-primary" href="destino.php?id=<?= (int) $pacote['id'] ?>">Ver detalhes</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <p id="sem-resultado" class="mt-3 mb-0 d-none">Nenhum destino encontrado.</p>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <h4 class="card-title mb-3">Solicitar reserva</h4>
                    <form method="post">
                        <div class="mb-2"><label class="form-label">Nome</label><input type="text" class="form-control" name="nome" required></div>
                        <div class="mb-2"><label class="form-label">Email</label><input type="email" class="form-control" name="email" required></div>
                        <div class="mb-2"><label class="form-label">Telefone</label><input type="text" class="form-control" name="telefone" required></div>
                        <div class="mb-2">
                            <label class="form-label">Destino</label>
                            <select class="form-select" id="pacote_id" name="pacote_id" required>
                                <option value="">Selecione...</option>
                                <?php foreach ($pacotes as $pacote): ?>
                                    <option value="<?= (int) $pacote['id'] ?>" data-preco="<?= (float) $pacote['preco'] ?>" <?= $pacoteSelecionado === (int) $pacote['id'] ? 'selected' : '' ?>>
                                        <?= h($pacote['destino']) ?> - R$ <?= number_format((float) $pacote['preco'], 2, ',', '.') ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-2"><label class="form-label">Quantidade de pessoas</label><input type="number" id="quantidade_pessoas" class="form-control" name="quantidade_pessoas" min="1" required></div>
                        <div class="mb-2"><label class="form-label">Observacoes</label><textarea class="form-control" name="observacoes" rows="2"></textarea></div>
                        <div class="resumo-reserva mb-3"><strong>Valor estimado:</strong> <span id="valor-estimado">R$ 0,00</span></div>
                        <button class="btn btn-primary w-100" type="submit">Enviar solicitacao</button>
                    </form>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title mb-3">Ultimas reservas</h5>
                    <?php if (!$ultimasReservas): ?>
                        <p class="mb-0 text-muted">Sem reservas recentes.</p>
                    <?php else: ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($ultimasReservas as $item): ?>
                                <li class="list-group-item px-0">
                                    <strong><?= h($item['cliente_nome']) ?></strong><br>
                                    <small class="text-muted"><?= h($item['pacote_destino']) ?> • <?= (int) $item['quantidade_pessoas'] ?> pessoa(s)</small>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <section class="mt-4">
        <div class="row g-3">
            <div class="col-lg-7">
                <div class="card contact-card h-100">
                    <div class="card-body p-4">
                        <span class="section-chip">Atendimento ao cliente</span>
                        <h4 class="mt-2 mb-3">Canais oficiais de contato</h4>
                        <div class="contact-grid">
                            <div><strong>Telefone:</strong><br>(11) 4002-8922</div>
                            <div><strong>WhatsApp:</strong><br>(11) 98888-7788</div>
                            <div><strong>Email:</strong><br>contato@destinocerto.com.br</div>
                            <div><strong>Horario:</strong><br>Seg a Sex, 9h as 18h</div>
                        </div>
                        <a class="btn btn-success mt-3" href="https://wa.me/5511988887788?text=Ola%2C%20quero%20ajuda%20para%20reservar%20uma%20viagem." target="_blank" rel="noopener noreferrer">Conversar no chat</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="card contact-card h-100">
                    <div class="card-body p-4">
                        <span class="section-chip section-chip-dark">Visite nossa loja</span>
                        <h4 class="mt-2 mb-3">Loja fisica</h4>
                        <p class="mb-2"><strong>Endereco:</strong><br>Av. Paulista, 1578 - Bela Vista<br>Sao Paulo - SP, CEP 01310-200</p>
                        <p class="mb-3"><strong>Atendimento presencial:</strong><br>Seg a Sabado, 9h as 19h</p>
                        <a class="btn btn-outline-secondary" href="https://www.google.com/maps?q=Av.+Paulista,+1578,+Sao+Paulo" target="_blank" rel="noopener noreferrer">Abrir localizacao</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php require __DIR__ . '/partials/footer.php'; ?>

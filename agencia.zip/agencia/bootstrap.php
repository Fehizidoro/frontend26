<?php
declare(strict_types=1);

session_start();

date_default_timezone_set('America/Sao_Paulo');

$dbFile = __DIR__ . DIRECTORY_SEPARATOR . 'agencia.sqlite';
$pdo = new PDO('sqlite:' . $dbFile);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

$pdo->exec('PRAGMA foreign_keys = ON');

$pdo->exec(
    "CREATE TABLE IF NOT EXISTS clientes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        telefone TEXT NOT NULL,
        criado_em TEXT NOT NULL
    )"
);

$pdo->exec(
    "CREATE TABLE IF NOT EXISTS pacotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        destino TEXT NOT NULL,
        descricao TEXT NOT NULL,
        preco REAL NOT NULL CHECK(preco > 0),
        duracao_dias INTEGER NOT NULL CHECK(duracao_dias > 0),
        vagas INTEGER NOT NULL CHECK(vagas >= 0),
        imagem TEXT
    )"
);

$pdo->exec(
    "CREATE TABLE IF NOT EXISTS reservas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cliente_id INTEGER NOT NULL,
        pacote_id INTEGER NOT NULL,
        quantidade_pessoas INTEGER NOT NULL CHECK(quantidade_pessoas > 0),
        observacoes TEXT,
        criado_em TEXT NOT NULL,
        FOREIGN KEY (cliente_id) REFERENCES clientes(id),
        FOREIGN KEY (pacote_id) REFERENCES pacotes(id)
    )"
);

$stmt = $pdo->prepare(
    "INSERT INTO pacotes (destino, descricao, preco, duracao_dias, vagas, imagem)
     VALUES (?, ?, ?, ?, ?, ?)"
);
$pacotesPadrao = [
    ['Gramado', 'Pacote romantico com hospedagem e city tour.', 1899.90, 5, 20, 'static/img/gramado.svg'],
    ['Porto de Galinhas', 'Resort all inclusive com traslado.', 2790.00, 7, 15, 'static/img/porto-galinhas.svg'],
    ['Buenos Aires', 'Experiencia cultural com passeios guiados.', 2450.50, 6, 18, 'static/img/buenos-aires.svg'],
    ['Jericoacoara', 'Aventura e praias paradisicas.', 3150.00, 8, 12, 'static/img/jericoacoara.svg'],
    ['Maceio', 'Praias urbanas, passeios de jangada e gastronomia regional.', 2090.00, 6, 22, 'static/img/maceio.svg'],
    ['Rio de Janeiro', 'Pacote com Cristo Redentor, Pao de Acucar e praias famosas.', 2590.00, 5, 20, 'static/img/rio-janeiro.svg'],
    ['Santiago', 'Roteiro cultural e enoturismo com opcional para neve.', 3390.00, 7, 16, 'static/img/santiago.svg'],
    ['Lisboa', 'City break europeu com passeios historicos e gastronomia.', 4990.00, 8, 14, 'static/img/lisboa.svg'],
];
foreach ($pacotesPadrao as $pacotePadrao) {
    [$destinoPadrao] = $pacotePadrao;
    $verifica = $pdo->prepare("SELECT id FROM pacotes WHERE lower(destino) = lower(?) LIMIT 1");
    $verifica->execute([$destinoPadrao]);
    if (!$verifica->fetch()) {
        $stmt->execute($pacotePadrao);
    }
}

$mapaImagens = [
    ['static/img/gramado.svg', '%gramado%'],
    ['static/img/porto-galinhas.svg', '%porto%'],
    ['static/img/buenos-aires.svg', '%buenos%'],
    ['static/img/jericoacoara.svg', '%jericoacoara%'],
    ['static/img/maceio.svg', '%maceio%'],
    ['static/img/rio-janeiro.svg', '%rio%'],
    ['static/img/santiago.svg', '%santiago%'],
    ['static/img/lisboa.svg', '%lisboa%'],
];
$updImagem = $pdo->prepare(
    "UPDATE pacotes
     SET imagem = ?
     WHERE lower(destino) LIKE ?"
);
foreach ($mapaImagens as [$img, $destinoLike]) {
    $updImagem->execute([$img, $destinoLike]);
}

$clientesPadrao = [
    ['Ana Paula Ribeiro', 'ana.ribeiro@email.com', '(11) 98811-1020'],
    ['Bruno Carvalho', 'bruno.carvalho@email.com', '(21) 97732-2091'],
    ['Camila Santos', 'camila.santos@email.com', '(31) 99120-3456'],
    ['Diego Almeida', 'diego.almeida@email.com', '(41) 99883-7210'],
    ['Fernanda Costa', 'fernanda.costa@email.com', '(51) 99654-1122'],
    ['Gustavo Lima', 'gustavo.lima@email.com', '(61) 99231-4508'],
    ['Helena Martins', 'helena.martins@email.com', '(71) 98119-3387'],
    ['Igor Souza', 'igor.souza@email.com', '(81) 99773-6601'],
    ['Julia Mendes', 'julia.mendes@email.com', '(85) 98942-5519'],
    ['Karina Rocha', 'karina.rocha@email.com', '(91) 99421-8800'],
];
$insCliente = $pdo->prepare(
    "INSERT INTO clientes (nome, email, telefone, criado_em)
     VALUES (?, ?, ?, ?)"
);
$buscaClienteEmail = $pdo->prepare("SELECT id FROM clientes WHERE lower(email) = lower(?) LIMIT 1");
foreach ($clientesPadrao as [$nomeCliente, $emailCliente, $telefoneCliente]) {
    $buscaClienteEmail->execute([$emailCliente]);
    if (!$buscaClienteEmail->fetch()) {
        $insCliente->execute([$nomeCliente, $emailCliente, $telefoneCliente, date('c')]);
    }
}

$totalReservasAtual = (int) $pdo->query("SELECT COUNT(*) FROM reservas")->fetchColumn();
if ($totalReservasAtual < 12) {
    $clientesIds = $pdo->query("SELECT id FROM clientes ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);
    $pacotesLista = $pdo->query("SELECT id, vagas FROM pacotes ORDER BY id")->fetchAll();
    $insReserva = $pdo->prepare(
        "INSERT INTO reservas (cliente_id, pacote_id, quantidade_pessoas, observacoes, criado_em)
         VALUES (?, ?, ?, ?, ?)"
    );
    $updVagas = $pdo->prepare("UPDATE pacotes SET vagas = vagas - ? WHERE id = ?");

    $observacoesPadrao = [
        'Preferencia por quarto duplo.',
        'Cliente solicitou passeio extra.',
        'Atendimento por indicacao de cliente antigo.',
        'Pagamento em duas parcelas.',
        'Solicitada opcao com traslado.',
    ];

    $pdo->beginTransaction();
    try {
        $clienteIndex = 0;
        $obsIndex = 0;
        foreach ($pacotesLista as $pacoteItem) {
            $pacoteId = (int) $pacoteItem['id'];
            $vagas = (int) $pacoteItem['vagas'];
            if ($vagas <= 0 || empty($clientesIds)) {
                continue;
            }
            $qtdPessoas = $vagas >= 2 ? 2 : 1;
            $clienteId = (int) $clientesIds[$clienteIndex % count($clientesIds)];
            $observacao = $observacoesPadrao[$obsIndex % count($observacoesPadrao)];
            $insReserva->execute([$clienteId, $pacoteId, $qtdPessoas, $observacao, date('c')]);
            $updVagas->execute([$qtdPessoas, $pacoteId]);
            $clienteIndex++;
            $obsIndex++;
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
    }
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function consume_flash(): array
{
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

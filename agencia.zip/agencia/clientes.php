<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim((string) ($_POST['nome'] ?? ''));
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $telefone = trim((string) ($_POST['telefone'] ?? ''));

    if ($nome === '' || $email === '' || $telefone === '') {
        flash('danger', 'Todos os campos sao obrigatorios.');
        header('Location: clientes.php');
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash('danger', 'Informe um email valido.');
        header('Location: clientes.php');
        exit;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO clientes (nome, email, telefone, criado_em) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nome, $email, $telefone, date('c')]);
        flash('success', 'Cliente cadastrado com sucesso.');
    } catch (PDOException $e) {
        flash('warning', 'Ja existe um cliente com esse email.');
    }
    header('Location: clientes.php');
    exit;
}

$clientes = $pdo->query("SELECT id, nome, email, telefone, criado_em FROM clientes ORDER BY id DESC")->fetchAll();
$totalClientes = count($clientes);
$clientesComEmailCorporativo = (int) $pdo->query("SELECT COUNT(*) FROM clientes WHERE email LIKE '%.com'")->fetchColumn();
$ultimoCliente = $clientes[0] ?? null;
$flashes = consume_flash();

$pageTitle = 'Clientes - Destino Certo Turismo';
$activeNav = 'clientes';
$navMode = 'admin';
require __DIR__ . '/partials/header.php';
?>
    <?php foreach ($flashes as $msg): ?><div class="alert alert-<?= h($msg['type']) ?>"><?= h($msg['message']) ?></div><?php endforeach; ?>
    <section class="page-head mb-4">
        <div class="d-flex flex-wrap justify-content-between align-items-end gap-2">
            <div>
                <span class="section-chip mb-2">Gestão de clientes</span>
                <h1 class="h3 fw-bold">Clientes</h1>
                <p class="text-muted mb-0">Cadastre, consulte e acompanhe a base de clientes com filtros rápidos.</p>
            </div>
            <div class="text-muted small">
                Total: <strong><?= $totalClientes ?></strong>
            </div>
        </div>
    </section>
    <section class="mb-3">
        <div class="row g-3">
            <div class="col-md-4">
                <div class="card dashboard-kpi"><div class="card-body">
                    <h5 class="card-title">Total de clientes</h5>
                    <p class="display-6 mb-0"><?= $totalClientes ?></p>
                </div></div>
            </div>
            <div class="col-md-4">
                <div class="card dashboard-kpi"><div class="card-body">
                    <h5 class="card-title">Emails .com</h5>
                    <p class="display-6 mb-0"><?= $clientesComEmailCorporativo ?></p>
                </div></div>
            </div>
            <div class="col-md-4">
                <div class="card dashboard-kpi"><div class="card-body">
                    <h5 class="card-title">Ultimo cadastro</h5>
                    <p class="mb-0 fw-semibold"><?= $ultimoCliente ? h($ultimoCliente['nome']) : '-' ?></p>
                    <small class="text-muted"><?= $ultimoCliente ? date('d/m/Y H:i', strtotime((string) $ultimoCliente['criado_em'])) : 'Sem registros' ?></small>
                </div></div>
            </div>
        </div>
    </section>

    <div class="row g-4">
        <div class="col-lg-4">
            <div class="card shadow-sm"><div class="card-body">
                <h4 class="card-title mb-3">Cadastro de cliente</h4>
                <form method="post">
                    <div class="mb-3"><label class="form-label">Nome</label><input type="text" class="form-control" name="nome" required></div>
                    <div class="mb-3"><label class="form-label">Email</label><input type="email" class="form-control" name="email" required></div>
                    <div class="mb-3"><label class="form-label">Telefone</label><input type="text" class="form-control" name="telefone" placeholder="(11) 99999-9999" required></div>
                    <button type="submit" class="btn btn-primary">Cadastrar</button>
                </form>
            </div></div>
        </div>
        <div class="col-lg-8">
            <div class="card shadow-sm"><div class="card-body">
                <div class="d-flex flex-wrap justify-content-between gap-2 mb-3">
                    <h4 class="card-title mb-0">Clientes cadastrados</h4>
                    <input type="text" class="form-control filtro-clientes" id="filtro-clientes" placeholder="Buscar por nome, email ou telefone...">
                </div>
                <?php if (!$clientes): ?>
                    <p class="mb-0">Nenhum cliente cadastrado.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped align-middle" id="tabela-clientes">
                            <thead><tr><th>ID</th><th>Nome</th><th>Email</th><th>Telefone</th><th>Cadastro</th></tr></thead>
                            <tbody id="lista-clientes">
                            <?php foreach ($clientes as $cliente): ?>
                                <tr class="cliente-item" data-busca="<?= h(strtolower($cliente['nome'] . ' ' . $cliente['email'] . ' ' . $cliente['telefone'])) ?>">
                                    <td><?= (int) $cliente['id'] ?></td>
                                    <td><?= h($cliente['nome']) ?></td>
                                    <td><?= h($cliente['email']) ?></td>
                                    <td><?= h($cliente['telefone']) ?></td>
                                    <td><?= date('d/m/Y H:i', strtotime((string) $cliente['criado_em'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <p id="clientes-sem-resultado" class="mt-3 mb-0 d-none">Nenhum cliente encontrado com esse filtro.</p>
                <?php endif; ?>
            </div></div>
        </div>
    </div>
<?php require __DIR__ . '/partials/footer.php'; ?>

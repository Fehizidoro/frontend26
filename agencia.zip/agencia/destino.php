<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

$pacoteId = (int) ($_GET['id'] ?? 0);
if ($pacoteId <= 0) {
    flash('warning', 'Destino nao encontrado.');
    header('Location: area-cliente.php');
    exit;
}

$stmt = $pdo->prepare(
    "SELECT id, destino, descricao, preco, duracao_dias, vagas, imagem
     FROM pacotes
     WHERE id = ?"
);
$stmt->execute([$pacoteId]);
$pacote = $stmt->fetch();

if (!$pacote) {
    flash('warning', 'Destino nao encontrado.');
    header('Location: area-cliente.php');
    exit;
}

$similares = $pdo->prepare(
    "SELECT id, destino, preco, imagem
     FROM pacotes
     WHERE id <> ?
     ORDER BY preco DESC
     LIMIT 3"
);
$similares->execute([$pacoteId]);
$outrosDestinos = $similares->fetchAll();

$pageTitle = h($pacote['destino']) . ' - Destino Certo Turismo';
$activeNav = 'destino';
$navMode = 'client';
require __DIR__ . '/partials/header.php';
?>
    <div class="card shadow-sm">
        <img src="<?= h($pacote['imagem'] ?: 'static/img/default.svg') ?>" class="card-img-top pacote-img" alt="Imagem de <?= h($pacote['destino']) ?>" onerror="this.onerror=null;this.src='static/img/default.svg';">
        <div class="card-body p-4">
            <div class="d-flex flex-wrap justify-content-between gap-2 align-items-start mb-2">
                <div>
                    <span class="section-chip">Destino em destaque</span>
                    <h1 class="h2 mt-2 mb-1"><?= h($pacote['destino']) ?></h1>
                    <p class="text-muted mb-0">Confira todos os detalhes da viagem antes de reservar.</p>
                </div>
                <div class="text-end">
                    <div class="fs-4 fw-bold text-success">R$ <?= number_format((float) $pacote['preco'], 2, ',', '.') ?></div>
                    <small class="text-muted">por pessoa</small>
                </div>
            </div>

            <hr>

            <div class="row g-3 mb-3">
                <div class="col-md-4"><div class="resumo-reserva h-100"><strong>Duracao:</strong><br><?= (int) $pacote['duracao_dias'] ?> dias</div></div>
                <div class="col-md-4"><div class="resumo-reserva h-100"><strong>Vagas disponiveis:</strong><br><?= (int) $pacote['vagas'] ?></div></div>
                <div class="col-md-4"><div class="resumo-reserva h-100"><strong>Codigo do pacote:</strong><br>#<?= (int) $pacote['id'] ?></div></div>
            </div>

            <h5>Descricao da viagem</h5>
            <p class="mb-4"><?= h($pacote['descricao']) ?></p>

            <div class="d-flex flex-wrap gap-2">
                <a class="btn btn-primary" href="area-cliente.php?pacote_id=<?= (int) $pacote['id'] ?>">Quero solicitar esta viagem</a>
                <a class="btn btn-outline-secondary" href="area-cliente.php">Voltar para destinos</a>
            </div>
        </div>
    </div>

    <?php if ($outrosDestinos): ?>
        <section class="mt-4">
            <h4 class="mb-3">Outros destinos que podem interessar</h4>
            <div class="row g-3">
                <?php foreach ($outrosDestinos as $item): ?>
                    <div class="col-md-4">
                        <a class="text-decoration-none text-reset" href="destino.php?id=<?= (int) $item['id'] ?>">
                            <div class="card pacote-card h-100">
                                <img src="<?= h($item['imagem'] ?: 'static/img/default.svg') ?>" class="card-img-top pacote-img" alt="Imagem de <?= h($item['destino']) ?>" onerror="this.onerror=null;this.src='static/img/default.svg';">
                                <div class="card-body">
                                    <h5 class="card-title"><?= h($item['destino']) ?></h5>
                                    <p class="mb-0 text-success fw-semibold">R$ <?= number_format((float) $item['preco'], 2, ',', '.') ?></p>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>
<?php require __DIR__ . '/partials/footer.php'; ?>

<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

$totalClientes = (int) $pdo->query("SELECT COUNT(*) FROM clientes")->fetchColumn();
$totalPacotes = (int) $pdo->query("SELECT COUNT(*) FROM pacotes")->fetchColumn();
$totalReservas = (int) $pdo->query("SELECT COUNT(*) FROM reservas")->fetchColumn();
$destaques = $pdo->query("SELECT id, destino, descricao, preco, imagem FROM pacotes ORDER BY preco DESC LIMIT 3")->fetchAll();
$flashes = consume_flash();

$pageTitle = 'Destino Certo Turismo';
$activeNav = 'inicio';
$navMode = 'admin';
require __DIR__ . '/partials/header.php';
?>
    <?php foreach ($flashes as $msg): ?>
        <div class="alert alert-<?= h($msg['type']) ?>"><?= h($msg['message']) ?></div>
    <?php endforeach; ?>

    <section class="hero-home mb-4 rounded-4 shadow-sm p-4 p-md-5">
        <div class="row align-items-center g-4">
            <div class="col-lg-8">
                <span class="hero-badge mb-3">Painel premium • Amarelo & Azul</span>
                <h1 class="display-6 fw-bold mb-3">Destino Certo Turismo</h1>
                <p class="fs-5 mb-4">Gestão completa de clientes, pacotes e reservas com visual premium e fluxo simples para o dia a dia.</p>
                <div class="d-flex flex-wrap gap-2">
                    <a class="btn btn-light btn-lg" href="reservas.php">Registrar nova reserva</a>
                    <a class="btn btn-outline-light btn-lg" href="pacotes.php">Ver pacotes</a>
                </div>
            </div>
            <div class="col-lg-4 text-lg-end">
                <div class="hero-mini-card ms-lg-auto">
                    <p class="mb-1 small">Status do sistema</p>
                    <h4 class="mb-0">Online e operacional</h4>
                </div>
            </div>
        </div>
    </section>

    <section class="kpi-strip mb-4">
        <div class="row g-3">
            <div class="col-md-4"><div class="card shadow-sm dashboard-kpi"><div class="card-body"><h5 class="card-title">Clientes cadastrados</h5><p class="display-6 mb-0"><?= $totalClientes ?></p></div></div></div>
            <div class="col-md-4"><div class="card shadow-sm dashboard-kpi"><div class="card-body"><h5 class="card-title">Pacotes disponiveis</h5><p class="display-6 mb-0"><?= $totalPacotes ?></p></div></div></div>
            <div class="col-md-4"><div class="card shadow-sm dashboard-kpi"><div class="card-body"><h5 class="card-title">Reservas realizadas</h5><p class="display-6 mb-0"><?= $totalReservas ?></p></div></div></div>
        </div>
    </section>

    <section class="mt-4">
        <div class="section-head mb-3">
            <span class="section-chip">Destaques premium</span>
            <h3 class="mb-1">Destinos em destaque</h3>
            <p class="text-muted mb-0">Selecao especial com experiencias mais procuradas pelos clientes.</p>
        </div>
        <div class="row g-3">
            <?php foreach ($destaques as $pacote): ?>
                <div class="col-md-4">
                    <div class="card pacote-card h-100 shadow-sm">
                        <a class="text-decoration-none text-reset" href="destino.php?id=<?= (int) $pacote['id'] ?>">
                            <img src="<?= h($pacote['imagem'] ?: 'static/img/default.svg') ?>" class="card-img-top pacote-img" alt="Imagem de <?= h($pacote['destino']) ?>" onerror="this.onerror=null;this.src='static/img/default.svg';">
                        </a>
                        <div class="card-body">
                            <a class="text-decoration-none text-reset" href="destino.php?id=<?= (int) $pacote['id'] ?>"><h5 class="card-title"><?= h($pacote['destino']) ?></h5></a>
                            <p class="card-text"><?= h($pacote['descricao']) ?></p>
                            <a class="btn btn-sm btn-outline-primary mt-2" href="destino.php?id=<?= (int) $pacote['id'] ?>">Ver detalhes</a>
                        </div>
                        <div class="card-footer bg-white border-0 pt-0">
                            <span class="badge text-bg-success fs-6">A partir de R$ <?= number_format((float) $pacote['preco'], 2, ',', '.') ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="mt-4">
        <div class="row g-3">
            <div class="col-lg-4 order-1 order-lg-2">
                <div class="card cta-panel h-100">
                    <div class="card-body p-4 d-flex flex-column">
                        <span class="section-chip section-chip-dark">Oferta da semana</span>
                        <h4 class="mt-2 mb-3">Planeje sua proxima viagem hoje</h4>
                        <p class="text-muted">Concentre atendimento, pacotes e reservas em um fluxo unico e profissional.</p>
                        <ul class="cta-list mt-2 mb-4">
                            <li>Visual moderno e confiavel</li>
                            <li>Processos organizados</li>
                            <li>Mais agilidade no atendimento</li>
                        </ul>
                        <a class="btn btn-primary mt-auto" href="clientes.php">Cadastrar novo cliente</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 order-2 order-lg-1">
                <div class="card feature-panel h-100">
                    <div class="card-body p-4">
                        <span class="section-chip">Por que escolher a agencia</span>
                        <h4 class="mt-2 mb-3">Atendimento especializado com foco em experiencia completa</h4>
                        <div class="feature-grid">
                            <article>
                                <h6>Curadoria de destinos</h6>
                                <p>Selecionamos roteiros com melhor custo-beneficio e alta satisfacao de clientes.</p>
                            </article>
                            <article>
                                <h6>Suporte dedicado</h6>
                                <p>Equipe preparada para auxiliar antes, durante e depois da viagem.</p>
                            </article>
                            <article>
                                <h6>Reserva rapida e segura</h6>
                                <p>Processo simples para consultar disponibilidade e confirmar em minutos.</p>
                            </article>
                            <article>
                                <h6>Controle em tempo real</h6>
                                <p>Painel com dados de clientes, reservas e vagas atualizadas automaticamente.</p>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="mt-4">
        <div class="section-head mb-3">
            <span class="section-chip">Como funciona</span>
            <h3 class="mb-1">Planeje sua viagem em 3 passos</h3>
            <p class="text-muted mb-0">Fluxo simples para pesquisar, reservar e acompanhar cada atendimento.</p>
        </div>
        <div class="row g-3">
            <div class="col-md-4">
                <article class="card step-card h-100">
                    <div class="card-body p-4">
                        <span class="step-index">01</span>
                        <h5 class="mt-3">Explore os pacotes</h5>
                        <p class="mb-0 text-muted">Veja destinos, duracao, valores e disponibilidade em tempo real.</p>
                    </div>
                </article>
            </div>
            <div class="col-md-4">
                <article class="card step-card h-100">
                    <div class="card-body p-4">
                        <span class="step-index">02</span>
                        <h5 class="mt-3">Cadastre o cliente</h5>
                        <p class="mb-0 text-muted">Registre dados obrigatorios com validacao para evitar retrabalho.</p>
                    </div>
                </article>
            </div>
            <div class="col-md-4">
                <article class="card step-card h-100">
                    <div class="card-body p-4">
                        <span class="step-index">03</span>
                        <h5 class="mt-3">Finalize a reserva</h5>
                        <p class="mb-0 text-muted">Confirme a quantidade de pessoas e acompanhe o historico no painel.</p>
                    </div>
                </article>
            </div>
        </div>
    </section>

    <section class="mt-4">
        <div class="row g-3">
            <div class="col-lg-5 order-1 order-lg-2">
                <div class="card faq-panel h-100">
                    <div class="card-body p-4">
                        <div class="section-head mb-3">
                            <span class="section-chip section-chip-dark">FAQ rapido</span>
                            <h4 class="mb-1">Perguntas frequentes</h4>
                        </div>
                        <div class="faq-list">
                            <details open>
                                <summary>Como funciona a reserva?</summary>
                                <p>Selecione cliente, pacote e quantidade. O sistema valida os dados e atualiza as vagas automaticamente.</p>
                            </details>
                            <details>
                                <summary>Posso acompanhar reservas antigas?</summary>
                                <p>Sim. Todas as reservas ficam registradas com cliente, destino, valor e observacoes.</p>
                            </details>
                            <details>
                                <summary>O sistema valida email e campos obrigatorios?</summary>
                                <p>Sim. O cadastro impede campos vazios e evita duplicidade de email para clientes.</p>
                            </details>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 order-2 order-lg-1">
                <div class="card testimonial-panel h-100">
                    <div class="card-body p-4">
                        <div class="section-head mb-3">
                            <span class="section-chip">Depoimentos</span>
                            <h4 class="mb-1">O que os clientes dizem</h4>
                        </div>
                        <div class="testimonial-list">
                            <blockquote>
                                <p>"Atendimento rapido e pacote muito bem organizado. Tudo ocorreu conforme planejado."</p>
                                <footer>- Mariana Souza, viagem para Gramado</footer>
                            </blockquote>
                            <blockquote>
                                <p>"Conseguimos reservar em poucos minutos e acompanhar todos os detalhes com clareza."</p>
                                <footer>- Eduardo Lima, viagem para Porto de Galinhas</footer>
                            </blockquote>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="mt-4">
        <div class="row g-3">
            <div class="col-lg-7">
                <div class="card contact-card h-100">
                    <div class="card-body p-4">
                        <span class="section-chip">Contato e suporte</span>
                        <h4 class="mt-2 mb-3">Fale com a Destino Certo Turismo</h4>
                        <div class="contact-grid">
                            <div><strong>Telefone:</strong><br>(11) 4002-8922</div>
                            <div><strong>WhatsApp:</strong><br>(11) 98888-7788</div>
                            <div><strong>Email:</strong><br>contato@destinocerto.com.br</div>
                            <div><strong>Horario:</strong><br>Seg a Sex, 9h as 18h</div>
                        </div>
                        <div class="d-flex flex-wrap gap-2 mt-3">
                            <a class="btn btn-success" href="https://wa.me/5511988887788?text=Ola%2C%20quero%20ajuda%20com%20uma%20viagem." target="_blank" rel="noopener noreferrer">Abrir chat no WhatsApp</a>
                            <a class="btn btn-outline-primary" href="mailto:contato@destinocerto.com.br">Enviar email</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="card contact-card h-100">
                    <div class="card-body p-4">
                        <span class="section-chip section-chip-dark">Loja fisica</span>
                        <h4 class="mt-2 mb-3">Unidade Sao Paulo</h4>
                        <p class="mb-2"><strong>Endereco:</strong><br>Av. Paulista, 1578 - Bela Vista<br>Sao Paulo - SP, CEP 01310-200</p>
                        <p class="mb-3"><strong>Ponto de referencia:</strong><br>Proximo a estacao Trianon-MASP.</p>
                        <a class="btn btn-outline-secondary" target="_blank" rel="noopener noreferrer" href="https://www.google.com/maps?q=Av.+Paulista,+1578,+Sao+Paulo">Ver no mapa</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php require __DIR__ . '/partials/footer.php'; ?>

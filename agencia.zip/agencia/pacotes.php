<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $destino = trim((string) ($_POST['destino'] ?? ''));
    $descricao = trim((string) ($_POST['descricao'] ?? ''));
    $preco = (float) ($_POST['preco'] ?? 0);
    $duracao = (int) ($_POST['duracao_dias'] ?? 0);
    $vagas = (int) ($_POST['vagas'] ?? 0);
    $imagem = trim((string) ($_POST['imagem'] ?? ''));

    if ($destino === '' || $descricao === '' || $preco <= 0 || $duracao <= 0 || $vagas < 0) {
        flash('danger', 'Preencha os campos obrigatorios de destino corretamente.');
        header('Location: pacotes.php');
        exit;
    }

    $verifica = $pdo->prepare("SELECT id FROM pacotes WHERE lower(destino) = lower(?) LIMIT 1");
    $verifica->execute([$destino]);
    if ($verifica->fetch()) {
        flash('warning', 'Esse destino ja existe. Edite o nome para cadastrar outro pacote.');
        header('Location: pacotes.php');
        exit;
    }

    if ($imagem === '') {
        $imagem = 'static/img/default.svg';
    }

    $stmt = $pdo->prepare(
        "INSERT INTO pacotes (destino, descricao, preco, duracao_dias, vagas, imagem)
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    $stmt->execute([$destino, $descricao, $preco, $duracao, $vagas, $imagem]);
    flash('success', 'Destino adicionado com sucesso.');
    header('Location: pacotes.php');
    exit;
}

$pacotes = $pdo->query("SELECT id, destino, descricao, preco, duracao_dias, vagas, imagem FROM pacotes ORDER BY destino")->fetchAll();
$totalPacotes = count($pacotes);
$mediaPreco = 0.0;
$totalVagas = 0;
foreach ($pacotes as $pacote) {
    $mediaPreco += (float) $pacote['preco'];
    $totalVagas += (int) $pacote['vagas'];
}
$mediaPreco = $totalPacotes > 0 ? $mediaPreco / $totalPacotes : 0.0;
$flashes = consume_flash();

$pageTitle = 'Pacotes - Destino Certo Turismo';
$activeNav = 'pacotes';
$navMode = 'admin';
require __DIR__ . '/partials/header.php';
?>
    <?php foreach ($flashes as $msg): ?><div class="alert alert-<?= h($msg['type']) ?>"><?= h($msg['message']) ?></div><?php endforeach; ?>
    <section class="page-head mb-4">
        <div class="d-flex flex-wrap justify-content-between align-items-end gap-2">
            <div>
                <span class="section-chip mb-2">Catálogo</span>
                <h1 class="h3 fw-bold">Pacotes</h1>
                <p class="text-muted mb-0">Gerencie destinos, preços e vagas com um visual mais limpo e moderno.</p>
            </div>
            <div class="text-muted small">
                Ativos: <strong><?= $totalPacotes ?></strong> • Vagas: <strong><?= $totalVagas ?></strong>
            </div>
        </div>
    </section>

    <section class="mb-3">
        <div class="row g-3">
            <div class="col-md-4"><div class="card dashboard-kpi"><div class="card-body"><h5 class="card-title">Destinos ativos</h5><p class="display-6 mb-0"><?= $totalPacotes ?></p></div></div></div>
            <div class="col-md-4"><div class="card dashboard-kpi"><div class="card-body"><h5 class="card-title">Vagas totais</h5><p class="display-6 mb-0"><?= $totalVagas ?></p></div></div></div>
            <div class="col-md-4"><div class="card dashboard-kpi"><div class="card-body"><h5 class="card-title">Preco medio</h5><p class="mb-0 fw-semibold">R$ <?= number_format($mediaPreco, 2, ',', '.') ?></p></div></div></div>
        </div>
    </section>

    <div class="row g-4">
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h4 class="card-title mb-3">Adicionar novo destino</h4>
                    <form method="post">
                        <div class="mb-3"><label class="form-label">Destino</label><input type="text" class="form-control" name="destino" required></div>
                        <div class="mb-3"><label class="form-label">Descricao</label><textarea class="form-control" name="descricao" rows="3" required></textarea></div>
                        <div class="row g-2">
                            <div class="col-6"><label class="form-label">Preco (R$)</label><input type="number" step="0.01" min="1" class="form-control" name="preco" required></div>
                            <div class="col-6"><label class="form-label">Duracao (dias)</label><input type="number" min="1" class="form-control" name="duracao_dias" required></div>
                        </div>
                        <div class="mb-3 mt-2"><label class="form-label">Vagas</label><input type="number" min="0" class="form-control" name="vagas" required></div>
                        <div class="mb-3"><label class="form-label">URL da imagem (opcional)</label><input type="url" class="form-control" name="imagem" placeholder="https://..."></div>
                        <button type="submit" class="btn btn-primary w-100">Salvar destino</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex flex-wrap justify-content-between gap-2 mb-3">
                        <h3 class="card-title mb-0">Pacotes de viagem</h3>
                        <input type="text" class="form-control filtro-pacotes" id="filtro-pacotes" placeholder="Filtrar por destino...">
                    </div>
                    <div class="row g-3" id="lista-pacotes">
                        <?php foreach ($pacotes as $pacote): ?>
                            <div class="col-md-6 pacote-item" data-destino="<?= h(strtolower((string) $pacote['destino'])) ?>">
                                <div class="card pacote-card h-100">
                                    <a class="text-decoration-none text-reset" href="destino.php?id=<?= (int) $pacote['id'] ?>">
                                        <img src="<?= h($pacote['imagem'] ?: 'static/img/default.svg') ?>" class="card-img-top pacote-img" alt="Imagem de <?= h($pacote['destino']) ?>" onerror="this.onerror=null;this.src='static/img/default.svg';">
                                    </a>
                                    <div class="card-body">
                                        <a class="text-decoration-none text-reset" href="destino.php?id=<?= (int) $pacote['id'] ?>"><h5 class="card-title"><?= h($pacote['destino']) ?></h5></a>
                                        <p class="card-text"><?= h($pacote['descricao']) ?></p>
                                        <p class="mb-1"><strong>Duracao:</strong> <?= (int) $pacote['duracao_dias'] ?> dias</p>
                                        <p class="mb-1"><strong>Vagas:</strong> <?= (int) $pacote['vagas'] ?></p>
                                        <p class="mb-2 text-success fw-semibold">R$ <?= number_format((float) $pacote['preco'], 2, ',', '.') ?></p>
                                        <a class="btn btn-sm btn-outline-primary" href="destino.php?id=<?= (int) $pacote['id'] ?>">Ver detalhes</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <p id="sem-resultado" class="mt-3 mb-0 d-none">Nenhum pacote encontrado com esse filtro.</p>
                </div>
            </div>
        </div>
    </div>
<?php require __DIR__ . '/partials/footer.php'; ?>

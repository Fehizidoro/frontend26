<?php declare(strict_types=1); ?>
</main>

<footer class="site-footer mt-5">
    <div class="container py-4">
        <div class="row g-3 align-items-center">
            <div class="col-md-8">
                <h6 class="mb-1">Destino Certo Turismo</h6>
                <p class="mb-0">Sistema de gestão para atendimento, pacotes e reservas de viagens.</p>
            </div>
            <div class="col-md-4 text-md-end">
                <small>Painel operacional • <?= date('Y') ?></small>
            </div>
        </div>
    </div>
</footer>

<a class="chat-float-btn" href="https://wa.me/5511988887788?text=Ola%2C%20quero%20falar%20com%20um%20consultor." target="_blank" rel="noopener noreferrer" aria-label="Abrir chat no WhatsApp">Chat</a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script defer src="static/js/main.js"></script>
</body>
</html>


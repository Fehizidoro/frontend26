<?php
declare(strict_types=1);
/**
 * Expected variables (optional):
 * - $pageTitle: string
 * - $activeNav: 'inicio'|'clientes'|'pacotes'|'reservas'|'area-cliente'|'destino'|null
 * - $navMode: 'admin'|'client'
 */
if (!isset($pageTitle) || !is_string($pageTitle) || $pageTitle === '') {
    $pageTitle = 'Destino Certo Turismo';
}
if (!isset($activeNav) || !is_string($activeNav)) {
    $activeNav = '';
}
$navMode = (isset($navMode) && $navMode === 'client') ? 'client' : 'admin';

function nav_link(string $href, string $label, string $key, string $activeNav): string
{
    $isActive = $key !== '' && $activeNav === $key;
    return '<a class="nav-link' . ($isActive ? ' active' : '') . '" href="' . h($href) . '">' . h($label) . '</a>';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="static/css/style.css">
</head>
<body class="app-shell">
<header class="app-topbar">
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2" href="<?= $navMode === 'client' ? 'area-cliente.php' : 'index.php' ?>">
                <span class="brand-mark" aria-hidden="true"></span>
                <span class="brand-name">Destino Certo</span>
                <span class="brand-sub d-none d-sm-inline">Turismo</span>
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#appNav" aria-controls="appNav" aria-expanded="false" aria-label="Alternar navegação">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="appNav">
                <div class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                    <?php if ($navMode === 'client'): ?>
                        <?= nav_link('area-cliente.php', 'Área do Cliente', 'area-cliente', $activeNav) ?>
                        <?= nav_link('index.php', 'Painel Interno', 'inicio', $activeNav) ?>
                    <?php else: ?>
                        <?= nav_link('index.php', 'Início', 'inicio', $activeNav) ?>
                        <?= nav_link('clientes.php', 'Clientes', 'clientes', $activeNav) ?>
                        <?= nav_link('pacotes.php', 'Pacotes', 'pacotes', $activeNav) ?>
                        <?= nav_link('reservas.php', 'Reservas', 'reservas', $activeNav) ?>
                        <?= nav_link('area-cliente.php', 'Área do Cliente', 'area-cliente', $activeNav) ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
</header>

<main class="container app-main pb-5">

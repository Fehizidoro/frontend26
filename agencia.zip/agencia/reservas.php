<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clienteId = (int) ($_POST['cliente_id'] ?? 0);
    $pacoteId = (int) ($_POST['pacote_id'] ?? 0);
    $qtd = (int) ($_POST['quantidade_pessoas'] ?? 0);
    $obs = trim((string) ($_POST['observacoes'] ?? ''));

    if ($clienteId <= 0 || $pacoteId <= 0 || $qtd <= 0) {
        flash('danger', 'Cliente, pacote e quantidade sao obrigatorios.');
        header('Location: reservas.php');
        exit;
    }

    $cliente = $pdo->prepare("SELECT id FROM clientes WHERE id = ?");
    $cliente->execute([$clienteId]);
    $cliente = $cliente->fetch();

    $pacoteStmt = $pdo->prepare("SELECT id, vagas FROM pacotes WHERE id = ?");
    $pacoteStmt->execute([$pacoteId]);
    $pacote = $pacoteStmt->fetch();

    if (!$cliente || !$pacote) {
        flash('danger', 'Cliente ou pacote invalido.');
        header('Location: reservas.php');
        exit;
    }
    if ($qtd > (int) $pacote['vagas']) {
        flash('warning', 'Nao ha vagas suficientes nesse pacote.');
        header('Location: reservas.php');
        exit;
    }

    $pdo->beginTransaction();
    try {
        $ins = $pdo->prepare("INSERT INTO reservas (cliente_id, pacote_id, quantidade_pessoas, observacoes, criado_em) VALUES (?, ?, ?, ?, ?)");
        $ins->execute([$clienteId, $pacoteId, $qtd, $obs, date('c')]);
        $upd = $pdo->prepare("UPDATE pacotes SET vagas = vagas - ? WHERE id = ?");
        $upd->execute([$qtd, $pacoteId]);
        $pdo->commit();
        flash('success', 'Reserva realizada com sucesso.');
    } catch (Throwable $e) {
        $pdo->rollBack();
        flash('danger', 'Erro ao salvar reserva.');
    }

    header('Location: reservas.php');
    exit;
}

$clientes = $pdo->query("SELECT id, nome FROM clientes ORDER BY nome")->fetchAll();
$pacotes = $pdo->query("SELECT id, destino, preco, vagas FROM pacotes ORDER BY destino")->fetchAll();
$reservas = $pdo->query(
    "SELECT r.id, c.nome AS cliente_nome, p.destino AS pacote_destino, r.quantidade_pessoas, p.preco, r.observacoes, r.criado_em
     FROM reservas r
     INNER JOIN clientes c ON c.id = r.cliente_id
     INNER JOIN pacotes p ON p.id = r.pacote_id
     ORDER BY r.id DESC"
)->fetchAll();
$totalReservas = count($reservas);
$faturamentoEstimado = 0.0;
$totalPessoas = 0;
foreach ($reservas as $item) {
    $faturamentoEstimado += ((float) $item['preco']) * ((int) $item['quantidade_pessoas']);
    $totalPessoas += (int) $item['quantidade_pessoas'];
}
$ticketMedio = $totalReservas > 0 ? $faturamentoEstimado / $totalReservas : 0.0;
$flashes = consume_flash();

$pageTitle = 'Reservas - Destino Certo Turismo';
$activeNav = 'reservas';
$navMode = 'admin';
require __DIR__ . '/partials/header.php';
?>
    <?php foreach ($flashes as $msg): ?><div class="alert alert-<?= h($msg['type']) ?>"><?= h($msg['message']) ?></div><?php endforeach; ?>
    <section class="page-head mb-4">
        <div class="d-flex flex-wrap justify-content-between align-items-end gap-2">
            <div>
                <span class="section-chip mb-2">Operação</span>
                <h1 class="h3 fw-bold">Reservas</h1>
                <p class="text-muted mb-0">Acompanhe vendas, ticket médio e registre novas reservas com facilidade.</p>
            </div>
            <div class="text-muted small">
                Reservas: <strong><?= $totalReservas ?></strong> • Pessoas: <strong><?= $totalPessoas ?></strong>
            </div>
        </div>
    </section>
    <section class="mb-3">
        <div class="row g-3">
            <div class="col-md-3">
                <div class="card dashboard-kpi"><div class="card-body">
                    <h5 class="card-title">Reservas</h5>
                    <p class="display-6 mb-0"><?= $totalReservas ?></p>
                </div></div>
            </div>
            <div class="col-md-3">
                <div class="card dashboard-kpi"><div class="card-body">
                    <h5 class="card-title">Pessoas</h5>
                    <p class="display-6 mb-0"><?= $totalPessoas ?></p>
                </div></div>
            </div>
            <div class="col-md-3">
                <div class="card dashboard-kpi"><div class="card-body">
                    <h5 class="card-title">Faturamento estimado</h5>
                    <p class="mb-0 fw-semibold">R$ <?= number_format($faturamentoEstimado, 2, ',', '.') ?></p>
                </div></div>
            </div>
            <div class="col-md-3">
                <div class="card dashboard-kpi"><div class="card-body">
                    <h5 class="card-title">Ticket medio</h5>
                    <p class="mb-0 fw-semibold">R$ <?= number_format($ticketMedio, 2, ',', '.') ?></p>
                </div></div>
            </div>
        </div>
    </section>

    <div class="row g-4">
        <div class="col-lg-4">
            <div class="card shadow-sm"><div class="card-body">
                <h4 class="card-title mb-3">Nova reserva</h4>
                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">Cliente</label>
                        <select class="form-select" id="cliente_id" name="cliente_id" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($clientes as $cliente): ?>
                                <option value="<?= (int) $cliente['id'] ?>"><?= h($cliente['nome']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Pacote</label>
                        <select class="form-select" id="pacote_id" name="pacote_id" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($pacotes as $pacote): ?>
                                <option value="<?= (int) $pacote['id'] ?>" data-preco="<?= (float) $pacote['preco'] ?>">
                                    <?= h($pacote['destino']) ?> - R$ <?= number_format((float) $pacote['preco'], 2, ',', '.') ?> (<?= (int) $pacote['vagas'] ?> vagas)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3"><label class="form-label">Quantidade de pessoas</label><input id="quantidade_pessoas" type="number" class="form-control" name="quantidade_pessoas" min="1" required></div>
                    <div class="mb-3"><label class="form-label">Observacoes</label><textarea class="form-control" name="observacoes" rows="3"></textarea></div>
                    <div class="resumo-reserva mb-3"><strong>Valor estimado:</strong> <span id="valor-estimado">R$ 0,00</span></div>
                    <div class="resumo-reserva mb-3">
                        <strong>Resumo:</strong>
                        <span id="resumo-reserva-info">Selecione cliente, pacote e quantidade.</span>
                    </div>
                    <button type="submit" class="btn btn-primary">Salvar reserva</button>
                </form>
            </div></div>
        </div>
        <div class="col-lg-8">
            <div class="card shadow-sm"><div class="card-body">
                <div class="d-flex flex-wrap justify-content-between gap-2 mb-3">
                    <h4 class="card-title mb-0">Reservas realizadas</h4>
                    <input type="text" class="form-control filtro-reservas" id="filtro-reservas" placeholder="Buscar por cliente, pacote ou observacao...">
                </div>
                <?php if (!$reservas): ?>
                    <p class="mb-0">Nenhuma reserva registrada ate o momento.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped align-middle" id="tabela-reservas">
                            <thead><tr><th>ID</th><th>Cliente</th><th>Pacote</th><th>Pessoas</th><th>Total</th><th>Status</th><th>Data</th><th>Observacoes</th></tr></thead>
                            <tbody id="lista-reservas">
                            <?php foreach ($reservas as $reserva): ?>
                                <?php $totalReserva = ((float) $reserva['preco']) * ((int) $reserva['quantidade_pessoas']); ?>
                                <tr class="reserva-item" data-busca="<?= h(strtolower($reserva['cliente_nome'] . ' ' . $reserva['pacote_destino'] . ' ' . ($reserva['observacoes'] ?? ''))) ?>">
                                    <td><?= (int) $reserva['id'] ?></td>
                                    <td><?= h($reserva['cliente_nome']) ?></td>
                                    <td><?= h($reserva['pacote_destino']) ?></td>
                                    <td><?= (int) $reserva['quantidade_pessoas'] ?></td>
                                    <td class="fw-semibold">R$ <?= number_format($totalReserva, 2, ',', '.') ?></td>
                                    <td><span class="badge text-bg-success">Confirmada</span></td>
                                    <td><?= date('d/m/Y H:i', strtotime((string) $reserva['criado_em'])) ?></td>
                                    <td><?= h($reserva['observacoes'] ?: '-') ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <p id="reservas-sem-resultado" class="mt-3 mb-0 d-none">Nenhuma reserva encontrada com esse filtro.</p>
                <?php endif; ?>
            </div></div>
        </div>
    </div>
<?php require __DIR__ . '/partials/footer.php'; ?>

function formatarBRL(valor) {
    return new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "BRL",
    }).format(valor);
}

function inicializarFiltroPacotes() {
    const inputFiltro = document.getElementById("filtro-pacotes");
    if (!inputFiltro) return;

    const itens = Array.from(document.querySelectorAll(".pacote-item"));
    const semResultado = document.getElementById("sem-resultado");

    inputFiltro.addEventListener("input", () => {
        const termo = inputFiltro.value.trim().toLowerCase();
        let visiveis = 0;

        itens.forEach((item) => {
            const destino = item.dataset.destino || "";
            const mostrar = destino.includes(termo);
            item.classList.toggle("d-none", !mostrar);
            if (mostrar) visiveis += 1;
        });

        if (semResultado) {
            semResultado.classList.toggle("d-none", visiveis !== 0);
        }
    });
}

function inicializarResumoReserva() {
    const selectCliente = document.getElementById("cliente_id");
    const selectPacote = document.getElementById("pacote_id");
    const inputQtd = document.getElementById("quantidade_pessoas");
    const alvoValor = document.getElementById("valor-estimado");
    const resumoInfo = document.getElementById("resumo-reserva-info");

    if (!selectPacote || !inputQtd || !alvoValor) return;

    const atualizar = () => {
        const opcaoSelecionada = selectPacote.options[selectPacote.selectedIndex];
        const preco = Number(opcaoSelecionada?.dataset?.preco || 0);
        const quantidade = Number(inputQtd.value || 0);
        const total = preco * quantidade;
        alvoValor.textContent = formatarBRL(total);

        if (resumoInfo) {
            const nomeCliente = selectCliente?.options?.[selectCliente.selectedIndex]?.textContent || "Cliente";
            const nomePacote = opcaoSelecionada?.textContent?.split(" - ")[0] || "Pacote";
            if (preco > 0 && quantidade > 0) {
                resumoInfo.textContent = `${nomeCliente} | ${nomePacote} | ${quantidade} pessoa(s)`;
            } else {
                resumoInfo.textContent = "Selecione cliente, pacote e quantidade.";
            }
        }
    };

    selectCliente?.addEventListener("change", atualizar);
    selectPacote.addEventListener("change", atualizar);
    inputQtd.addEventListener("input", atualizar);
    atualizar();
}

function inicializarFiltroClientes() {
    const inputFiltro = document.getElementById("filtro-clientes");
    if (!inputFiltro) return;

    const itens = Array.from(document.querySelectorAll(".cliente-item"));
    const semResultado = document.getElementById("clientes-sem-resultado");

    inputFiltro.addEventListener("input", () => {
        const termo = inputFiltro.value.trim().toLowerCase();
        let visiveis = 0;

        itens.forEach((item) => {
            const base = item.dataset.busca || "";
            const mostrar = base.includes(termo);
            item.classList.toggle("d-none", !mostrar);
            if (mostrar) visiveis += 1;
        });

        semResultado?.classList.toggle("d-none", visiveis !== 0);
    });
}

function inicializarFiltroReservas() {
    const inputFiltro = document.getElementById("filtro-reservas");
    if (!inputFiltro) return;

    const itens = Array.from(document.querySelectorAll(".reserva-item"));
    const semResultado = document.getElementById("reservas-sem-resultado");

    inputFiltro.addEventListener("input", () => {
        const termo = inputFiltro.value.trim().toLowerCase();
        let visiveis = 0;

        itens.forEach((item) => {
            const base = item.dataset.busca || "";
            const mostrar = base.includes(termo);
            item.classList.toggle("d-none", !mostrar);
            if (mostrar) visiveis += 1;
        });

        semResultado?.classList.toggle("d-none", visiveis !== 0);
    });
}

document.addEventListener("DOMContentLoaded", () => {
    inicializarFiltroPacotes();
    inicializarFiltroClientes();
    inicializarFiltroReservas();
    inicializarResumoReserva();
});

ConectaFácil — Sistema de Locação de Dispositivos
===================================================
Versão 2.0 — Design moderno, banco expandido

REQUISITOS
----------
- PHP 8.1+
- MySQL / MariaDB (XAMPP)
- Apache (XAMPP)

INSTALAÇÃO
----------
1. Extraia esta pasta em:
   C:\xampp\htdocs\conectafacil

2. Inicie o XAMPP (Apache + MySQL)

3. Acesse o phpMyAdmin:
   http://localhost/phpmyadmin

4. Clique em "SQL", cole o conteúdo de:
   banco_de_dados.sql
   e clique em Executar.

5. Acesse o sistema:
   http://localhost/conectafacil

CREDENCIAIS DE TESTE
--------------------
Admin:    admin@conectafacil.com    / admin123
Operador: operador@conectafacil.com / operador123

ESTRUTURA DE ARQUIVOS
----------------------
index.php              → Redireciona para login/dashboard
login.php              → Tela de login moderna
logout.php             → Encerra sessão
dashboard.php          → Painel com estatísticas e receita mensal
devices.php            → Lista e gerencia dispositivos (admin)
device_save.php        → Cria/edita dispositivo
device_delete.php      → Exclui dispositivo
rentals.php            → Lista locações ativas e finalizadas
rental_new.php         → Nova locação
rental_return.php      → Devolução com cálculo automático
includes/db.php        → Conexão PDO MySQL
includes/auth.php      → Sessão e permissões
includes/layout.php    → Layout unificado
assets/style.css       → Design system completo (Sora + DM Sans)
assets/app.js          → Modal, cálculo de devolução, alerts
banco_de_dados.sql     → SQL completo com 8 tabelas

BANCO DE DADOS — 8 TABELAS
---------------------------
users               → Login com roles (admin / operador)
customers           → Cadastro de clientes com CPF/contato
device_categories   → Categorias: Smartphone, Tablet, etc.
devices             → Dispositivos com IMEI, cor, capacidade
rentals             → Locações com financeiro completo
rental_history      → Auditoria de edições (quem mudou o quê)
device_maintenances → Histórico de manutenções
settings            → Configurações editáveis pelo admin

REGRAS DE NEGÓCIO
-----------------
- Multa por atraso: 10% da diária por dia de atraso
- Taxa de dano: diária × 5 × 20%
- Valor final = base + multa + dano
- Dispositivo alugado NÃO pode ser excluído/editado
- Apenas ADMIN gerencia dispositivos
- Operador pode criar locações e devoluções
- Receita do mês exibida no dashboard

CONFIGURAÇÃO DO BANCO (includes/db.php)
---------------------------------------
$host   = 'localhost';
$dbname = 'conectafacil';
$user   = 'root';
$pass   = '';  // padrão XAMPP

OBSERVAÇÕES
-----------
- Sem dependência de Composer ou npm
- CSS e JS próprios, sem Bootstrap
- Fontes via Google Fonts (requer internet)
- Senhas em texto puro (apenas para uso escolar)
  Em produção: usar password_hash() / password_verify()

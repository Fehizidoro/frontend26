<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/layout.php';
requireLogin();

$db = getDB();
$user = currentUser();

// Se for POST, salvar mensagem
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = trim($_POST['message'] ?? '');
    $customer_id = $_POST['customer_id'] ?? null;
    $rental_id = $_POST['rental_id'] ?? null; // Adicionado para vincular a locação, se houver

    if (!$message || !$customer_id) {
        $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Dados inválidos.'];
    } else {
        try {
            // Primeiro, verificar se existe um chat_thread para este cliente/locação
            // Se não, criar um novo thread
            $stmt = $db->prepare("SELECT id FROM chat_threads WHERE customer_id = ? AND (rental_id = ? OR rental_id IS NULL)");
            $stmt->execute([$customer_id, $rental_id]);
            $thread_id = $stmt->fetchColumn();

            if (!$thread_id) {
                $stmt = $db->prepare("INSERT INTO chat_threads (customer_id, rental_id, subject, status, assigned_to) VALUES (?, ?, ?, 'waiting_customer', ?)");
                $stmt->execute([$customer_id, $rental_id, 'Atendimento ConectaFácil', $user['id']]);
                $thread_id = $db->lastInsertId();
            }

            $stmt = $db->prepare("
                INSERT INTO chat_messages (thread_id, rental_id, customer_id, user_id, message, sender_type)
                VALUES (?, ?, ?, ?, ?, 'admin')
            ");
            $stmt->execute([$thread_id, $rental_id, $customer_id, $user['id'], $message]);
            $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Mensagem enviada!'];
        } catch (Exception $e) {
            $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Erro: ' . $e->getMessage()];
        }
    }

    header('Location: admin_chat.php?customer_id=' . $customer_id . ($rental_id ? '&rental_id=' . $rental_id : ''));
    exit;
}

// Buscar clientes com mensagens usando a VIEW
$customers_with_chat = $db->query("SELECT * FROM v_chat_inbox ORDER BY last_message_at DESC")->fetchAll();

$selected_customer_id = $_GET['customer_id'] ?? null;
$selected_rental_id = $_GET['rental_id'] ?? null;
$messages = [];
$selected_customer = null;

if ($selected_customer_id) {
    // Buscar dados do cliente
    $stmt = $db->prepare("SELECT * FROM customers WHERE id = ?");
    $stmt->execute([$selected_customer_id]);
    $selected_customer = $stmt->fetch();

    // Buscar mensagens
    $sql_messages = "SELECT * FROM chat_messages WHERE customer_id = ?";
    $params_messages = [$selected_customer_id];

    if ($selected_rental_id) {
        $sql_messages .= " AND rental_id = ?";
        $params_messages[] = $selected_rental_id;
    }
    $sql_messages .= " ORDER BY created_at ASC";

    $stmt = $db->prepare($sql_messages);
    $stmt->execute($params_messages);
    $messages = $stmt->fetchAll();

    // Marcar como lidas as mensagens do cliente
    $db->prepare("UPDATE chat_messages SET is_read = 1 WHERE customer_id = ? AND sender_type = 'customer' AND is_read = 0")
        ->execute([$selected_customer_id]);
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$actions = '<a href="admin_chat.php" class="btn btn-secondary btn-sm"><i class="bi bi-arrow-clockwise"></i> Atualizar</a>';
renderPageStart('Chat com Clientes', 'admin_chat.php', $actions);
?>

<?= flashHtml($flash) ?>

<div class="chat-layout">
  <!-- Sidebar com clientes -->
  <div class="card chat-sidebar">
    <div class="card-header">
      <h3 class="card-title">Conversas</h3>
    </div>
    <div class="card-body p-0">
      <?php if (empty($customers_with_chat)): ?>
        <div class="text-center text-muted py-4">
          <i class="bi bi-chat-left-text text-2xl mb-2"></i>
          <p>Nenhuma conversa ainda.</p>
        </div>
      <?php else: ?>
        <ul class="list-none divide-y divide-border-color">
          <?php foreach ($customers_with_chat as $customer): ?>
            <li>
              <a href="admin_chat.php?customer_id=<?= $customer['customer_id'] ?>" class="flex items-center gap-3 p-3 hover:bg-bg-hover transition-colors <?= $selected_customer_id == $customer['customer_id'] ? 'bg-info-bg' : '' ?>">
                <div class="flex-1">
                  <div class="font-semibold text-text-900"><?= htmlspecialchars($customer['customer_name']) ?></div>
                  <div class="text-sm text-text-600"><?= htmlspecialchars($customer['email']) ?></div>
                </div>
                <?php if ($customer['unread_count'] > 0): ?>
                  <span class="badge badge-red">
                    <?= $customer['unread_count'] ?>
                  </span>
                <?php endif; ?>
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>

  <!-- Chat principal -->
  <div class="card chat-main">
    <?php if (!$selected_customer): ?>
      <div class="flex flex-col items-center justify-center h-full text-center text-muted">
        <i class="bi bi-chat-left-text text-4xl mb-4"></i>
        <p>Selecione um cliente para iniciar a conversa.</p>
      </div>
    <?php else: ?>
      <div class="card-header">
        <h2 class="card-title"><?= htmlspecialchars($selected_customer['name']) ?></h2>
        <p class="text-muted text-sm"><?= htmlspecialchars($selected_customer['email']) ?> | <?= htmlspecialchars($selected_customer['phone']) ?></p>
      </div>

      <div class="chat-messages">
        <?php if (empty($messages)): ?>
          <div class="text-center text-muted m-auto">
            <p>Nenhuma mensagem ainda.</p>
          </div>
        <?php else: ?>
          <?php foreach ($messages as $msg): ?>
            <div class="message <?= $msg['sender_type'] === 'customer' ? 'customer' : 'admin' ?>">
              <div class="message-bubble">
                <?= htmlspecialchars($msg['message']) ?>
                <div class="message-time">
                  <?= date('H:i', strtotime($msg['created_at'])) ?>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <form method="POST" class="chat-input-area">
        <input type="hidden" name="customer_id" value="<?= $selected_customer_id ?>">
        <input type="hidden" name="rental_id" value="<?= $selected_rental_id ?>">
        <input type="text" name="message" placeholder="Digite sua resposta..." required autofocus>
        <button type="submit" class="btn btn-primary"><i class="bi bi-send"></i> Enviar</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<script>
  // Auto-scroll para a última mensagem
  const chatMessages = document.querySelector('.chat-messages');
  if (chatMessages) {
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }
</script>

<?php renderPageEnd(); ?>

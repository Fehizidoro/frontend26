/* ConectaFácil — app.js */

/* ── Modal helpers ───────────────────────────────────────── */
function openModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.add('open'); document.body.style.overflow = 'hidden'; }
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.remove('open'); document.body.style.overflow = ''; }
}

// Close on backdrop click
document.addEventListener('click', function(e) {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
    document.body.style.overflow = '';
  }
});

// Close on Escape
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(m => {
      m.classList.remove('open');
      document.body.style.overflow = '';
    });
  }
});

/* ── Confirm delete ──────────────────────────────────────── */
document.addEventListener('submit', function(e) {
  const form = e.target;
  const msg  = form.getAttribute('data-confirm');
  if (msg && !confirm(msg)) e.preventDefault();
});

/* ── Device modal ────────────────────────────────────────── */
window.openDeviceCreate = function() {
  document.getElementById('modalDeviceTitle').textContent = 'Novo Dispositivo';
  document.getElementById('fieldId').value      = '';
  document.getElementById('fieldBrand').value   = '';
  document.getElementById('fieldModel').value   = '';
  document.getElementById('fieldImei').value    = '';
  document.getElementById('fieldRate').value    = '';
  document.getElementById('fieldColor').value   = '';
  document.getElementById('fieldStatus').value  = 'available';
  const fn = document.getElementById('fieldNotes');
  if (fn) fn.value = '';
  const fp = document.getElementById('fieldPhoto');
  if (fp) fp.value = '';
  openModal('deviceModal');
};

window.openDeviceEdit = function(d) {
  document.getElementById('modalDeviceTitle').textContent = 'Editar Dispositivo';
  document.getElementById('fieldId').value      = d.id;
  document.getElementById('fieldBrand').value   = d.brand;
  document.getElementById('fieldModel').value   = d.model;
  document.getElementById('fieldImei').value    = d.imei  || '';
  document.getElementById('fieldRate').value    = d.daily_rate;
  document.getElementById('fieldColor').value   = d.color || '';
  document.getElementById('fieldStatus').value  = d.status;
  const fn = document.getElementById('fieldNotes');
  if (fn) fn.value = d.notes || '';
  const fp = document.getElementById('fieldPhoto');
  if (fp) fp.value = d.photo_url || '';
  openModal('deviceModal');
};

/* ── Return calc ─────────────────────────────────────────── */
(function() {
  const returnDateInput   = document.getElementById('return_date');
  const hasDamageCheckbox = document.getElementById('has_damage');
  const summaryDiv        = document.getElementById('return-summary');

  function fmt(v) {
    return 'R$ ' + v.toFixed(2).replace('.', ',');
  }

  function calcReturn() {
    if (!returnDateInput || !summaryDiv) return;
    const dailyRate   = parseFloat(summaryDiv.dataset.dailyRate   || 0);
    const startDate   = new Date(summaryDiv.dataset.startDate   + 'T00:00:00');
    const plannedDate = new Date(summaryDiv.dataset.plannedDate + 'T00:00:00');
    const returnDate  = returnDateInput.value
      ? new Date(returnDateInput.value + 'T00:00:00')
      : null;

    if (!returnDate || isNaN(returnDate)) {
      summaryDiv.innerHTML = '<span class="text-muted" style="font-size:13px">Selecione a data de devolução para ver o cálculo.</span>';
      return;
    }

    const msDay      = 86400000;
    const totalDays  = Math.max(1, Math.ceil((returnDate - startDate) / msDay));
    const baseValue  = dailyRate * totalDays;

    let lateDays = 0;
    if (returnDate > plannedDate)
      lateDays = Math.ceil((returnDate - plannedDate) / msDay);

    const lateFee   = lateDays > 0 ? dailyRate * lateDays * 0.1 : 0;
    const damageFee = hasDamageCheckbox && hasDamageCheckbox.checked ? dailyRate * 5 * 0.2 : 0;
    const total     = baseValue + lateFee + damageFee;

    let html = `
      <div class="return-summary-row">
        <span>Dias locados</span><strong>${totalDays} dia${totalDays !== 1 ? 's' : ''}</strong>
      </div>
      <div class="return-summary-row">
        <span>Valor base (${totalDays}d × ${fmt(dailyRate)})</span>
        <span>${fmt(baseValue)}</span>
      </div>`;

    if (lateDays > 0) {
      html += `
      <div class="return-summary-row late">
        <span>⚠ Multa por atraso (${lateDays}d × 10%)</span>
        <span>${fmt(lateFee)}</span>
      </div>`;
    }

    if (damageFee > 0) {
      html += `
      <div class="return-summary-row damage">
        <span>⚡ Taxa de dano</span>
        <span>${fmt(damageFee)}</span>
      </div>`;
    }

    html += `
      <div class="return-summary-row total">
        <span>Total a cobrar</span><span>${fmt(total)}</span>
      </div>`;

    summaryDiv.innerHTML = html;
  }

  if (returnDateInput)   returnDateInput.addEventListener('change', calcReturn);
  if (hasDamageCheckbox) hasDamageCheckbox.addEventListener('change', calcReturn);
  if (returnDateInput && returnDateInput.value) calcReturn();
})();

/* ── Auto-dismiss alerts ─────────────────────────────────── */
document.querySelectorAll('.alert[data-autohide]').forEach(el => {
  setTimeout(() => {
    el.style.transition = 'opacity .4s';
    el.style.opacity    = '0';
    setTimeout(() => el.remove(), 400);
  }, 4000);
});

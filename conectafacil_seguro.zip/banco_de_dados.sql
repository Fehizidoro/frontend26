-- ============================================================
--  ConectaFácil — Banco de Dados Completo e Modernizado
--  Sistema de Locação de Dispositivos com Admin, Layout e Chat
--  MySQL / MariaDB • utf8mb4
-- ============================================================
--  Como usar no XAMPP/phpMyAdmin:
--    1. Acesse: http://localhost/phpmyadmin
--    2. Clique em SQL
--    3. Cole este arquivo inteiro ou importe este .sql
--    4. Clique em Executar
--
--  Observação importante:
--    O login atual do projeto compara senha em texto puro.
--    Por isso, as senhas iniciais abaixo estão em texto puro para
--    funcionar imediatamente com o código PHP enviado.
-- ============================================================

SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET time_zone = '-03:00';
SET NAMES utf8mb4;

DROP DATABASE IF EXISTS conectafacil;

CREATE DATABASE conectafacil
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE conectafacil;

-- ============================================================
-- 1. USUÁRIOS DO PAINEL ADMINISTRATIVO
-- ============================================================
CREATE TABLE users (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(120) NOT NULL,
    email           VARCHAR(180) NOT NULL UNIQUE,
    password        VARCHAR(255) NOT NULL,
    role            ENUM('admin','operador') NOT NULL DEFAULT 'operador',
    avatar_url      VARCHAR(500) DEFAULT NULL,
    phone           VARCHAR(30) DEFAULT NULL,
    active          TINYINT(1) NOT NULL DEFAULT 1,
    last_login      DATETIME DEFAULT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB COMMENT='Usuários do dashboard administrativo';

-- ============================================================
-- 2. PREFERÊNCIAS VISUAIS DO USUÁRIO ADMIN
-- ============================================================
CREATE TABLE user_preferences (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    theme_mode      ENUM('light','dark','system') NOT NULL DEFAULT 'light',
    sidebar_state   ENUM('expanded','collapsed') NOT NULL DEFAULT 'expanded',
    accent_color    VARCHAR(20) NOT NULL DEFAULT '#2563eb',
    dashboard_layout JSON DEFAULT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_user_preferences_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE ON UPDATE CASCADE,

    UNIQUE KEY uq_user_preferences_user (user_id)
) ENGINE=InnoDB COMMENT='Preferências de layout do painel por usuário';

-- ============================================================
-- 3. CLIENTES
-- ============================================================
CREATE TABLE customers (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(160) NOT NULL,
    cpf             VARCHAR(14) UNIQUE,
    phone           VARCHAR(30),
    email           VARCHAR(180),
    address         VARCHAR(255),
    city            VARCHAR(100),
    state           CHAR(2),
    zip_code        VARCHAR(12),
    notes           TEXT,
    active          TINYINT(1) NOT NULL DEFAULT 1,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB COMMENT='Cadastro de clientes';

-- ============================================================
-- 4. CATEGORIAS DE DISPOSITIVOS
-- ============================================================
CREATE TABLE device_categories (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(90) NOT NULL UNIQUE,
    description     VARCHAR(255),
    icon            VARCHAR(80) DEFAULT 'bi-device-ssd',
    active          TINYINT(1) NOT NULL DEFAULT 1,
    sort_order      INT NOT NULL DEFAULT 0,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB COMMENT='Categorias dos dispositivos';

-- ============================================================
-- 5. DISPOSITIVOS
-- ============================================================
CREATE TABLE devices (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    category_id     INT DEFAULT NULL,
    brand           VARCHAR(100) NOT NULL,
    model           VARCHAR(120) NOT NULL,
    imei            VARCHAR(30) UNIQUE,
    serial_no       VARCHAR(80),
    color           VARCHAR(60),
    storage_gb      SMALLINT UNSIGNED,
    ram_gb          SMALLINT UNSIGNED DEFAULT NULL,
    daily_rate      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    replacement_value DECIMAL(10,2) DEFAULT NULL,
    status          ENUM('available','rented','maintenance','inactive') NOT NULL DEFAULT 'available',
    condition_in    ENUM('novo','bom','regular','ruim') NOT NULL DEFAULT 'bom',
    battery_health  TINYINT UNSIGNED DEFAULT NULL,
    photo_url       VARCHAR(500) DEFAULT NULL,
    notes           TEXT,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_devices_category
        FOREIGN KEY (category_id) REFERENCES device_categories(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Dispositivos disponíveis para locação';

-- ============================================================
-- 6. LOCAÇÕES E SOLICITAÇÕES
--    Inclui status pending, usado pelo site público.
-- ============================================================
CREATE TABLE rentals (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    device_id         INT NOT NULL,
    customer_id       INT DEFAULT NULL,
    customer_name     VARCHAR(160) NOT NULL,
    start_date        DATE NOT NULL,
    planned_end_date  DATE NOT NULL,
    actual_end_date   DATE DEFAULT NULL,
    status            ENUM('pending','active','finished','cancelled') NOT NULL DEFAULT 'pending',

    daily_rate_snap   DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    base_value        DECIMAL(10,2) DEFAULT NULL,
    late_fee          DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    damage_fee        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    discount          DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    final_value       DECIMAL(10,2) DEFAULT NULL,
    payment_status    ENUM('pending','partial','paid','refunded') NOT NULL DEFAULT 'pending',
    payment_method    ENUM('pix','cartao','dinheiro','boleto','transferencia','outro') DEFAULT NULL,

    has_damage        TINYINT(1) NOT NULL DEFAULT 0,
    damage_notes      TEXT,
    condition_out     ENUM('novo','bom','regular','ruim') DEFAULT NULL,

    created_by        INT DEFAULT NULL,
    closed_by         INT DEFAULT NULL,
    approved_at       DATETIME DEFAULT NULL,
    cancelled_at      DATETIME DEFAULT NULL,
    notes             TEXT,
    created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_rentals_device
        FOREIGN KEY (device_id) REFERENCES devices(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,

    CONSTRAINT fk_rentals_customer
        FOREIGN KEY (customer_id) REFERENCES customers(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT fk_rentals_created_by
        FOREIGN KEY (created_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT fk_rentals_closed_by
        FOREIGN KEY (closed_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Solicitações e locações de dispositivos';

-- ============================================================
-- 7. PAGAMENTOS
-- ============================================================
CREATE TABLE rental_payments (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    rental_id       INT NOT NULL,
    amount          DECIMAL(10,2) NOT NULL,
    method          ENUM('pix','cartao','dinheiro','boleto','transferencia','outro') NOT NULL DEFAULT 'pix',
    status          ENUM('pending','confirmed','cancelled','refunded') NOT NULL DEFAULT 'confirmed',
    reference_code  VARCHAR(120) DEFAULT NULL,
    paid_at         DATETIME DEFAULT NULL,
    created_by      INT DEFAULT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_rental_payments_rental
        FOREIGN KEY (rental_id) REFERENCES rentals(id)
        ON DELETE CASCADE ON UPDATE CASCADE,

    CONSTRAINT fk_rental_payments_user
        FOREIGN KEY (created_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Pagamentos vinculados às locações';

-- ============================================================
-- 8. HISTÓRICO / AUDITORIA DE LOCAÇÕES
-- ============================================================
CREATE TABLE rental_history (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    rental_id       INT NOT NULL,
    changed_by      INT DEFAULT NULL,
    action          VARCHAR(80) NOT NULL,
    old_data        JSON DEFAULT NULL,
    new_data        JSON DEFAULT NULL,
    note            VARCHAR(255),
    changed_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_rental_history_rental
        FOREIGN KEY (rental_id) REFERENCES rentals(id)
        ON DELETE CASCADE ON UPDATE CASCADE,

    CONSTRAINT fk_rental_history_user
        FOREIGN KEY (changed_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Registro de alterações das locações';

-- ============================================================
-- 9. MANUTENÇÕES DE DISPOSITIVOS
-- ============================================================
CREATE TABLE device_maintenances (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    device_id       INT NOT NULL,
    description     TEXT NOT NULL,
    cost            DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    opened_at       DATE NOT NULL,
    closed_at       DATE DEFAULT NULL,
    status          ENUM('open','closed','cancelled') NOT NULL DEFAULT 'open',
    created_by      INT DEFAULT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_device_maintenances_device
        FOREIGN KEY (device_id) REFERENCES devices(id)
        ON DELETE CASCADE ON UPDATE CASCADE,

    CONSTRAINT fk_device_maintenances_user
        FOREIGN KEY (created_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Histórico de manutenção dos dispositivos';

-- ============================================================
-- 10. CONVERSAS DE CHAT
--     Tabela moderna opcional; mantém chat_messages compatível.
-- ============================================================
CREATE TABLE chat_threads (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT NOT NULL,
    rental_id       INT DEFAULT NULL,
    subject         VARCHAR(180) NOT NULL DEFAULT 'Atendimento ConectaFácil',
    status          ENUM('open','waiting_customer','waiting_admin','closed') NOT NULL DEFAULT 'open',
    priority        ENUM('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
    assigned_to     INT DEFAULT NULL,
    last_message_at DATETIME DEFAULT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_chat_threads_customer
        FOREIGN KEY (customer_id) REFERENCES customers(id)
        ON DELETE CASCADE ON UPDATE CASCADE,

    CONSTRAINT fk_chat_threads_rental
        FOREIGN KEY (rental_id) REFERENCES rentals(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT fk_chat_threads_assigned_to
        FOREIGN KEY (assigned_to) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Conversas agrupadas do chat';

-- ============================================================
-- 11. MENSAGENS DE CHAT
--     Compatível com chat.php e admin_chat.php do projeto enviado.
-- ============================================================
CREATE TABLE chat_messages (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    thread_id       INT DEFAULT NULL,
    rental_id       INT DEFAULT NULL,
    customer_id     INT DEFAULT NULL,
    user_id         INT DEFAULT NULL,
    message         TEXT NOT NULL,
    sender_type     ENUM('customer','admin') NOT NULL,
    message_type    ENUM('text','system','file') NOT NULL DEFAULT 'text',
    attachment_url  VARCHAR(500) DEFAULT NULL,
    is_read         TINYINT(1) NOT NULL DEFAULT 0,
    read_at         DATETIME DEFAULT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_chat_messages_thread
        FOREIGN KEY (thread_id) REFERENCES chat_threads(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT fk_chat_messages_rental
        FOREIGN KEY (rental_id) REFERENCES rentals(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT fk_chat_messages_customer
        FOREIGN KEY (customer_id) REFERENCES customers(id)
        ON DELETE CASCADE ON UPDATE CASCADE,

    CONSTRAINT fk_chat_messages_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Mensagens do chat entre cliente e administrador';

-- ============================================================
-- 12. NOTIFICAÇÕES DO PAINEL
-- ============================================================
CREATE TABLE notifications (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT DEFAULT NULL,
    customer_id     INT DEFAULT NULL,
    rental_id       INT DEFAULT NULL,
    type            ENUM('rental_request','rental_overdue','chat','payment','maintenance','system') NOT NULL DEFAULT 'system',
    title           VARCHAR(180) NOT NULL,
    body            TEXT DEFAULT NULL,
    link_url        VARCHAR(500) DEFAULT NULL,
    is_read         TINYINT(1) NOT NULL DEFAULT 0,
    read_at         DATETIME DEFAULT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_notifications_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE ON UPDATE CASCADE,

    CONSTRAINT fk_notifications_customer
        FOREIGN KEY (customer_id) REFERENCES customers(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT fk_notifications_rental
        FOREIGN KEY (rental_id) REFERENCES rentals(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Notificações para o painel administrativo';

-- ============================================================
-- 13. CONFIGURAÇÕES GERAIS E DE LAYOUT
-- ============================================================
CREATE TABLE settings (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    `key`           VARCHAR(100) NOT NULL UNIQUE,
    value           VARCHAR(800) NOT NULL,
    description     VARCHAR(255),
    group_name      VARCHAR(80) NOT NULL DEFAULT 'geral',
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB COMMENT='Parâmetros configuráveis do sistema';

-- ============================================================
-- 14. EVENTOS GERAIS DO SISTEMA
-- ============================================================
CREATE TABLE activity_logs (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT DEFAULT NULL,
    customer_id     INT DEFAULT NULL,
    entity_type     VARCHAR(80) NOT NULL,
    entity_id       INT DEFAULT NULL,
    action          VARCHAR(80) NOT NULL,
    description     VARCHAR(255) DEFAULT NULL,
    metadata        JSON DEFAULT NULL,
    ip_address      VARCHAR(45) DEFAULT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_activity_logs_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT fk_activity_logs_customer
        FOREIGN KEY (customer_id) REFERENCES customers(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Log geral de atividades para auditoria';

-- ============================================================
-- ÍNDICES DE PERFORMANCE
-- ============================================================
CREATE INDEX idx_users_role_active ON users (role, active);
CREATE INDEX idx_customers_cpf ON customers (cpf);
CREATE INDEX idx_customers_email ON customers (email);
CREATE INDEX idx_devices_status ON devices (status);
CREATE INDEX idx_devices_brand_model ON devices (brand, model);
CREATE INDEX idx_rentals_status ON rentals (status);
CREATE INDEX idx_rentals_dates ON rentals (start_date, planned_end_date, actual_end_date);
CREATE INDEX idx_rentals_customer_name ON rentals (customer_name);
CREATE INDEX idx_rentals_customer_id ON rentals (customer_id);
CREATE INDEX idx_rentals_device_status ON rentals (device_id, status);
CREATE INDEX idx_payments_rental_status ON rental_payments (rental_id, status);
CREATE INDEX idx_chat_threads_customer ON chat_threads (customer_id, status);
CREATE INDEX idx_chat_threads_last_message ON chat_threads (last_message_at);
CREATE INDEX idx_chat_customer ON chat_messages (customer_id);
CREATE INDEX idx_chat_rental ON chat_messages (rental_id);
CREATE INDEX idx_chat_is_read ON chat_messages (is_read);
CREATE INDEX idx_chat_sender_read ON chat_messages (sender_type, is_read);
CREATE INDEX idx_chat_created_at ON chat_messages (created_at);
CREATE INDEX idx_notifications_user_read ON notifications (user_id, is_read);
CREATE INDEX idx_notifications_type_created ON notifications (type, created_at);
CREATE INDEX idx_activity_entity ON activity_logs (entity_type, entity_id);

-- ============================================================
-- VIEWS PARA DASHBOARD MODERNO
-- ============================================================
CREATE OR REPLACE VIEW v_admin_dashboard_summary AS
SELECT
    (SELECT COUNT(*) FROM devices) AS total_devices,
    (SELECT COUNT(*) FROM devices WHERE status = 'available') AS devices_available,
    (SELECT COUNT(*) FROM devices WHERE status = 'rented') AS devices_rented,
    (SELECT COUNT(*) FROM devices WHERE status = 'maintenance') AS devices_maintenance,
    (SELECT COUNT(*) FROM rentals WHERE status = 'pending') AS rental_requests_pending,
    (SELECT COUNT(*) FROM rentals WHERE status = 'active') AS rentals_active,
    (SELECT COUNT(*) FROM rentals WHERE status = 'active' AND planned_end_date < CURDATE()) AS rentals_overdue,
    (SELECT COUNT(*) FROM chat_messages WHERE sender_type = 'customer' AND is_read = 0) AS unread_chat_messages,
    (SELECT COALESCE(SUM(final_value), 0) FROM rentals WHERE status = 'finished' AND MONTH(actual_end_date) = MONTH(CURDATE()) AND YEAR(actual_end_date) = YEAR(CURDATE())) AS revenue_current_month;

CREATE OR REPLACE VIEW v_chat_inbox AS
SELECT
    c.id AS customer_id,
    c.name AS customer_name,
    c.phone,
    c.email,
    MAX(cm.created_at) AS last_message_at,
    SUM(CASE WHEN cm.sender_type = 'customer' AND cm.is_read = 0 THEN 1 ELSE 0 END) AS unread_count,
    COUNT(cm.id) AS total_messages
FROM customers c
JOIN chat_messages cm ON cm.customer_id = c.id
GROUP BY c.id, c.name, c.phone, c.email;

CREATE OR REPLACE VIEW v_rentals_overview AS
SELECT
    r.id,
    r.status,
    r.customer_name,
    r.start_date,
    r.planned_end_date,
    r.actual_end_date,
    r.base_value,
    r.final_value,
    r.payment_status,
    d.brand,
    d.model,
    d.imei,
    c.phone AS customer_phone,
    c.email AS customer_email,
    CASE
        WHEN r.status = 'active' AND r.planned_end_date < CURDATE() THEN 1
        ELSE 0
    END AS is_overdue
FROM rentals r
JOIN devices d ON d.id = r.device_id
LEFT JOIN customers c ON c.id = r.customer_id;

-- ============================================================
-- TRIGGERS PARA MANTER DISPOSITIVOS FUNCIONAIS
-- ============================================================
DELIMITER $$

CREATE TRIGGER trg_rentals_after_insert
AFTER INSERT ON rentals
FOR EACH ROW
BEGIN
    IF NEW.status = 'active' THEN
        UPDATE devices SET status = 'rented' WHERE id = NEW.device_id;
    END IF;
END$$

CREATE TRIGGER trg_rentals_after_update
AFTER UPDATE ON rentals
FOR EACH ROW
BEGIN
    IF NEW.status = 'active' AND OLD.status <> 'active' THEN
        UPDATE devices SET status = 'rented' WHERE id = NEW.device_id;
    END IF;

    IF OLD.status = 'active' AND NEW.status IN ('finished','cancelled') THEN
        IF NOT EXISTS (
            SELECT 1 FROM rentals
            WHERE device_id = NEW.device_id
              AND status = 'active'
              AND id <> NEW.id
        ) THEN
            UPDATE devices SET status = 'available' WHERE id = NEW.device_id;
        END IF;
    END IF;
END$$

CREATE TRIGGER trg_chat_messages_after_insert
AFTER INSERT ON chat_messages
FOR EACH ROW
BEGIN
    IF NEW.thread_id IS NOT NULL THEN
        UPDATE chat_threads
           SET last_message_at = NEW.created_at,
               status = CASE
                    WHEN NEW.sender_type = 'customer' THEN 'waiting_admin'
                    WHEN NEW.sender_type = 'admin' THEN 'waiting_customer'
                    ELSE status
               END
         WHERE id = NEW.thread_id;
    END IF;
END$$

DELIMITER ;

-- ============================================================
-- DADOS INICIAIS
-- ============================================================

INSERT INTO users (name, email, password, role, active, avatar_url, phone) VALUES
('Administrador', 'admin@conectafacil.com', 'admin123', 'admin', 1, NULL, '(11) 99999-9999'),
('Operador', 'operador@conectafacil.com', 'operador123', 'operador', 1, NULL, '(11) 98888-8888');

INSERT INTO user_preferences (user_id, theme_mode, sidebar_state, accent_color, dashboard_layout) VALUES
(1, 'light', 'expanded', '#2563eb', JSON_OBJECT('cards', JSON_ARRAY('pending','active','revenue','chat'), 'density', 'comfortable')),
(2, 'light', 'expanded', '#2563eb', JSON_OBJECT('cards', JSON_ARRAY('active','maintenance','chat'), 'density', 'comfortable'));

INSERT INTO device_categories (name, description, icon, sort_order) VALUES
('Smartphone', 'Celulares e smartphones para locação', 'bi-phone', 1),
('Tablet', 'Tablets e iPads', 'bi-tablet', 2),
('Notebook', 'Laptops e notebooks', 'bi-laptop', 3),
('Roteador', 'Roteadores, modens e internet portátil', 'bi-router', 4),
('Câmera', 'Câmeras e equipamentos audiovisuais', 'bi-camera', 5),
('Console', 'Consoles de videogame e acessórios', 'bi-controller', 6);

INSERT INTO customers (name, cpf, phone, email, city, state, notes) VALUES
('João Silva', '111.111.111-11', '(11) 91111-1111', 'joao@email.com', 'São Paulo', 'SP', 'Cliente de exemplo'),
('Maria Souza', '222.222.222-22', '(11) 92222-2222', 'maria@email.com', 'São Paulo', 'SP', 'Cliente de exemplo'),
('Carlos Lima', '333.333.333-33', '(11) 93333-3333', 'carlos@email.com', 'Guarulhos', 'SP', 'Cliente de exemplo');

INSERT INTO devices (category_id, brand, model, imei, serial_no, daily_rate, replacement_value, status, color, storage_gb, ram_gb, condition_in, battery_health, photo_url, notes) VALUES
(1, 'Apple', 'iPhone 15 Pro', '111222333444555', 'APL15PRO001', 65.00, 7500.00, 'available', 'Titânio', 256, 8, 'novo', 100, 'assets/images/iphone15pro.png', 'Bateria 100%'),
(1, 'Apple', 'iPhone 15', '222333444555666', 'APL15002', 50.00, 5500.00, 'available', 'Azul', 128, 6, 'bom', 98, 'assets/images/iphone15.png', 'Sem riscos'),
(1, 'Apple', 'iPhone 13', '333444555666777', 'APL13003', 35.00, 3500.00, 'available', 'Rosa', 128, 4, 'bom', 91, 'assets/images/iphone13.png', 'Custo benefício'),
(1, 'Samsung', 'Galaxy S24', '444555666777888', 'SMS24004', 55.00, 5200.00, 'available', 'Cinza', 256, 8, 'novo', 100, 'assets/images/s24.webp', 'Último lançamento'),
(1, 'Samsung', 'Galaxy S23 Ultra', '555666777888999', 'SMS23U005', 45.00, 4300.00, 'available', 'Verde', 256, 12, 'bom', 95, 'assets/images/s23ultra.webp', 'Câmera avançada'),
(3, 'Apple', 'MacBook Pro M3', '666777888999000', 'MBPM3006', 120.00, 16000.00, 'available', 'Cinza', 512, 18, 'novo', NULL, 'assets/images/macbookpro.png', 'Chip M3 Max'),
(3, 'Apple', 'MacBook Air', '777888999000111', 'MBA007', 80.00, 9000.00, 'available', 'Dourado', 256, 8, 'bom', NULL, 'assets/images/laptop.png', 'Super leve'),
(2, 'Apple', 'iPad Pro M2', '888999000111222', 'IPADM2008', 55.00, 7800.00, 'available', 'Prata', 256, 8, 'novo', 100, 'assets/images/ipadpro.jpg', 'Tela 12.9 polegadas'),
(6, 'Sony', 'PlayStation 5', '999000111222333', 'PS5009', 40.00, 4200.00, 'available', 'Branco', 825, 16, 'novo', NULL, 'assets/images/ps5.png', 'Com 2 controles'),
(3, 'Dell', 'Inspiron 15', '000111222333444', 'DELL010', 30.00, 3800.00, 'available', 'Prata', 512, 16, 'bom', NULL, 'assets/images/macbookalt.png', 'Core i7, 16GB RAM'),
(1, 'Apple', 'iPhone 15 Pro Max', '121212121212121', 'APL15PM011', 75.00, 8500.00, 'available', 'Preto', 512, 8, 'novo', 100, 'assets/images/iphone15side.png', 'Modelo premium');

INSERT INTO rentals (device_id, customer_id, customer_name, start_date, planned_end_date, status, daily_rate_snap, base_value, created_by, notes) VALUES
(1, 1, 'João Silva', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 7 DAY), 'pending', 65.00, 455.00, NULL, 'Solicitação pública aguardando aprovação'),
(4, 2, 'Maria Souza', DATE_SUB(CURDATE(), INTERVAL 2 DAY), DATE_ADD(CURDATE(), INTERVAL 5 DAY), 'active', 55.00, 385.00, 1, 'Locação ativa de exemplo');

INSERT INTO rental_history (rental_id, changed_by, action, note) VALUES
(1, NULL, 'created', 'Solicitação criada pelo cliente'),
(2, 1, 'created', 'Locação criada pelo administrador');

INSERT INTO chat_threads (customer_id, rental_id, subject, status, priority, assigned_to, last_message_at) VALUES
(1, 1, 'Dúvida sobre reserva do iPhone 15 Pro', 'waiting_admin', 'normal', 1, NOW()),
(2, 2, 'Acompanhamento de locação ativa', 'waiting_customer', 'normal', 1, NOW());

INSERT INTO chat_messages (thread_id, rental_id, customer_id, user_id, message, sender_type, is_read, created_at) VALUES
(1, 1, 1, NULL, 'Olá, quero confirmar se minha solicitação foi recebida.', 'customer', 0, DATE_SUB(NOW(), INTERVAL 20 MINUTE)),
(2, 2, 2, 1, 'Olá, Maria. Sua locação está ativa. Qualquer dúvida estamos à disposição.', 'admin', 1, DATE_SUB(NOW(), INTERVAL 10 MINUTE));

INSERT INTO notifications (user_id, customer_id, rental_id, type, title, body, link_url, is_read) VALUES
(1, 1, 1, 'rental_request', 'Nova solicitação de aluguel', 'João Silva solicitou a locação de um iPhone 15 Pro.', 'rental_requests.php', 0),
(1, 1, 1, 'chat', 'Nova mensagem no chat', 'João Silva enviou uma mensagem aguardando resposta.', 'admin_chat.php?customer_id=1', 0);

INSERT INTO settings (`key`, value, description, group_name) VALUES
('company_name', 'ConectaFácil', 'Nome da empresa exibido no sistema', 'empresa'),
('company_phone', '(11) 99999-9999', 'Telefone de contato', 'empresa'),
('company_email', 'contato@empresa.com', 'E-mail de contato', 'empresa'),
('company_address', 'São Paulo - SP', 'Endereço resumido da empresa', 'empresa'),
('late_fee_pct', '10', 'Percentual de multa por atraso sobre a diária', 'financeiro'),
('damage_multiplier', '5', 'Multiplicador de dias para cálculo de dano', 'financeiro'),
('damage_pct', '20', 'Percentual de taxa de dano', 'financeiro'),
('max_rental_days', '30', 'Prazo máximo permitido para locação em dias', 'operacao'),
('min_rental_days', '1', 'Prazo mínimo de locação em dias', 'operacao'),
('theme_primary_color', '#2563eb', 'Cor principal do layout moderno', 'layout'),
('theme_secondary_color', '#7c3aed', 'Cor secundária do layout moderno', 'layout'),
('theme_background', '#f8fafc', 'Cor de fundo padrão', 'layout'),
('dashboard_refresh_seconds', '30', 'Intervalo sugerido para atualizar indicadores do dashboard', 'dashboard'),
('chat_enabled', '1', 'Ativa ou desativa o chat público', 'chat'),
('chat_welcome_message', 'Olá! Como podemos ajudar?', 'Mensagem inicial do chat', 'chat'),
('chat_business_hours', 'Segunda a sexta, das 09h às 18h', 'Horário de atendimento exibido no chat', 'chat');

INSERT INTO activity_logs (user_id, entity_type, entity_id, action, description, metadata) VALUES
(1, 'system', NULL, 'database_seed', 'Banco completo modernizado instalado com sucesso.', JSON_OBJECT('version', '2026.05', 'module', 'admin_chat_layout'));

-- ============================================================
-- RESUMO DO BANCO CRIADO
-- ============================================================
--  users                  -> login e permissões do painel
--  user_preferences       -> preferências visuais do dashboard/admin
--  customers              -> cadastro dos clientes
--  device_categories      -> categorias dos dispositivos
--  devices                -> aparelhos disponíveis, alugados e manutenção
--  rentals                -> solicitações pendentes, locações ativas e finalizadas
--  rental_payments        -> pagamentos das locações
--  rental_history         -> auditoria das locações
--  device_maintenances    -> manutenção de aparelhos
--  chat_threads           -> conversas modernas agrupadas
--  chat_messages          -> mensagens compatíveis com o chat atual
--  notifications          -> avisos do painel admin
--  settings               -> configurações gerais, layout, dashboard e chat
--  activity_logs          -> auditoria geral
--
--  Views:
--  v_admin_dashboard_summary, v_chat_inbox, v_rentals_overview
--
--  Credenciais iniciais:
--  Admin:    admin@conectafacil.com    / admin123
--  Operador: operador@conectafacil.com / operador123
-- ============================================================

<?php
require_once 'includes/db.php';
session_start();

$db = getDB();
$customer_id = $_GET['customer_id'] ?? null;
$rental_id = $_GET['rental_id'] ?? null;

// Se for POST, salvar mensagem
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = trim($_POST['message'] ?? '');
    $sender_type = $_POST['sender_type'] ?? 'customer';
    $user_id = null;
    
    if (!$message) {
        $_SESSION['chat_error'] = 'Mensagem não pode estar vazia.';
    } else {
        try {
            // Criar ou obter thread de chat
            $stmt = $db->prepare("SELECT id FROM chat_threads WHERE customer_id = ? AND (rental_id = ? OR rental_id IS NULL)");
            $stmt->execute([$customer_id, $rental_id]);
            $thread_id = $stmt->fetchColumn();

            if (!$thread_id) {
                $stmt = $db->prepare("INSERT INTO chat_threads (customer_id, rental_id, subject, status) VALUES (?, ?, ?, 'waiting_admin')");
                $stmt->execute([$customer_id, $rental_id, 'Atendimento ConectaFácil']);
                $thread_id = $db->lastInsertId();
            }

            $stmt = $db->prepare("
                INSERT INTO chat_messages (thread_id, rental_id, customer_id, user_id, message, sender_type)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$thread_id, $rental_id, $customer_id, $user_id, $message, $sender_type]);
            $_SESSION['chat_success'] = 'Mensagem enviada!';
        } catch (Exception $e) {
            $_SESSION['chat_error'] = 'Erro ao enviar: ' . $e->getMessage();
        }
    }
    
    header('Location: chat.php?customer_id=' . $customer_id . ($rental_id ? '&rental_id=' . $rental_id : ''));
    exit;
}

// Buscar mensagens
$messages = [];
if ($customer_id) {
    $sql = "SELECT * FROM chat_messages WHERE customer_id = ?";
    $params = [$customer_id];
    
    if ($rental_id) {
        $sql .= " AND rental_id = ?";
        $params[] = $rental_id;
    }
    
    $sql .= " ORDER BY created_at ASC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $messages = $stmt->fetchAll();
}

$error = $_SESSION['chat_error'] ?? null;
$success = $_SESSION['chat_success'] ?? null;
unset($_SESSION['chat_error'], $_SESSION['chat_success']);
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chat — ConectaFácil</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="bg-body">

<div class="container py-6">
  <a href="index.php" class="btn btn-secondary btn-sm mb-4">
    <i class="bi bi-arrow-left"></i> Voltar
  </a>

  <div class="chat-container">
    <div class="chat-header">
      <h2 class="text-light mb-0">💬 Chat com ConectaFácil</h2>
      <i class="bi bi-chat-dots text-2xl"></i>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-danger mx-4 mt-3">
      <i class="bi bi-exclamation-triangle-fill"></i> <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <?php if ($success): ?>
    <div class="alert alert-success mx-4 mt-3">
      <i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>

    <div class="chat-messages">
      <?php if (empty($messages)): ?>
        <div class="text-center text-muted m-auto">
          <i class="bi bi-chat-left-text text-4xl mb-4"></i>
          <p>Nenhuma mensagem ainda. Comece uma conversa!</p>
        </div>
      <?php else: ?>
        <?php foreach ($messages as $msg): ?>
          <div class="message <?= $msg['sender_type'] === 'customer' ? 'customer' : 'admin' ?>">
            <div>
              <div class="message-bubble">
                <?= htmlspecialchars($msg['message']) ?>
              </div>
              <div class="message-time">
                <?= date('H:i', strtotime($msg['created_at'])) ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <form method="POST" class="chat-input-area">
      <input type="hidden" name="customer_id" value="<?= htmlspecialchars($customer_id) ?>">
      <input type="hidden" name="rental_id" value="<?= htmlspecialchars($rental_id) ?>">
      <input type="hidden" name="sender_type" value="customer">
      <input type="text" name="message" placeholder="Digite sua mensagem..." required autofocus>
      <button type="submit" class="btn btn-primary"><i class="bi bi-send"></i> Enviar</button>
    </form>
  </div>
</div>

<script>
  // Auto-scroll para a última mensagem
  const chatMessages = document.querySelector('.chat-messages');
  if (chatMessages) {
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }
</script>

</body>
</html>

-- ============================================================
-- Tabela de Chat Cliente-Admin
-- ============================================================
CREATE TABLE IF NOT EXISTS chat_messages (
    id          INT            AUTO_INCREMENT PRIMARY KEY,
    rental_id   INT,                         -- Vinculado a uma locação (opcional)
    customer_id INT,                         -- Cliente que enviou
    user_id     INT,                         -- Admin que respondeu (NULL = cliente)
    message     TEXT           NOT NULL,
    sender_type ENUM('customer','admin')     NOT NULL,
    is_read     TINYINT(1)     DEFAULT 0,
    created_at  TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_chat_rental
        FOREIGN KEY (rental_id) REFERENCES rentals(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    
    CONSTRAINT fk_chat_customer
        FOREIGN KEY (customer_id) REFERENCES customers(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    
    CONSTRAINT fk_chat_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Mensagens de chat entre cliente e administrador';

CREATE INDEX idx_chat_customer ON chat_messages (customer_id);
CREATE INDEX idx_chat_rental ON chat_messages (rental_id);
CREATE INDEX idx_chat_is_read ON chat_messages (is_read);

<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/layout.php';
requireLogin();

$db = getDB();
$customers = $db->query("SELECT * FROM customers ORDER BY name")->fetchAll();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$actions = '<button class="btn btn-primary btn-sm" onclick="alert(\'Funcionalidade de adicionar cliente em breve!\')">
  <i class="bi bi-person-plus"></i> Novo Cliente
</button>';

renderPageStart('Clientes', 'customers.php', $actions);
?>

<?= flashHtml($flash) ?>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>CPF</th>
                    <th>E-mail</th>
                    <th>Telefone</th>
                    <th>Cidade/UF</th>
                    <th>Status</th>
                    <th class="text-right">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$customers): ?>
                <tr><td colspan="7" class="text-center py-10 text-muted">Nenhum cliente cadastrado.</td></tr>
                <?php endif; ?>
                <?php foreach ($customers as $c): ?>
                <tr>
                    <td><strong class="text-text-900"><?= htmlspecialchars($c['name']) ?></strong></td>
                    <td><?= htmlspecialchars($c['cpf'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($c['email'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($c['phone'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($c['city'] . '/' . $c['state']) ?></td>
                    <td>
                        <span class="badge <?= $c['active'] ? 'badge-green' : 'badge-gray' ?>">
                            <?= $c['active'] ? 'Ativo' : 'Inativo' ?>
                        </span>
                    </td>
                    <td class="text-right">
                        <div class="flex justify-end gap-2">
                            <a href="admin_chat.php?customer_id=<?= $c['id'] ?>" class="btn btn-secondary btn-sm" title="Conversar">
                                <i class="bi bi-chat-dots"></i>
                            </a>
                            <button class="btn btn-secondary btn-sm" title="Editar">
                                <i class="bi bi-pencil"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php renderPageEnd(); ?>

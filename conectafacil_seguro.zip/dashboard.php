<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/layout.php';
requireLogin();

$db = getDB();

// Usar a nova view para obter todos os dados do dashboard de uma vez
$summary = $db->query("SELECT * FROM v_admin_dashboard_summary")->fetch();

$recentRentals = $db->query("
    SELECT r.id, r.customer_name, r.start_date, r.planned_end_date, r.status,
           d.brand, d.model
    FROM rentals r
    JOIN devices d ON d.id = r.device_id
    ORDER BY r.created_at DESC
    LIMIT 8
")->fetchAll();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
$today = new DateTimeImmutable('today');

renderPageStart('Dashboard', 'dashboard.php');
?>

<?= flashHtml($flash) ?>

<!-- Stat Grid -->
<div class="stats-grid">

  <div class="stat-card">
    <div class="stat-icon bg-primary">
      <i class="bi bi-phone"></i>
    </div>
    <div class="stat-info">
      <h3><?= $summary['total_devices'] ?></h3>
      <p>Total Dispositivos</p>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-icon bg-success">
      <i class="bi bi-check-circle"></i>
    </div>
    <div class="stat-info">
      <h3><?= $summary['devices_available'] ?></h3>
      <p>Disponíveis</p>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-icon bg-danger">
      <i class="bi bi-phone-vibrate"></i>
    </div>
    <div class="stat-info">
      <h3><?= $summary['devices_rented'] ?></h3>
      <p>Alugados</p>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-icon bg-info">
      <i class="bi bi-clipboard-check"></i>
    </div>
    <div class="stat-info">
      <h3><?= $summary['rentals_active'] ?></h3>
      <p>Locações Ativas</p>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-icon bg-warning">
      <i class="bi bi-exclamation-triangle"></i>
    </div>
    <div class="stat-info">
      <h3><?= $summary['rentals_overdue'] ?></h3>
      <p>Em Atraso</p>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-icon bg-success">
      <i class="bi bi-cash-stack"></i>
    </div>
    <div class="stat-info">
      <h3>R$ <?= number_format($summary['revenue_current_month'], 2, ',', '.') ?></h3>
      <p>Receita este mês</p>
    </div>
  </div>

</div>

<!-- Recent Rentals -->
<div class="card">
  <div class="card-header">
    <h2 class="card-title">Locações Recentes</h2>
    <a href="rentals.php" class="btn btn-secondary btn-sm">
      Ver todas <i class="bi bi-arrow-right"></i>
    </a>
  </div>

  <div class="table-responsive">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Cliente</th>
          <th>Dispositivo</th>
          <th>Início</th>
          <th>Devolução Prev.</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$recentRentals): ?>
        <tr><td colspan="6"><div class="text-center text-muted py-4"><i class="bi bi-clipboard-x text-2xl mb-2"></i><p>Nenhuma locação registrada.</p></div></td></tr>
        <?php endif; ?>
        <?php foreach ($recentRentals as $r):
          $dueDate = new DateTimeImmutable($r['planned_end_date']);
          $isLate  = $r['status'] === 'active' && $today > $dueDate;
        ?>
        <tr>
          <td>#<?= $r['id'] ?></td>
          <td class="font-semibold"><?= htmlspecialchars($r['customer_name']) ?></td>
          <td><?= htmlspecialchars($r['brand'] . ' ' . $r['model']) ?></td>
          <td><?= date('d/m/Y', strtotime($r['start_date'])) ?></td>
          <td>
            <?= date('d/m/Y', strtotime($r['planned_end_date'])) ?>
            <?php if ($isLate): ?><span class="badge badge-red ml-2"><span class="badge-dot"></span>Atraso</span><?php endif; ?>
          </td>
          <td>
            <?php if ($r['status'] === 'active'): ?>
              <span class="badge badge-blue"><span class="badge-dot"></span>Ativa</span>
            <?php elseif ($r['status'] === 'pending'): ?>
              <span class="badge badge-amber"><span class="badge-dot"></span>Pendente</span>
            <?php elseif ($r['status'] === 'cancelled'): ?>
              <span class="badge badge-red"><span class="badge-dot"></span>Cancelada</span>
            <?php else: ?>
              <span class="badge badge-gray"><span class="badge-dot"></span>Finalizada</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php renderPageEnd(); ?>

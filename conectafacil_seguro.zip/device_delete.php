<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: devices.php');
    exit;
}

$id = (int)($_POST['id'] ?? 0);

if ($id <= 0) {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'ID inválido.'];
    header('Location: devices.php');
    exit;
}

try {
    $db   = getDB();
    $stmt = $db->prepare("DELETE FROM devices WHERE id = ? AND status != 'rented'");
    $stmt->execute([$id]);

    $_SESSION['flash'] = $stmt->rowCount() > 0
        ? ['type' => 'success', 'msg' => 'Dispositivo excluído com sucesso.']
        : ['type' => 'warning', 'msg' => 'Não é possível excluir dispositivo alugado ou inexistente.'];
} catch (PDOException $e) {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Erro ao excluir: ' . $e->getMessage()];
}

header('Location: devices.php');
exit;

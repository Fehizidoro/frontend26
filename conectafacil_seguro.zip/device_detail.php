<?php
require_once 'includes/db.php';
session_start();

$db = getDB();
$device_id = $_GET['id'] ?? null;

if (!$device_id) {
    header('Location: index.php');
    exit;
}

// Buscar dispositivo
$stmt = $db->prepare("
    SELECT d.*, c.name as category_name 
    FROM devices d 
    LEFT JOIN device_categories c ON d.category_id = c.id 
    WHERE d.id = ? AND d.status = 'available'
");
$stmt->execute([$device_id]);
$device = $stmt->fetch();

if (!$device) {
    header('Location: index.php');
    exit;
}

// Mapeamento de imagens
$image_map = [
    'iPhone 15 Pro' => 'assets/images/iphone15pro.png',
    'iPhone 15' => 'assets/images/iphone15side.png',
    'iPhone 13' => 'assets/images/iphone13.png',
    'Galaxy S24' => 'assets/images/s24.webp',
    'Galaxy S23' => 'assets/images/s23ultra.webp',
    'MacBook Pro' => 'assets/images/macbookpro.png',
    'MacBook' => 'assets/images/macbookalt.png',
    'iPad Pro' => 'assets/images/ipadpro.jpg',
    'PlayStation 5' => 'assets/images/ps5.png',
    'Inspiron' => 'assets/images/laptop.png',
];

function getDeviceImage($model, $db_url) {
    global $image_map;
    if (!empty($db_url)) return $db_url;
    foreach ($image_map as $key => $path) {
        if (stripos($model, $key) !== false) return $path;
    }
    return '';
}

$img = getDeviceImage($device['brand'] . ' ' . $device['model'], $device['photo_url']);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $cpf = trim($_POST['cpf'] ?? '');
    $start_date = trim($_POST['start_date'] ?? '');
    $end_date = trim($_POST['end_date'] ?? '');
    
    if (!$name || !$email || !$phone || !$cpf || !$start_date || !$end_date) {
        $error = 'Por favor, preencha todos os campos obrigatórios.';
    } else {
        try {
            // Logica simplificada para demonstração
            $customer_stmt = $db->prepare("SELECT id FROM customers WHERE cpf = ?");
            $customer_stmt->execute([$cpf]);
            $customer = $customer_stmt->fetch();
            
            if (!$customer) {
                $insert_customer = $db->prepare("INSERT INTO customers (name, cpf, phone, email) VALUES (?, ?, ?, ?)");
                $insert_customer->execute([$name, $cpf, $phone, $email]);
                $customer_id = $db->lastInsertId();
            } else {
                $customer_id = $customer['id'];
            }
            
            $days = (strtotime($end_date) - strtotime($start_date)) / 86400;
            $base_value = $device['daily_rate'] * max(1, $days);
            
            $insert_rental = $db->prepare("
                INSERT INTO rentals 
                (device_id, customer_id, customer_name, start_date, planned_end_date, status, daily_rate_snap, base_value) 
                VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)
            ");
            $insert_rental->execute([$device['id'], $customer_id, $name, $start_date, $end_date, $device['daily_rate'], $base_value]);
            
            $success = 'Sua solicitação foi enviada! Analisaremos os dados e entraremos em contato em breve.';
        } catch (Exception $e) {
            $error = 'Erro ao processar: ' . $e->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Reservar <?= htmlspecialchars($device['model']) ?> — ConectaFácil</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="assets/style.css">
  <style>
    .detail-grid {
      display: grid;
      grid-template-columns: 1.2fr 1fr;
      gap: 60px;
      padding: 120px 40px;
      max-width: 1400px;
      margin: 0 auto;
    }
    .product-visual {
      background: white;
      border-radius: 40px;
      padding: 60px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: sticky;
      top: 120px;
      height: fit-content;
      box-shadow: var(--shadow-premium);
    }
    .product-visual img { width: 100%; max-width: 500px; filter: drop-shadow(0 20px 40px rgba(0,0,0,0.1)); }

    .booking-form {
      background: white;
      border-radius: 40px;
      padding: 50px;
      box-shadow: var(--shadow-premium);
    }
    
    .spec-tag {
      background: #f1f5f9;
      padding: 8px 16px;
      border-radius: 12px;
      font-size: 0.85rem;
      font-weight: 700;
      color: var(--text-600);
    }

    .price-card {
      background: var(--brand-950);
      color: white;
      padding: 30px;
      border-radius: 24px;
      margin-bottom: 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    @media (max-width: 1024px) {
      .detail-grid { grid-template-columns: 1fr; padding: 40px 20px; }
      .product-visual { position: static; }
    }
  </style>
</head>
<body>

<nav class="nav-premium scrolled">
  <a href="index.php" class="site-logo">
    <div class="sidebar-logo"><i class="bi bi-phone-vibrate" style="color: white; font-size: 20px;"></i></div>
    <span style="font-family: 'Sora'; font-weight: 800; font-size: 1.5rem; color: var(--brand-950);">ConectaFácil</span>
  </a>
  <a href="index.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Voltar ao Catálogo</a>
</nav>

<main class="detail-grid">
  <div class="product-visual">
    <?php if ($img): ?>
      <img src="<?= $img ?>" alt="<?= htmlspecialchars($device['model']) ?>">
    <?php else: ?>
      <i class="bi bi-phone" style="font-size: 200px; color: #cbd5e1;"></i>
    <?php endif; ?>
  </div>

  <div class="booking-content">
    <div style="margin-bottom: 40px;">
      <span style="color: var(--brand-accent); font-weight: 800; text-transform: uppercase; letter-spacing: 2px;"><?= htmlspecialchars($device['brand']) ?></span>
      <h1 style="font-size: 3.5rem; color: var(--brand-950); margin-bottom: 16px;"><?= htmlspecialchars($device['model']) ?></h1>
      <div style="display: flex; gap: 12px; flex-wrap: wrap;">
        <span class="spec-tag"><i class="bi bi-cpu"></i> <?= $device['storage_gb'] ?>GB</span>
        <span class="spec-tag"><i class="bi bi-palette"></i> <?= htmlspecialchars($device['color']) ?></span>
        <span class="spec-tag"><i class="bi bi-shield-check"></i> Revisado</span>
      </div>
    </div>

    <div class="price-card">
      <div>
        <p style="color: var(--text-400); font-size: 0.9rem; font-weight: 700;">VALOR DA DIÁRIA</p>
        <h2 style="font-size: 2.5rem; margin: 0;">R$ <?= number_format($device['daily_rate'], 2, ',', '.') ?></h2>
      </div>
      <i class="bi bi-lightning-charge-fill" style="font-size: 3rem; color: var(--brand-accent); opacity: 0.5;"></i>
    </div>

    <div class="booking-form">
      <h3 style="margin-bottom: 30px; font-size: 1.8rem;">Solicitar Reserva</h3>
      
      <?php if ($error): ?>
        <div style="background: #fee2e2; color: #991b1b; padding: 20px; border-radius: 16px; margin-bottom: 24px;">
          <i class="bi bi-exclamation-triangle-fill"></i> <?= $error ?>
        </div>
      <?php endif; ?>

      <?php if ($success): ?>
        <div style="background: #dcfce7; color: #166534; padding: 20px; border-radius: 16px; margin-bottom: 24px;">
          <i class="bi bi-check-circle-fill"></i> <?= $success ?>
        </div>
      <?php endif; ?>

      <form method="POST">
        <div class="form-group">
          <label class="form-label">Nome Completo</label>
          <input type="text" name="name" class="form-control" style="color: #0f172a; background: #f8fafc; border: 1px solid #e2e8f0;" required>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
          <div class="form-group">
            <label class="form-label">E-mail</label>
            <input type="email" name="email" class="form-control" style="color: #0f172a; background: #f8fafc; border: 1px solid #e2e8f0;" required>
          </div>
          <div class="form-group">
            <label class="form-label">WhatsApp</label>
            <input type="tel" name="phone" class="form-control" style="color: #0f172a; background: #f8fafc; border: 1px solid #e2e8f0;" placeholder="(00) 00000-0000" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">CPF</label>
          <input type="text" name="cpf" class="form-control" style="color: #0f172a; background: #f8fafc; border: 1px solid #e2e8f0;" placeholder="000.000.000-00" required>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 32px;">
          <div class="form-group">
            <label class="form-label">Data de Início</label>
            <input type="date" name="start_date" class="form-control" style="color: #0f172a; background: #f8fafc; border: 1px solid #e2e8f0;" required>
          </div>
          <div class="form-group">
            <label class="form-label">Data de Término</label>
            <input type="date" name="end_date" class="form-control" style="color: #0f172a; background: #f8fafc; border: 1px solid #e2e8f0;" required>
          </div>
        </div>
        
        <button type="submit" class="btn btn-primary" style="width: 100%; padding: 20px; font-size: 1.1rem; justify-content: center;">
          Confirmar Solicitação <i class="bi bi-arrow-right"></i>
        </button>
      </form>
    </div>
  </div>
</main>

</body>
</html>

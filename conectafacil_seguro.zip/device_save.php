<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: devices.php');
    exit;
}

$id                = trim($_POST['id'] ?? '');
$category_id       = trim($_POST['category_id'] ?? '') ?: null;
$brand             = trim($_POST['brand'] ?? '');
$model             = trim($_POST['model'] ?? '');
$imei              = trim($_POST['imei'] ?? '') ?: null;
$serial_no         = trim($_POST['serial_no'] ?? '') ?: null;
$color             = trim($_POST['color'] ?? '') ?: null;
$storage_gb        = trim($_POST['storage_gb'] ?? '') ?: null;
$ram_gb            = trim($_POST['ram_gb'] ?? '') ?: null;
$battery_health    = trim($_POST['battery_health'] ?? '') ?: null;
$daily_rate        = (float)($_POST['daily_rate'] ?? 0);
$replacement_value = trim($_POST['replacement_value'] ?? '') ?: null;
$condition_in      = $_POST['condition_in'] ?? 'bom';
$status            = $_POST['status'] ?? 'available';
$photo_url         = trim($_POST['photo_url'] ?? '') ?: null;
$notes             = trim($_POST['notes'] ?? '') ?: null;

if ($brand === '' || $model === '' || $daily_rate <= 0) {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Preencha todos os campos obrigatórios (Marca, Modelo, Diária).'];
    header('Location: devices.php');
    exit;
}

try {
    $db = getDB();

    if ($id === '') {
        // INSERT
        $sql = "INSERT INTO devices (category_id, brand, model, imei, serial_no, color, storage_gb, ram_gb, battery_health, daily_rate, replacement_value, condition_in, status, photo_url, notes) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $db->prepare($sql)->execute([
            $category_id, $brand, $model, $imei, $serial_no, $color, $storage_gb, $ram_gb, $battery_health, $daily_rate, $replacement_value, $condition_in, $status, $photo_url, $notes
        ]);

        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Dispositivo criado com sucesso.'];
    } else {
        // UPDATE
        $sql = "UPDATE devices SET 
                category_id = ?, brand = ?, model = ?, imei = ?, serial_no = ?, color = ?, 
                storage_gb = ?, ram_gb = ?, battery_health = ?, daily_rate = ?, 
                replacement_value = ?, condition_in = ?, status = ?, photo_url = ?, notes = ?
                WHERE id = ? AND status != 'rented'";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([
            $category_id, $brand, $model, $imei, $serial_no, $color, $storage_gb, $ram_gb, $battery_health, $daily_rate, $replacement_value, $condition_in, $status, $photo_url, $notes, (int)$id
        ]);

        $_SESSION['flash'] = $stmt->rowCount() > 0
            ? ['type' => 'success', 'msg' => 'Dispositivo atualizado com sucesso.']
            : ['type' => 'warning', 'msg' => 'Nenhuma alteração feita ou dispositivo alugado.'];
    }
} catch (PDOException $e) {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Erro ao salvar: ' . $e->getMessage()];
}

header('Location: devices.php');
exit;

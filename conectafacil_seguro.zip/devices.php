<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/layout.php';
requireLogin();

$db = getDB();

$filter  = $_GET['status'] ?? '';
$allowed = ['available','rented','maintenance'];

$sql    = 'SELECT d.*, dc.name as category_name FROM devices d LEFT JOIN device_categories dc ON d.category_id = dc.id';
$params = [];

if (in_array($filter, $allowed)) {
    $sql    .= ' WHERE d.status = ?';
    $params[] = $filter;
}
$sql .= ' ORDER BY d.brand, d.model';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$devices = $stmt->fetchAll();

$categories = $db->query('SELECT id, name FROM device_categories ORDER BY name')->fetchAll();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$actions = isAdmin()
    ? '<button class="btn btn-primary btn-sm" onclick="openDeviceCreate()">
         <i class="bi bi-plus-lg"></i> Novo Dispositivo
       </button>'
    : '';

renderPageStart('Dispositivos', 'devices.php', $actions);
?>

<?= flashHtml($flash) ?>

<!-- Filter chips -->
<div class="flex gap-2 mb-6">
  <?php foreach (['' => 'Todos', 'available' => 'Disponíveis', 'rented' => 'Alugados', 'maintenance' => 'Manutenção'] as $val => $lbl): ?>
  <a href="devices.php<?= $val ? '?status='.$val : '' ?>" class="badge badge-gray <?= $filter === $val ? 'active' : '' ?>"><?= $lbl ?></a>
  <?php endforeach; ?>
</div>

<!-- Table -->
<div class="card">
  <div class="table-responsive">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Marca / Modelo</th>
          <th>Categoria</th>
          <th>IMEI / Série</th>
          <th>Diária</th>
          <th>Status</th>
          <?php if (isAdmin()): ?><th class="text-right">Ações</th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php if (!$devices): ?>
        <tr><td colspan="7"><div class="text-center text-muted py-4"><i class="bi bi-phone-slash text-2xl mb-2"></i><p>Nenhum dispositivo encontrado.</p></div></td></tr>
        <?php endif; ?>

        <?php foreach ($devices as $d):
          [$badgeClass, $label] = match($d['status']) {
              'available'   => ['badge-green',  'Disponível'],
              'rented'      => ['badge-red',    'Alugado'],
              'maintenance' => ['badge-amber',  'Manutenção'],
              default       => ['badge-gray',  $d['status']],
          };
        ?>
        <tr>
          <td>#<?= $d['id'] ?></td>
          <td>
            <strong class="text-text-900"><?= htmlspecialchars($d['brand']) ?></strong>
            <span class="text-muted"> <?= htmlspecialchars($d['model']) ?></span>
          </td>
          <td><?= htmlspecialchars($d['category_name'] ?? 'N/A') ?></td>
          <td>
            <span class="text-sm text-muted block"><?= htmlspecialchars($d['imei'] ?? '—') ?></span>
            <span class="text-xs text-muted block"><?= htmlspecialchars($d['serial_no'] ?? '—') ?></span>
          </td>
          <td class="font-semibold">R$ <?= number_format($d['daily_rate'], 2, ',', '.') ?></td>
          <td>
            <span class="badge <?= $badgeClass ?>">
              <span class="badge-dot"></span><?= $label ?>
            </span>
          </td>
          <?php if (isAdmin()): ?>
          <td class="text-right">
            <div class="flex justify-end gap-2">
              <button class="btn btn-secondary btn-sm"
                onclick='openDeviceEdit(<?= json_encode($d, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>)'
                <?= $d['status'] === 'rented' ? 'disabled title="Dispositivo alugado"' : '' ?>>
                <i class="bi bi-pencil"></i>
              </button>
              <?php if ($d['status'] !== 'rented'): ?>
              <form method="post" action="device_delete.php"
                    onsubmit="return confirm('Excluir <?= htmlspecialchars($d['brand'].' '.$d['model']) ?>? Esta ação não pode ser desfeita.');">
                <input type="hidden" name="id" value="<?= $d['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm"><i class="bi bi-trash"></i></button>
              </form>
              <?php endif; ?>
            </div>
          </td>
          <?php endif; ?>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php if (isAdmin()): ?>
<!-- Device Modal -->
<div class="modal-overlay" id="deviceModal">
  <div class="modal-box">
    <form method="post" action="device_save.php">
      <div class="modal-header">
        <h2 class="modal-title" id="modalDeviceTitle">Novo Dispositivo</h2>
        <button type="button" class="modal-close" onclick="closeModal('deviceModal')">
          <i class="bi bi-x-lg"></i>
        </button>
      </div>

      <div class="modal-body grid grid-cols-1 md:grid-cols-2 gap-4">
        <input type="hidden" name="id" id="fieldId">

        <div class="form-group">
          <label class="form-label" for="fieldCategory">Categoria <span>*</span></label>
          <select id="fieldCategory" name="category_id" class="form-control" required>
            <option value="">Selecione uma categoria</option>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label" for="fieldBrand">Marca <span>*</span></label>
          <input type="text" id="fieldBrand" name="brand" class="form-control" required placeholder="Samsung">
        </div>

        <div class="form-group">
          <label class="form-label" for="fieldModel">Modelo <span>*</span></label>
          <input type="text" id="fieldModel" name="model" class="form-control" required placeholder="Galaxy S23">
        </div>

        <div class="form-group">
          <label class="form-label" for="fieldImei">IMEI</label>
          <input type="text" id="fieldImei" name="imei" class="form-control" placeholder="15 dígitos">
        </div>

        <div class="form-group">
          <label class="form-label" for="fieldSerialNo">Número de Série</label>
          <input type="text" id="fieldSerialNo" name="serial_no" class="form-control" placeholder="ABC123DEF456">
        </div>

        <div class="form-group">
          <label class="form-label" for="fieldColor">Cor</label>
          <input type="text" id="fieldColor" name="color" class="form-control" placeholder="Preto">
        </div>

        <div class="form-group">
          <label class="form-label" for="fieldStorageGb">Armazenamento (GB)</label>
          <input type="number" id="fieldStorageGb" name="storage_gb" class="form-control" min="0" placeholder="128">
        </div>

        <div class="form-group">
          <label class="form-label" for="fieldRamGb">RAM (GB)</label>
          <input type="number" id="fieldRamGb" name="ram_gb" class="form-control" min="0" placeholder="8">
        </div>

        <div class="form-group">
          <label class="form-label" for="fieldBatteryHealth">Saúde da Bateria (%)</label>
          <input type="number" id="fieldBatteryHealth" name="battery_health" class="form-control" min="0" max="100" placeholder="90">
        </div>

        <div class="form-group">
          <label class="form-label" for="fieldDailyRate">Diária (R$) <span>*</span></label>
          <input type="number" id="fieldDailyRate" name="daily_rate" class="form-control" step="0.01" min="0.01" required placeholder="50.00">
        </div>

        <div class="form-group">
          <label class="form-label" for="fieldReplacementValue">Valor de Reposição (R$)</label>
          <input type="number" id="fieldReplacementValue" name="replacement_value" class="form-control" step="0.01" min="0" placeholder="3500.00">
        </div>

        <div class="form-group">
          <label class="form-label" for="fieldConditionIn">Condição de Entrada <span>*</span></label>
          <select id="fieldConditionIn" name="condition_in" class="form-control" required>
            <option value="novo">Novo</option>
            <option value="bom">Bom</option>
            <option value="regular">Regular</option>
            <option value="ruim">Ruim</option>
          </select>
        </div>

        <div class="form-group md:col-span-2">
          <label class="form-label" for="fieldPhotoUrl">URL da Foto</label>
          <input type="text" id="fieldPhotoUrl" name="photo_url" class="form-control" placeholder="https://exemplo.com/foto.jpg">
        </div>

        <div class="form-group md:col-span-2">
          <label class="form-label" for="fieldNotes">Observações</label>
          <textarea id="fieldNotes" name="notes" class="form-control" placeholder="Informações adicionais…"></textarea>
        </div>

        <div class="form-group">
          <label class="form-label" for="fieldStatus">Status <span>*</span></label>
          <select id="fieldStatus" name="status" class="form-control" required>
            <option value="available">Disponível</option>
            <option value="maintenance">Manutenção</option>
          </select>
        </div>

      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('deviceModal')">Cancelar</button>
        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Salvar</button>
      </div>
    </form>
  </div>
</div>

<script>
  function openDeviceCreate() {
    document.getElementById('modalDeviceTitle').innerText = 'Novo Dispositivo';
    document.getElementById('fieldId').value = '';
    document.getElementById('fieldCategory').value = '';
    document.getElementById('fieldBrand').value = '';
    document.getElementById('fieldModel').value = '';
    document.getElementById('fieldImei').value = '';
    document.getElementById('fieldSerialNo').value = '';
    document.getElementById('fieldColor').value = '';
    document.getElementById('fieldStorageGb').value = '';
    document.getElementById('fieldRamGb').value = '';
    document.getElementById('fieldBatteryHealth').value = '';
    document.getElementById('fieldDailyRate').value = '';
    document.getElementById('fieldReplacementValue').value = '';
    document.getElementById('fieldConditionIn').value = 'bom';
    document.getElementById('fieldPhotoUrl').value = '';
    document.getElementById('fieldNotes').value = '';
    document.getElementById('fieldStatus').value = 'available';
    document.getElementById('deviceModal').classList.add('open');
  }

  function openDeviceEdit(device) {
    document.getElementById('modalDeviceTitle').innerText = 'Editar Dispositivo';
    document.getElementById('fieldId').value = device.id;
    document.getElementById('fieldCategory').value = device.category_id;
    document.getElementById('fieldBrand').value = device.brand;
    document.getElementById('fieldModel').value = device.model;
    document.getElementById('fieldImei').value = device.imei;
    document.getElementById('fieldSerialNo').value = device.serial_no;
    document.getElementById('fieldColor').value = device.color;
    document.getElementById('fieldStorageGb').value = device.storage_gb;
    document.getElementById('fieldRamGb').value = device.ram_gb;
    document.getElementById('fieldBatteryHealth').value = device.battery_health;
    document.getElementById('fieldDailyRate').value = device.daily_rate;
    document.getElementById('fieldReplacementValue').value = device.replacement_value;
    document.getElementById('fieldConditionIn').value = device.condition_in;
    document.getElementById('fieldPhotoUrl').value = device.photo_url;
    document.getElementById('fieldNotes').value = device.notes;
    document.getElementById('fieldStatus').value = device.status;
    document.getElementById('deviceModal').classList.add('open');
  }

  function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('open');
  }
</script>
<?php endif; ?>

<?php renderPageEnd(); ?>

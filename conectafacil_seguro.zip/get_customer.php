<?php
require_once 'includes/db.php';

header('Content-Type: application/json');

$cpf = $_GET['cpf'] ?? null;

if (!$cpf) {
    echo json_encode(['error' => 'CPF não fornecido']);
    exit;
}

try {
    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM customers WHERE cpf = ?");
    $stmt->execute([$cpf]);
    $customer = $stmt->fetch();
    
    if ($customer) {
        echo json_encode(['customer_id' => $customer['id']]);
    } else {
        echo json_encode(['error' => 'Cliente não encontrado']);
    }
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

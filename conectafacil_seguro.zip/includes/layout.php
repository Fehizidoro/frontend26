<?php
function renderHeader(string $title, string $activePage): void {
    $user = currentUser();
    $initials = implode('', array_map(fn($w) => strtoupper($w[0]), array_slice(explode(' ', $user['name']), 0, 2)));
    $roleLabel = $user['role'] === 'admin' ? 'Administrador' : 'Operador';

    $nav = [
        ['href' => 'dashboard.php', 'icon' => 'bi-speedometer2',   'label' => 'Dashboard'],
        ['href' => 'rental_requests.php', 'icon' => 'bi-inbox-check', 'label' => 'Solicitações'],
        ['href' => 'admin_chat.php', 'icon' => 'bi-chat-dots',      'label' => 'Chat'],
        ['href' => 'devices.php',   'icon' => 'bi-phone',           'label' => 'Dispositivos'],
        ['href' => 'rentals.php',   'icon' => 'bi-clipboard-check', 'label' => 'Locações'],
        ['href' => 'customers.php', 'icon' => 'bi-people',          'label' => 'Clientes'],
        ['href' => 'settings.php',  'icon' => 'bi-gear',            'label' => 'Configurações'],
        ['href' => 'index.php',     'icon' => 'bi-globe',           'label' => 'Ver Site'],
    ];
    ?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($title) ?> — ConectaFácil</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="app-wrapper">

  <!-- ── Sidebar ── -->
  <nav id="sidebar">

    <a href="dashboard.php" class="sidebar-brand">
      <div class="sidebar-logo">
        <i class="bi bi-phone-vibrate"></i>
      </div>
      <span class="sidebar-brand-text">
        <span class="sidebar-brand-name">ConectaFácil</span>
        <span class="sidebar-brand-sub">Sistema de Locação</span>
      </span>
    </a>

    <ul class="sidebar-nav">
      <?php foreach ($nav as $item): ?>
      <li>
        <a href="<?= $item['href'] ?>" class="<?= $activePage === $item['href'] ? 'active' : '' ?>">
          <i class="bi <?= $item['icon'] ?>"></i>
          <span><?= $item['label'] ?></span>
        </a>
      </li>
      <?php endforeach; ?>
    </ul>

    <div class="sidebar-footer">
      <div class="avatar"><?= htmlspecialchars($initials) ?></div>
      <div class="user-info">
        <span class="font-bold"><?= htmlspecialchars($user['name']) ?></span>
        <span class="text-muted text-xs"><?= $roleLabel ?></span>
      </div>
      <div class="flex flex-col gap-2 ml-auto">
        <a href="logout.php" class="btn btn-danger btn-sm" title="Sair e ir para o Site">
          <i class="bi bi-power"></i> SAIRRRRRRRRRRR
        </a>
      </div>
    </div>

  </nav>

  <!-- ── Main Content ── -->
  <div id="main-content">

    <header class="page-header">
      <h1 class="page-title"><?= htmlspecialchars($title) ?></h1>
      <div class="page-actions">
        <button id="sidebar-toggle" class="btn btn-secondary btn-sm d-none d-md-inline-flex">
          <i class="bi bi-list"></i>
        </button>
    <?php
}

function renderHeaderActions(): void {
    // placeholder — actions injected inline via page-actions slot
}

function renderHeaderEnd(): void {
    ?>
      </div><!-- .page-actions -->
    </header>
    <?php
}

function renderFooter(): void {
    ?>
  </div><!-- #main-content -->
</div><!-- .app-wrapper -->

<script src="assets/app.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebar-toggle');

    if (sidebar && sidebarToggle) {
      sidebarToggle.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
      });
    }
  });
</script>
</body>
</html>
    <?php
}

/* Shorthand used in pages that inject topbar buttons */
function renderPageStart(string $title, string $activePage, string $actionsHtml = ''): void {
    renderHeader($title, $activePage);
    echo $actionsHtml;
    renderHeaderEnd();
    echo '<div class="page-body">';
    if (isset($_SESSION['flash'])) {
        echo flashHtml($_SESSION['flash']);
        unset($_SESSION['flash']);
    }
}

function renderPageEnd(): void {
    echo '</div>';
    renderFooter();
}

function flashHtml(?array $flash): string {
    if (!$flash) return '';
    $icons = ['success'=>'bi-check-circle-fill','danger'=>'bi-x-circle-fill','warning'=>'bi-exclamation-triangle-fill','info'=>'bi-info-circle-fill'];
    $icon  = $icons[$flash['type']] ?? 'bi-info-circle-fill';
    $msg   = htmlspecialchars($flash['msg']);
    return "<div class=\"alert alert-{$flash['type']}\"><i class=\"bi {$icon}\"></i> {$msg}</div>";
}

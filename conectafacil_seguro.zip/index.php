<?php
require_once 'includes/db.php';
session_start();

$db = getDB();

// Buscar dispositivos disponíveis
$stmt = $db->query("
    SELECT d.*, c.name as category_name 
    FROM devices d 
    LEFT JOIN device_categories c ON d.category_id = c.id 
    WHERE d.status = 'available' 
    ORDER BY d.brand, d.model
");
$devices = $stmt->fetchAll();

// Mapeamento de imagens
$image_map = [
    'iPhone 15 Pro' => 'assets/images/iphone15pro.png',
    'iPhone 15' => 'assets/images/iphone15side.png',
    'iPhone 13' => 'assets/images/iphone13.png',
    'Galaxy S24' => 'assets/images/s24.webp',
    'Galaxy S23' => 'assets/images/s23ultra.webp',
    'MacBook Pro' => 'assets/images/macbookpro.png',
    'MacBook' => 'assets/images/macbookalt.png',
    'iPad Pro' => 'assets/images/ipadpro.jpg',
    'PlayStation 5' => 'assets/images/ps5.png',
    'Inspiron' => 'assets/images/laptop.png',
];

function getDeviceImage($model, $db_url) {
    global $image_map;
    if (!empty($db_url)) return $db_url;
    foreach ($image_map as $key => $path) {
        if (stripos($model, $key) !== false) return $path;
    }
    return 'assets/images/laptop.png'; // Fallback
}

// Depoimentos de clientes
$testimonials = [
    ['name' => 'João Silva', 'role' => 'Freelancer', 'text' => 'Perfeito! Aluguei um MacBook Pro para um projeto e foi excelente.', 'rating' => 5],
    ['name' => 'Maria Santos', 'role' => 'Estudante', 'text' => 'Consegui alugar um iPad Pro para minhas aulas. Muito prático!', 'rating' => 5],
    ['name' => 'Carlos Mendes', 'role' => 'Empresário', 'text' => 'Equipamos nossa equipe para um evento. Suporte impecável.', 'rating' => 5],
];
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ConectaFácil — Tecnologia Sob Demanda</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="assets/style.css">
  <style>
    .hero-section {
      padding: 120px 0 80px;
      background: var(--bg-sidebar);
      color: white;
      text-align: center;
      position: relative;
      overflow: hidden;
    }
    .hero-section::before {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      background: var(--brand-gradient);
      opacity: 0.1;
      z-index: 0;
    }
    .hero-content { position: relative; z-index: 1; }
    .hero-title { font-size: 4rem; margin-bottom: 20px; color: white; }
    .hero-subtitle { font-size: 1.25rem; color: var(--text-400); margin-bottom: 40px; }
  </style>
</head>
<body class="bg-body">

<nav class="bg-card shadow-md py-4 sticky top-0 z-50">
  <div class="container flex justify-between items-center">
    <a href="index.php" class="flex items-center gap-2 text-2xl font-bold text-primary">
      <i class="bi bi-phone-vibrate"></i> ConectaFácil
    </a>
    <div class="flex gap-4">
      <a href="my_rentals.php" class="btn btn-secondary btn-sm">Meus Aluguéis</a>
      <a href="login.php" class="btn btn-primary btn-sm"><i class="bi bi-person-lock"></i> Login Admin</a>
    </div>
  </div>
</nav>

<header class="hero-section">
  <div class="container hero-content">
    <h1 class="hero-title">Tecnologia Premium <br><span class="text-accent">Sem Complicação</span></h1>
    <p class="hero-subtitle">Alugue os melhores dispositivos do mercado por dia. Rápido, seguro e flexível.</p>
    <div class="flex justify-center gap-4">
      <a href="#catalogo" class="btn btn-primary">Ver Catálogo</a>
      <a href="chat.php" class="btn btn-secondary">Falar com Consultor</a>
    </div>
  </div>
</header>

<section id="catalogo" class="py-12">
  <div class="container">
    <div class="text-center mb-12">
      <h2 class="text-3xl font-bold mb-4">Nosso Catálogo</h2>
      <p class="text-muted">Escolha o dispositivo ideal para sua necessidade atual.</p>
    </div>

    <div class="device-grid">
      <?php foreach ($devices as $d): ?>
      <div class="device-card">
        <div class="device-img-container">
          <img src="<?= getDeviceImage($d['brand'].' '.$d['model'], $d['photo_url']) ?>" alt="<?= htmlspecialchars($d['model']) ?>">
        </div>
        <div class="device-card-body">
          <span class="badge badge-blue mb-2"><?= htmlspecialchars($d['category_name']) ?></span>
          <h3 class="device-card-title"><?= htmlspecialchars($d['brand'] . ' ' . $d['model']) ?></h3>
          <p class="device-card-meta">
            <i class="bi bi-cpu"></i> <?= htmlspecialchars($d['color']) ?> | 
            <i class="bi bi-memory"></i> <?= $d['storage_gb'] ?>GB
          </p>
          <div class="device-card-price">
            R$ <?= number_format($d['daily_rate'], 2, ',', '.') ?> <span>/dia</span>
          </div>
          <a href="device_detail.php?id=<?= $d['id'] ?>" class="btn btn-primary w-full">Alugar Agora</a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="sobre" class="bg-input py-12">
  <div class="container">
    <div class="text-center mb-12">
      <h2 class="text-3xl font-bold">O que dizem nossos clientes</h2>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
      <?php foreach ($testimonials as $t): ?>
      <div class="card text-center">
        <div class="text-warning mb-4">
          <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
        </div>
        <p class="italic text-text-600 mb-6">"<?= htmlspecialchars($t['text']) ?>"</p>
        <h4 class="font-bold"><?= htmlspecialchars($t['name']) ?></h4>
        <span class="text-sm text-muted"><?= htmlspecialchars($t['role']) ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<footer id="contato" class="bg-sidebar text-light py-12">
  <div class="container grid grid-cols-1 md:grid-cols-3 gap-12">
    <div>
      <h3 class="text-xl font-bold mb-4 text-light"><i class="bi bi-phone-vibrate text-primary"></i> ConectaFácil</h3>
      <p class="text-muted">A solução inteligente para suas necessidades temporárias de tecnologia.</p>
    </div>
    <div>
      <h4 class="font-bold mb-4">Links Rápidos</h4>
      <ul class="list-none p-0 text-muted">
        <li class="mb-2"><a href="index.php" class="text-muted hover:text-light">Home</a></li>
        <li class="mb-2"><a href="#catalogo" class="text-muted hover:text-light">Aluguéis</a></li>
        <li class="mb-2"><a href="#sobre" class="text-muted hover:text-light">Sobre Nós</a></li>
        <li class="mb-2"><a href="#contato" class="text-muted hover:text-light">Contato</a></li>
        <li class="mb-2"><a href="login.php" class="text-muted hover:text-light font-bold">Painel Admin</a></li>
      </ul>
    </div>
    <div>
      <h4 class="font-bold mb-4">Contato</h4>
      <p class="text-muted mb-2"><i class="bi bi-envelope mr-2"></i> contato@conectafacil.com</p>
      <p class="text-muted"><i class="bi bi-telephone mr-2"></i> (11) 99999-9999</p>
    </div>
  </div>
  <div class="container border-t border-border-color mt-8 pt-8 text-center text-sm text-muted">
    &copy; <?= date('Y') ?> ConectaFácil. Todos os direitos reservados.
  </div>
</footer>

<a href="chat.php" class="btn btn-primary rounded-full shadow-xl" style="position:fixed; bottom:30px; right:30px; width:60px; height:60px; padding:0; font-size:24px; z-index:1000">
  <i class="bi bi-chat-dots"></i>
</a>

</body>
</html>

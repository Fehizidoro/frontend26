<?php
session_start();
require_once 'includes/db.php';

// Se já estiver logado, vai direto para o dashboard
if (!empty($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if ($email === '' || $pass === '') {
        $error = 'Preencha e-mail e senha.';
    } else {
        try {
            $db   = getDB();
            $stmt = $db->prepare('SELECT id, name, email, password, role FROM users WHERE email = ? AND active = 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && $pass === $user['password']) {
                session_regenerate_id(true);
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_role'] = $user['role'];
                
                // Redireciona para o dashboard após login bem-sucedido
                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'E-mail ou senha inválidos.';
            }
        } catch (PDOException $e) {
            $error = 'Erro de conexão: ' . $e->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login — ConectaFácil Admin</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="login-page">
  <div class="login-card">
    <div class="login-logo">
      <i class="bi bi-phone-vibrate"></i>
    </div>

    <h1 class="login-heading">ConectaFácil</h1>
    <p class="login-sub">Painel Administrativo</p>

    <?php if ($error): ?>
    <div class="alert alert-danger">
      <i class="bi bi-x-circle-fill"></i> <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <form method="post">
      <div class="form-group">
        <label class="form-label">E-mail Corporativo</label>
        <input type="email" name="email" class="form-control" placeholder="admin@conectafacil.com" required autofocus>
      </div>

      <div class="form-group mb-8">
        <label class="form-label">Senha de Acesso</label>
        <input type="password" name="password" class="form-control" placeholder="••••••••" required>
      </div>

      <button type="submit" class="btn btn-primary w-full py-4">
        Acessar Painel <i class="bi bi-box-arrow-in-right"></i>
      </button>
    </form>
    
    <div class="text-center mt-8">
      <a href="index.php" class="text-muted text-sm font-semibold">
        <i class="bi bi-arrow-left"></i> Voltar para o Site
      </a>
    </div>
  </div>
</div>
</body>
</html>

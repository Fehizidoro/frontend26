<?php
session_start();
// Limpa todas as variáveis de sessão
$_SESSION = array();

// Destrói o cookie da sessão se existir
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 42000, '/');
}

// Destrói a sessão
session_destroy();

// Redireciona para o site público
header('Location: index.php');
exit;

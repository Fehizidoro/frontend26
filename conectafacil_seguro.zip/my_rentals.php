<?php
require_once 'includes/db.php';
session_start();

$db = getDB();
$cpf = $_GET['cpf'] ?? '';
$email = $_GET['email'] ?? '';

// Buscar configurações
$settings_stmt = $db->query("SELECT `key`, `value` FROM settings");
$settings = [];
while ($row = $settings_stmt->fetch()) {
    $settings[$row['key']] = $row['value'];
}

$company_name = $settings['company_name'] ?? 'ConectaFácil';

$rentals = [];
$customer_name = '';

if ($cpf || $email) {
    $query = "
        SELECT r.*, d.brand, d.model, d.daily_rate
        FROM rentals r
        JOIN devices d ON r.device_id = d.id
        JOIN customers c ON r.customer_id = c.id
        WHERE ";
    
    if ($cpf) {
        $query .= "c.cpf = ?";
        $param = $cpf;
    } else {
        $query .= "c.email = ?";
        $param = $email;
    }
    
    $query .= " ORDER BY r.created_at DESC";
    
    $stmt = $db->prepare($query);
    $stmt->execute([$param]);
    $rentals = $stmt->fetchAll();
    
    if (!empty($rentals)) {
        $customer_name = $rentals[0]['customer_name'];
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Minhas Locações — <?= htmlspecialchars($company_name) ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="assets/style.css">
  <style>
    body { background: #f8fafc; }
    
    .site-nav {
      background: white;
      padding: 1rem 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .site-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      font-family: 'Sora', sans-serif;
      font-weight: 800;
      font-size: 1.5rem;
      color: var(--brand-900);
      text-decoration: none;
    }
    .site-logo svg {
      width: 36px;
      height: 36px;
      background: var(--brand-accent);
      border-radius: 8px;
      padding: 6px;
      color: white;
    }
    
    .container { max-width: 1000px; margin: 0 auto; padding: 0 20px; }
    
    .search-section {
      background: white;
      border-radius: 20px;
      padding: 30px;
      margin: 40px 0;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    
    .search-form {
      display: grid;
      grid-template-columns: 1fr 1fr auto;
      gap: 15px;
      align-items: end;
    }
    
    .form-group {
      display: flex;
      flex-direction: column;
    }
    
    .form-label {
      font-weight: 600;
      color: var(--text-secondary);
      margin-bottom: 8px;
      font-size: 0.9rem;
    }
    
    .form-control {
      padding: 12px 14px;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      font-family: 'DM Sans', sans-serif;
      font-size: 1rem;
      transition: border-color 0.2s;
    }
    
    .form-control:focus {
      outline: none;
      border-color: var(--brand-accent);
      box-shadow: 0 0 0 3px rgba(249,115,22,0.1);
    }
    
    .btn-search {
      padding: 12px 24px;
      background: var(--brand-accent);
      color: white;
      border: none;
      border-radius: 10px;
      font-weight: 700;
      cursor: pointer;
      transition: background 0.2s;
    }
    
    .btn-search:hover {
      background: var(--brand-accent-dim);
    }
    
    .rental-card {
      background: white;
      border-radius: 15px;
      border: 1px solid #e2e8f0;
      padding: 20px;
      margin-bottom: 20px;
      display: grid;
      grid-template-columns: 1fr auto;
      gap: 20px;
      align-items: center;
    }
    
    .rental-info h3 {
      margin: 0 0 10px;
      color: var(--brand-900);
    }
    
    .rental-details {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 15px;
      margin-top: 15px;
      padding-top: 15px;
      border-top: 1px solid #e2e8f0;
    }
    
    .detail-item {
      font-size: 0.9rem;
    }
    
    .detail-label {
      color: #64748b;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 0.75rem;
    }
    
    .detail-value {
      font-weight: 700;
      color: var(--brand-900);
      margin-top: 4px;
    }
    
    .status-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 8px 16px;
      border-radius: 99px;
      font-weight: 600;
      font-size: 0.85rem;
    }
    
    .status-pending {
      background: #fef3c7;
      color: #92400e;
    }
    
    .status-active {
      background: #dcfce7;
      color: #166534;
    }
    
    .status-finished {
      background: #dbeafe;
      color: #1e40af;
    }
    
    .status-cancelled {
      background: #fee2e2;
      color: #991b1b;
    }
    
    .empty-state {
      text-align: center;
      padding: 60px 20px;
      background: white;
      border-radius: 20px;
      border: 1px dashed #cbd5e1;
    }
    
    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: var(--brand-accent);
      margin-bottom: 30px;
      text-decoration: none;
      font-weight: 600;
    }
    
    .back-link:hover { color: var(--brand-accent-dim); }
  </style>
</head>
<body>

<nav class="site-nav">
  <a href="index.php" class="site-logo">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="5" y="2" width="14" height="20" rx="2" ry="2"/>
      <line x1="12" y1="18" x2="12.01" y2="18"/>
    </svg>
    <?= htmlspecialchars($company_name) ?>
  </a>
</nav>

<main class="container">
  <a href="index.php" class="back-link">
    <i class="bi bi-arrow-left"></i> Voltar ao catálogo
  </a>
  
  <div class="search-section">
    <h2 style="margin-top: 0; color: var(--brand-900);">Consultar Minhas Locações</h2>
    <p style="color: #64748b; margin-bottom: 20px;">Digite seu CPF ou email para visualizar o histórico de suas locações.</p>
    
    <form method="GET" class="search-form">
      <div class="form-group">
        <label class="form-label">CPF</label>
        <input type="text" name="cpf" class="form-control" placeholder="000.000.000-00" value="<?= htmlspecialchars($cpf) ?>">
      </div>
      <div class="form-group">
        <label class="form-label">ou Email</label>
        <input type="email" name="email" class="form-control" placeholder="seu@email.com" value="<?= htmlspecialchars($email) ?>">
      </div>
      <button type="submit" class="btn-search">
        <i class="bi bi-search"></i> Consultar
      </button>
    </form>
  </div>
  
  <?php if ($cpf || $email): ?>
    <?php if (empty($rentals)): ?>
      <div class="empty-state">
        <i class="bi bi-inbox" style="font-size: 3rem; color: #94a3b8;"></i>
        <h3 style="margin-top: 1rem; color: #475569;">Nenhuma locação encontrada</h3>
        <p style="color: #64748b;">Não encontramos locações para este CPF ou email.</p>
      </div>
    <?php else: ?>
      <h2 style="color: var(--brand-900); margin-bottom: 20px;">Locações de <?= htmlspecialchars($customer_name) ?></h2>
      
      <?php foreach ($rentals as $rental): ?>
        <div class="rental-card">
          <div class="rental-info">
            <h3><?= htmlspecialchars($rental['brand'] . ' ' . $rental['model']) ?></h3>
            <p style="color: #64748b; margin: 0;">ID da Locação: #<?= $rental['id'] ?></p>
            
            <div class="rental-details">
              <div class="detail-item">
                <div class="detail-label">Data de Início</div>
                <div class="detail-value"><?= date('d/m/Y', strtotime($rental['start_date'])) ?></div>
              </div>
              <div class="detail-item">
                <div class="detail-label">Data de Término</div>
                <div class="detail-value"><?= date('d/m/Y', strtotime($rental['planned_end_date'])) ?></div>
              </div>
              <div class="detail-item">
                <div class="detail-label">Valor Total</div>
                <div class="detail-value">R$ <?= number_format($rental['base_value'], 2, ',', '.') ?></div>
              </div>
              <?php if ($rental['final_value']): ?>
              <div class="detail-item">
                <div class="detail-label">Valor Final</div>
                <div class="detail-value">R$ <?= number_format($rental['final_value'], 2, ',', '.') ?></div>
              </div>
              <?php endif; ?>
            </div>
          </div>
          
          <div>
            <?php
              $status_map = [
                'pending' => ['badge' => 'status-pending', 'label' => 'Pendente', 'icon' => 'hourglass-split'],
                'active' => ['badge' => 'status-active', 'label' => 'Ativa', 'icon' => 'check-circle'],
                'finished' => ['badge' => 'status-finished', 'label' => 'Finalizada', 'icon' => 'check-all'],
                'cancelled' => ['badge' => 'status-cancelled', 'label' => 'Cancelada', 'icon' => 'x-circle']
              ];
              $status_info = $status_map[$rental['status']] ?? ['badge' => '', 'label' => 'Desconhecido', 'icon' => 'question-circle'];
            ?>
            <span class="status-badge <?= $status_info['badge'] ?>">
              <i class="bi bi-<?= $status_info['icon'] ?>"></i>
              <?= $status_info['label'] ?>
            </span>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  <?php endif; ?>
</main>

</body>
</html>

<!-- ... (código PHP existente) ... -->
<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/layout.php';
requireLogin();

$db     = getDB();
$errors = [];
$data   = [
    'device_id'        => '',
    'customer_name'    => '',
    'start_date'       => date('Y-m-d'),
    'planned_end_date' => '',
];

$availableDevices = $db->query(
    "SELECT id, brand, model, daily_rate FROM devices WHERE status = 'available' ORDER BY brand, model"
)->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['device_id']        = (int)($_POST['device_id'] ?? 0);
    $data['customer_name']    = trim($_POST['customer_name'] ?? '');
    $data['start_date']       = trim($_POST['start_date'] ?? '');
    $data['planned_end_date'] = trim($_POST['planned_end_date'] ?? '');

    if (!$data['device_id'])              $errors[] = 'Selecione um dispositivo.';
    if ($data['customer_name'] === '')    $errors[] = 'Informe o nome do cliente.';
    if ($data['start_date'] === '')       $errors[] = 'Informe a data de início.';
    if ($data['planned_end_date'] === '') $errors[] = 'Informe a data de devolução prevista.';
    if (!$errors && $data['planned_end_date'] < $data['start_date'])
        $errors[] = 'A data de devolução deve ser igual ou posterior ao início.';

    if (!$errors) {
        try {
            $db->beginTransaction();

            $check = $db->prepare("SELECT status, daily_rate FROM devices WHERE id = ? FOR UPDATE");
            $check->execute([$data['device_id']]);
            $dev = $check->fetch();

            if (!$dev || $dev['status'] !== 'available') {
                $errors[] = 'Este dispositivo não está mais disponível.';
                $db->rollBack();
            } else {
                $userId = currentUser()['id'];

                $ins = $db->prepare("
                    INSERT INTO rentals
                        (device_id, customer_name, start_date, planned_end_date, status,
                         daily_rate_snap, created_by)
                    VALUES (?, ?, ?, ?, 'active', ?, ?)
                ");
                $ins->execute([
                    $data['device_id'],
                    $data['customer_name'],
                    $data['start_date'],
                    $data['planned_end_date'],
                    $dev['daily_rate'],
                    $userId,
                ]);

                $db->prepare("UPDATE devices SET status = 'rented' WHERE id = ?")
                   ->execute([$data['device_id']]);

                $db->commit();
                $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Locação registrada com sucesso!'];
                header('Location: rentals.php');
                exit;
            }
        } catch (PDOException $e) {
            if ($db->inTransaction()) $db->rollBack();
            $errors[] = 'Erro ao registrar: ' . $e->getMessage();
        }
    }
}

$actions = '<a href="rentals.php" class="btn btn-secondary btn-sm">
  <i class="bi bi-arrow-left"></i> Voltar
</a>';
renderPageStart('Nova Locação', 'rentals.php', $actions);
?>

<div class="max-w-2xl mx-auto">

  <?php if ($errors): ?>
  <div class="alert alert-danger">
    <i class="bi bi-x-circle-fill"></i>
    <div>
      <?php foreach ($errors as $e): ?>
      <div><?= htmlspecialchars($e) ?></div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <?php if (!$availableDevices): ?>
  <div class="alert alert-warning">
    <i class="bi bi-exclamation-triangle-fill"></i>
    Nenhum dispositivo disponível para locação no momento.
  </div>
  <?php else: ?>

  <div class="card">
    <form method="post">

      <div class="form-group">
        <label class="form-label" for="device_id">Dispositivo <span class="text-danger">*</span></label>
        <select id="device_id" name="device_id" class="form-control" required>
          <option value="">Selecione um dispositivo…</option>
          <?php foreach ($availableDevices as $d): ?>
          <option value="<?= $d['id'] ?>"
                  data-rate="<?= $d['daily_rate'] ?>"
                  <?= $data['device_id'] == $d['id'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($d['brand'] . ' ' . $d['model']) ?>
            — R$ <?= number_format($d['daily_rate'], 2, ',', '.') ?>/dia
          </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label" for="customer_name">Nome do Cliente <span class="text-danger">*</span></label>
        <input type="text" id="customer_name" name="customer_name" class="form-control"
               value="<?= htmlspecialchars($data['customer_name']) ?>"
               placeholder="Nome completo do cliente" required>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="form-group">
          <label class="form-label" for="start_date">Data de Início <span class="text-danger">*</span></label>
          <input type="date" id="start_date" name="start_date" class="form-control"
                 value="<?= htmlspecialchars($data['start_date']) ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label" for="planned_end_date">Devolução Prevista <span class="text-danger">*</span></label>
          <input type="date" id="planned_end_date" name="planned_end_date" class="form-control"
                 value="<?= htmlspecialchars($data['planned_end_date']) ?>" required>
        </div>
      </div>

      <div class="flex gap-3 mt-6">
        <button type="submit" class="btn btn-primary">
          <i class="bi bi-check-lg"></i> Registrar Locação
        </button>
        <a href="rentals.php" class="btn btn-secondary">Cancelar</a>
      </div>

    </form>
  </div>

  <?php endif; ?>
</div>

<?php renderPageEnd(); ?>

<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/layout.php';

requireLogin();

$db = getDB();
$user = currentUser();

// Processar ações (aprovar/rejeitar)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $rental_id = $_POST['rental_id'] ?? '';
    
    if ($action === 'approve' && $rental_id) {
        $update = $db->prepare("UPDATE rentals SET status = 'active', created_by = ? WHERE id = ? AND status = 'pending'");
        $update->execute([$user['id'], $rental_id]);
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Locação aprovada com sucesso!'];
    } elseif ($action === 'reject' && $rental_id) {
        $update = $db->prepare("UPDATE rentals SET status = 'cancelled', closed_by = ? WHERE id = ? AND status = 'pending'");
        $update->execute([$user['id'], $rental_id]);
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Locação rejeitada.'];
    }
    
    header('Location: rental_requests.php');
    exit;
}

// Buscar solicitações pendentes
$stmt = $db->query("
    SELECT r.*, d.brand, d.model, d.daily_rate, c.phone, c.email 
    FROM rentals r 
    JOIN devices d ON r.device_id = d.id 
    LEFT JOIN customers c ON r.customer_id = c.id 
    WHERE r.status = 'pending' 
    ORDER BY r.created_at DESC
");
$pending_requests = $stmt->fetchAll();

// Buscar locações ativas
$active_stmt = $db->query("
    SELECT r.*, d.brand, d.model, c.phone, c.email 
    FROM rentals r 
    JOIN devices d ON r.device_id = d.id 
    LEFT JOIN customers c ON r.customer_id = c.id 
    WHERE r.status = 'active' 
    ORDER BY r.planned_end_date ASC
");
$active_rentals = $active_stmt->fetchAll();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$actions = '<a href="rental_requests.php" class="btn btn-secondary btn-sm"><i class="bi bi-arrow-clockwise"></i> Atualizar</a>';
renderPageStart('Solicitações de Aluguel', 'rental_requests.php', $actions);
?>

<?= flashHtml($flash) ?>

<div class="tabs mb-6">
  <button class="tab-btn active" onclick="switchTab('pending', this)">
    <i class="bi bi-hourglass-split"></i> Solicitações Pendentes
    <?php if (count($pending_requests) > 0): ?>
      <span class="badge badge-amber ml-2">
        <?= count($pending_requests) ?>
      </span>
    <?php endif; ?>
  </button>
  <button class="tab-btn" onclick="switchTab('active', this)">
    <i class="bi bi-check-circle"></i> Locações Ativas
    <?php if (count($active_rentals) > 0): ?>
      <span class="badge badge-success ml-2">
        <?= count($active_rentals) ?>
      </span>
    <?php endif; ?>
  </button>
</div>

<!-- Solicitações Pendentes -->
<div id="pending" class="tab-content active">
  <?php if (empty($pending_requests)): ?>
    <div class="card empty-state text-center py-10">
      <i class="bi bi-inbox text-4xl text-muted mb-4"></i>
      <h3 class="text-xl text-text-700 mb-2">Nenhuma solicitação pendente</h3>
      <p class="text-muted">Todas as solicitações foram processadas.</p>
    </div>
  <?php else: ?>
    <?php foreach ($pending_requests as $request): ?>
      <div class="card mb-4">
        <div class="card-header flex justify-between items-start">
          <div>
            <h4 class="card-title text-primary mb-1"><?= htmlspecialchars($request['brand'] . ' ' . $request['model']) ?></h4>
            <p class="text-sm text-text-600"><strong><?= htmlspecialchars($request['customer_name']) ?></strong></p>
          </div>
          <span class="badge badge-amber">
            <span class="badge-dot"></span> Pendente
          </span>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 py-4 border-t border-b border-border-color mb-4">
          <div class="date-item">
            <div class="text-sm text-muted font-semibold uppercase">Início</div>
            <div class="font-bold text-text-900 mt-1"><?= date('d/m/Y', strtotime($request['start_date'])) ?></div>
          </div>
          <div class="date-item">
            <div class="text-sm text-muted font-semibold uppercase">Término</div>
            <div class="font-bold text-text-900 mt-1"><?= date('d/m/Y', strtotime($request['planned_end_date'])) ?></div>
          </div>
          <div class="date-item">
            <div class="text-sm text-muted font-semibold uppercase">Valor Total</div>
            <div class="font-bold text-primary mt-1">R$ <?= number_format($request['base_value'], 2, ',', '.') ?></div>
          </div>
        </div>
        
        <div class="flex gap-4 mb-4 text-sm text-text-700">
          <div class="flex items-center gap-2">
            <i class="bi bi-envelope"></i>
            <a href="mailto:<?= htmlspecialchars($request['email']) ?>" class="text-primary hover:text-secondary"><?= htmlspecialchars($request['email']) ?></a>
          </div>
          <div class="flex items-center gap-2">
            <i class="bi bi-telephone"></i>
            <a href="tel:<?= htmlspecialchars($request['phone']) ?>" class="text-primary hover:text-secondary"><?= htmlspecialchars($request['phone']) ?></a>
          </div>
        </div>
        
        <div class="flex gap-3 mt-4">
          <form method="POST">
            <input type="hidden" name="rental_id" value="<?= $request['id'] ?>">
            <input type="hidden" name="action" value="approve">
            <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('Aprovar esta locação?')">
              <i class="bi bi-check-lg"></i> Aprovar
            </button>
          </form>
          <form method="POST">
            <input type="hidden" name="rental_id" value="<?= $request['id'] ?>">
            <input type="hidden" name="action" value="reject">
            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Rejeitar esta locação?')">
              <i class="bi bi-x-lg"></i> Rejeitar
            </button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<!-- Locações Ativas -->
<div id="active" class="tab-content">
  <?php if (empty($active_rentals)): ?>
    <div class="card empty-state text-center py-10">
      <i class="bi bi-calendar-check text-4xl text-muted mb-4"></i>
      <h3 class="text-xl text-text-700 mb-2">Nenhuma locação ativa</h3>
      <p class="text-muted">As locações aprovadas aparecerão aqui.</p>
    </div>
  <?php else: ?>
    <div class="card">
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>Dispositivo</th>
              <th>Cliente</th>
              <th>Período</th>
              <th>Valor</th>
              <th>Contato</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($active_rentals as $rental): ?>
              <tr>
                <td><strong class="text-text-900"><?= htmlspecialchars($rental['brand'] . ' ' . $rental['model']) ?></strong></td>
                <td><?= htmlspecialchars($rental['customer_name']) ?></td>
                <td>
                  <?= date('d/m', strtotime($rental['start_date'])) ?> a 
                  <?= date('d/m/Y', strtotime($rental['planned_end_date'])) ?>
                </td>
                <td>R$ <?= number_format($rental['base_value'], 2, ',', '.') ?></td>
                <td>
                  <a href="mailto:<?= htmlspecialchars($rental['email']) ?>" title="Email" class="text-primary hover:text-secondary mr-2">
                    <i class="bi bi-envelope"></i>
                  </a>
                  <a href="tel:<?= htmlspecialchars($rental['phone']) ?>" title="Telefone" class="text-primary hover:text-secondary">
                    <i class="bi bi-telephone"></i>
                  </a>
                </td>
                <td>
                  <a href="rental_return.php?id=<?= $rental['id'] ?>" class="btn btn-secondary btn-sm">
                    <i class="bi bi-box-arrow-in"></i> Devolução
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endif; ?>
</div>

<script>
  function switchTab(tabName, element) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    
    document.getElementById(tabName).classList.add('active');
    element.classList.add('active');
  }
</script>

<?php renderPageEnd(); ?>

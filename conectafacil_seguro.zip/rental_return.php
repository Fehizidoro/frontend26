<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/layout.php';
requireLogin();

$db     = getDB();
$errors = [];

$rentalId = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
if (!$rentalId) { header('Location: rentals.php'); exit; }

$stmt = $db->prepare("
    SELECT r.*, d.brand, d.model, d.daily_rate
    FROM rentals r
    JOIN devices d ON d.id = r.device_id
    WHERE r.id = ? AND r.status = 'active'
");
$stmt->execute([$rentalId]);
$rental = $stmt->fetch();

if (!$rental) {
    $_SESSION['flash'] = ['type' => 'warning', 'msg' => 'Locação não encontrada ou já finalizada.'];
    header('Location: rentals.php');
    exit;
}

$today      = date('Y-m-d');
$returnDate = $_POST['actual_end_date'] ?? $today;
$hasDamage  = isset($_POST['has_damage']);
$damageNotes = trim($_POST['damage_notes'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $returnDate = trim($_POST['actual_end_date'] ?? '');

    if ($returnDate === '')
        $errors[] = 'Informe a data de devolução.';
    if (!$errors && $returnDate < $rental['start_date'])
        $errors[] = 'A data de devolução não pode ser anterior ao início da locação.';

    if (!$errors) {
        $start    = new DateTimeImmutable($rental['start_date']);
        $planned  = new DateTimeImmutable($rental['planned_end_date']);
        $returned = new DateTimeImmutable($returnDate);
        $daily    = (float)$rental['daily_rate'];

        $totalDays = max(1, $start->diff($returned)->days);
        $baseValue = $daily * $totalDays;

        $lateDays  = ($returned > $planned) ? $planned->diff($returned)->days : 0;
        $lateFee   = $lateDays > 0 ? $daily * $lateDays * 0.1 : 0;
        $damageFee = $hasDamage ? $daily * 5 * 0.2 : 0;
        $finalValue = $baseValue + $lateFee + $damageFee;

        try {
            $db->beginTransaction();

            $userId = currentUser()['id'];

            $db->prepare("
                UPDATE rentals
                SET status = 'finished',
                    actual_end_date = ?, has_damage = ?,
                    damage_notes = ?, late_fee = ?,
                    damage_fee = ?, final_value = ?,
                    base_value = ?, closed_by = ?
                WHERE id = ?
            ")->execute([
                $returnDate, $hasDamage ? 1 : 0,
                $damageNotes ?: null,
                $lateFee, $damageFee, $finalValue,
                $baseValue, $userId, $rentalId
            ]);

            $db->prepare("UPDATE devices SET status = 'available' WHERE id = ?")
               ->execute([$rental['device_id']]);

            // audit log
            $db->prepare("
                INSERT INTO rental_history (rental_id, changed_by, action, note)
                VALUES (?, ?, 'returned', ?)
            ")->execute([$rentalId, $userId,
                "Devolução: R$ " . number_format($finalValue, 2, ',', '.')]);

            $db->commit();

            $_SESSION['flash'] = [
                'type' => 'success',
                'msg'  => 'Devolução registrada! Valor total: R$ ' . number_format($finalValue, 2, ',', '.'),
            ];
            header('Location: rentals.php?tab=finished');
            exit;
        } catch (PDOException $e) {
            if ($db->inTransaction()) $db->rollBack();
            $errors[] = 'Erro ao processar: ' . $e->getMessage();
        }
    }
}

$actions = '<a href="rentals.php" class="btn btn-secondary btn-sm">
  <i class="bi bi-arrow-left"></i> Voltar
</a>';
renderPageStart('Registrar Devolução', 'rentals.php', $actions);
?>

<div class="max-w-2xl mx-auto">

  <?php if ($errors): ?>
  <div class="alert alert-danger">
    <i class="bi bi-x-circle-fill"></i>
    <div>
      <?php foreach ($errors as $e): ?>
      <div><?= htmlspecialchars($e) ?></div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Rental Info -->
  <div class="card mb-6">
    <div class="card-header">
      <h2 class="card-title">Dados da Locação</h2>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
      <div class="flex flex-col">
        <label class="text-sm text-muted font-semibold uppercase">Cliente</label>
        <span class="font-bold text-text-900"><?= htmlspecialchars($rental['customer_name']) ?></span>
      </div>
      <div class="flex flex-col">
        <label class="text-sm text-muted font-semibold uppercase">Dispositivo</label>
        <span class="font-bold text-text-900"><?= htmlspecialchars($rental['brand'] . ' ' . $rental['model']) ?></span>
      </div>
      <div class="flex flex-col">
        <label class="text-sm text-muted font-semibold uppercase">Data de Início</label>
        <span class="font-bold text-text-900"><?= date('d/m/Y', strtotime($rental['start_date'])) ?></span>
      </div>
      <div class="flex flex-col">
        <label class="text-sm text-muted font-semibold uppercase">Devolução Prevista</label>
        <span class="font-bold text-text-900"><?= date('d/m/Y', strtotime($rental['planned_end_date'])) ?></span>
      </div>
      <div class="flex flex-col">
        <label class="text-sm text-muted font-semibold uppercase">Diária</label>
        <span class="font-bold text-primary">R$ <?= number_format($rental['daily_rate'], 2, ',', '.') ?></span>
      </div>
      <div class="flex flex-col">
        <label class="text-sm text-muted font-semibold uppercase">Locação #</label>
        <span class="font-bold">#<?= $rental['id'] ?></span>
      </div>
    </div>
  </div>

  <!-- Return Form -->
  <div class="card">
    <div class="card-header">
      <h2 class="card-title">Registrar Devolução</h2>
    </div>
    <form method="post">
      <input type="hidden" name="id" value="<?= $rentalId ?>">

      <div class="form-group">
        <label class="form-label" for="return_date">Data de Devolução <span class="text-danger">*</span></label>
        <input type="date" id="return_date" name="actual_end_date" class="form-control"
               value="<?= htmlspecialchars($returnDate) ?>" max="<?= $today ?>" required>
      </div>

      <div class="form-group flex items-center gap-3 mb-4">
        <input type="checkbox" id="has_damage" name="has_damage" class="w-5 h-5" <?= $hasDamage ? 'checked' : '' ?>>
        <label for="has_damage" class="font-semibold cursor-pointer">Dispositivo apresenta danos</label>
      </div>

      <div class="form-group mb-6" id="damageNotesGroup" style="<?= $hasDamage ? '' : 'display:none' ?>">
        <label class="form-label" for="damage_notes">Descrição dos danos</label>
        <textarea id="damage_notes" name="damage_notes" class="form-control"
                  placeholder="Descreva os danos observados…"><?= htmlspecialchars($damageNotes) ?></textarea>
      </div>

      <div class="flex gap-3 mt-8">
        <button type="submit" class="btn btn-primary">
          <i class="bi bi-check-lg"></i> Confirmar Devolução
        </button>
        <a href="rentals.php" class="btn btn-secondary">Cancelar</a>
      </div>
    </form>
  </div>

</div>

<script>
  const hasDmg = document.getElementById('has_damage');
  const dmgGrp = document.getElementById('damageNotesGroup');
  if (hasDmg && dmgGrp) {
    hasDmg.addEventListener('change', () => {
      dmgGrp.style.display = hasDmg.checked ? 'block' : 'none';
    });
  }
</script>

<?php renderPageEnd(); ?>

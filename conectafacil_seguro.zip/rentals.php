<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/layout.php';
requireLogin();

$db  = getDB();
$tab = $_GET['tab'] ?? 'active';

$activeRentals = $db->query("
    SELECT r.id, r.customer_name, r.start_date, r.planned_end_date, r.status,
           d.brand, d.model, d.daily_rate
    FROM rentals r
    JOIN devices d ON d.id = r.device_id
    WHERE r.status = 'active'
    ORDER BY r.planned_end_date ASC
")->fetchAll();

$finishedRentals = $db->query("
    SELECT r.id, r.customer_name, r.start_date, r.actual_end_date,
           r.final_value, r.has_damage, r.status,
           d.brand, d.model
    FROM rentals r
    JOIN devices d ON d.id = r.device_id
    WHERE r.status = 'finished'
    ORDER BY r.actual_end_date DESC
    LIMIT 50
")->fetchAll();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$today = new DateTimeImmutable('today');

$actions = '<a href="rental_new.php" class="btn btn-primary btn-sm">
  <i class="bi bi-plus-lg"></i> Nova Locação
</a>';

renderPageStart('Locações', 'rentals.php', $actions);
?>

<?= flashHtml($flash) ?>

<!-- Tabs -->
<div class="tabs mb-6">
  <button class="tab-btn <?= $tab === 'active' ? 'active' : '' ?>" onclick="switchTab('active', this)">
    Ativas <span class="badge badge-blue ml-2"><?= count($activeRentals) ?></span>
  </button>
  <button class="tab-btn <?= $tab === 'finished' ? 'active' : '' ?>" onclick="switchTab('finished', this)">
    Finalizadas <span class="badge badge-gray ml-2"><?= count($finishedRentals) ?></span>
  </button>
</div>

<?php if ($tab === 'active'): ?>
<!-- Active rentals -->
<div id="active" class="tab-content active">
  <?php if (empty($activeRentals)): ?>
    <div class="card empty-state text-center py-10">
      <i class="bi bi-clipboard-check text-4xl text-muted mb-4"></i>
      <h3 class="text-xl text-text-700 mb-2">Nenhuma locação ativa no momento.</h3>
      <p class="text-muted">As locações aprovadas aparecerão aqui.</p>
    </div>
  <?php else: ?>
    <div class="card">
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Cliente</th>
              <th>Dispositivo</th>
              <th>Início</th>
              <th>Devolução Prev.</th>
              <th>Status</th>
              <th class="text-right">Ação</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($activeRentals as $r):
              $dueDate = new DateTimeImmutable($r['planned_end_date']);
              $isLate  = $today > $dueDate;
              $daysLate = $isLate ? $today->diff($dueDate)->days : 0;
            ?>
            <tr>
              <td>#<?= $r['id'] ?></td>
              <td class="font-semibold"><?= htmlspecialchars($r['customer_name']) ?></td>
              <td><?= htmlspecialchars($r['brand'] . ' ' . $r['model']) ?></td>
              <td><?= date('d/m/Y', strtotime($r['start_date'])) ?></td>
              <td>
                <?= date('d/m/Y', strtotime($r['planned_end_date'])) ?>
                <?php if ($isLate): ?>
                <span class="badge badge-red ml-2">
                  <span class="badge-dot"></span><?= $daysLate ?>d atraso
                </span>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($isLate): ?>
                  <span class="badge badge-red"><span class="badge-dot"></span>Em atraso</span>
                <?php else: ?>
                  <span class="badge badge-blue"><span class="badge-dot"></span>Ativa</span>
                <?php endif; ?>
              </td>
              <td class="text-right">
                <a href="rental_return.php?id=<?= $r['id'] ?>" class="btn btn-secondary btn-sm">
                  <i class="bi bi-arrow-return-left"></i> Devolver
                </a>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endif; ?>
</div>

<?php else: ?>
<!-- Finished rentals -->
<div id="finished" class="tab-content active">
  <?php if (empty($finishedRentals)): ?>
    <div class="card empty-state text-center py-10">
      <i class="bi bi-archive text-4xl text-muted mb-4"></i>
      <h3 class="text-xl text-text-700 mb-2">Nenhuma locação finalizada.</h3>
      <p class="text-muted">As locações concluídas aparecerão aqui.</p>
    </div>
  <?php else: ?>
    <div class="card">
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Cliente</th>
              <th>Dispositivo</th>
              <th>Início</th>
              <th>Devolvido em</th>
              <th>Valor Final</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($finishedRentals as $r): ?>
            <tr>
              <td>#<?= $r['id'] ?></td>
              <td class="font-semibold"><?= htmlspecialchars($r['customer_name']) ?></td>
              <td><?= htmlspecialchars($r['brand'] . ' ' . $r['model']) ?></td>
              <td><?= date('d/m/Y', strtotime($r['start_date'])) ?></td>
              <td><?= date('d/m/Y', strtotime($r['actual_end_date'])) ?></td>
              <td class="font-semibold">R$ <?= number_format($r['final_value'] ?? 0, 2, ',', '.') ?></td>
              <td>
                <?php if ($r['has_damage']): ?>
                  <span class="badge badge-amber"><span class="badge-dot"></span>Com dano</span>
                <?php else: ?>
                  <span class="badge badge-gray"><span class="badge-dot"></span>Finalizada</span>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<script>
  function switchTab(tabName, element) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    
    document.getElementById(tabName).classList.add('active');
    element.classList.add('active');
  }
</script>

<?php renderPageEnd(); ?>

<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/layout.php';
requireAdmin();

$db = getDB();
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db->beginTransaction();
        foreach ($_POST['settings'] as $key => $value) {
            $stmt = $db->prepare("UPDATE settings SET value = ? WHERE `key` = ?");
            $stmt->execute([$value, $key]);
        }
        $db->commit();
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Configurações atualizadas com sucesso!'];
        header('Location: settings.php');
        exit;
    } catch (Exception $e) {
        if ($db->inTransaction()) $db->rollBack();
        $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Erro ao salvar: ' . $e->getMessage()];
    }
}

$settings = $db->query("SELECT * FROM settings ORDER BY group_name, `key`")->fetchAll();
$groups = [];
foreach ($settings as $s) {
    $groups[$s['group_name']][] = $s;
}

renderPageStart('Configurações', 'settings.php');
?>

<?= flashHtml($flash) ?>

<div class="max-w-4xl mx-auto">
    <form method="POST">
        <?php foreach ($groups as $groupName => $items): ?>
            <div class="card mb-8">
                <div class="card-header">
                    <h2 class="card-title text-capitalize"><?= htmlspecialchars(str_replace('_', ' ', $groupName)) ?></h2>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php foreach ($items as $s): ?>
                        <div class="form-group">
                            <label class="form-label" title="<?= htmlspecialchars($s['description']) ?>">
                                <?= htmlspecialchars(str_replace('_', ' ', $s['key'])) ?>
                            </label>
                            <input type="text" name="settings[<?= $s['key'] ?>]" value="<?= htmlspecialchars($s['value']) ?>" class="form-control">
                            <small class="text-muted text-xs"><?= htmlspecialchars($s['description']) ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="flex justify-end gap-4 mb-12">
            <button type="submit" class="btn btn-primary">
                <i class="bi bi-save"></i> Salvar Alterações
            </button>
        </div>
    </form>
</div>

<?php renderPageEnd(); ?>

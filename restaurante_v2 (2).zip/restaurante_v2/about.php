<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
$sobre_titulo = getConteudo($pdo,'sobre_titulo');
$sobre_texto  = getConteudo($pdo,'sobre_texto');
$sobre_missao = getConteudo($pdo,'sobre_missao');
$rodape       = getConteudo($pdo,'rodape_texto');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sobre — Bella Vista</title>
<link rel="stylesheet" href="css/styles.css">
</head>
<body>

<header class="site-header">
  <div class="header-inner">
    <a href="index.php" class="site-logo">Bella<span>Vista</span></a>
    <ul class="site-nav">
      <li><a href="index.php">Início</a></li>
      <li><a href="about.php" class="active">Sobre</a></li>
      <li><a href="services.php">Cardápio</a></li>
      <li><a href="contact.php">Contato</a></li>
      <?php if(estaLogado()): ?>
        <li><a href="admin/index.php" class="nav-cta">⚙ Admin</a></li>
      <?php else: ?>
        <li><a href="admin/login.php" class="nav-cta">Entrar</a></li>
      <?php endif; ?>
    </ul>
  </div>
</header>

<section class="section sobre-section" style="padding-top:110px">
  <div class="section-inner">
    <div class="sobre-grid">
      <div class="sobre-img">
        <img src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=700&q=80" alt="Interior do restaurante">
      </div>
      <div>
        <span class="section-label">✦ Nossa História</span>
        <h2 class="section-title"><?= htmlspecialchars($sobre_titulo) ?></h2>
        <div class="divider"></div>
        <p style="color:var(--muted);margin-bottom:20px;line-height:1.8"><?= htmlspecialchars($sobre_texto) ?></p>
        <div style="background:var(--warm);border-left:3px solid var(--gold);padding:18px 22px;border-radius:0 8px 8px 0;margin-bottom:28px">
          <p style="font-family:'Cormorant Garamond',serif;font-size:1.1rem;font-style:italic;color:var(--umber)">
            "<?= htmlspecialchars($sobre_missao) ?>"
          </p>
        </div>
        <a href="services.php" class="btn btn-gold">Ver nosso Cardápio</a>
      </div>
    </div>

    <div class="sobre-stats" style="margin-top:64px">
      <div class="stat-item">
        <div class="stat-num">+20</div>
        <div class="stat-lbl">Anos de tradição</div>
      </div>
      <div class="stat-item">
        <div class="stat-num">50+</div>
        <div class="stat-lbl">Pratos no cardápio</div>
      </div>
      <div class="stat-item">
        <div class="stat-num">4.9★</div>
        <div class="stat-lbl">Avaliação média</div>
      </div>
      <div class="stat-item">
        <div class="stat-num">+8k</div>
        <div class="stat-lbl">Clientes satisfeitos</div>
      </div>
    </div>
  </div>
</section>

<!-- Equipe / valores -->
<section class="section" style="background:var(--noir);padding:80px 20px">
  <div class="section-inner" style="text-align:center">
    <span class="section-label">✦ Nossos valores</span>
    <h2 class="section-title" style="color:var(--white)">Por que o <em>Bella Vista</em>?</h2>
    <div class="divider" style="margin:16px auto 40px"></div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:28px;margin-top:8px">
      <?php
      $valores = [
        ['🍝','Receitas Autênticas','Tradições culinárias italianas passadas de geração em geração.'],
        ['🌿','Ingredientes Frescos','Selecionados diariamente nos melhores produtores locais.'],
        ['👨‍🍳','Chefs Especializados','Formados nas melhores escolas de gastronomia da Itália.'],
        ['🍷','Carta de Vinhos','Mais de 80 rótulos italianos selecionados pelo nosso sommelier.'],
      ];
      foreach($valores as [$icon,$titulo,$desc]):
      ?>
      <div style="background:rgba(255,255,255,.04);border:1px solid rgba(201,168,76,.15);border-radius:14px;padding:30px 24px">
        <div style="font-size:2rem;margin-bottom:14px"><?= $icon ?></div>
        <h3 style="font-family:'Cormorant Garamond',serif;font-size:1.25rem;color:var(--gold);margin-bottom:10px"><?= $titulo ?></h3>
        <p style="color:rgba(255,255,255,.45);font-size:.87rem;line-height:1.7"><?= $desc ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<footer class="site-footer">
  <div class="footer-bottom" style="border-top:none;padding:24px 40px">
    <p><?= htmlspecialchars($rodape) ?> | <a href="admin/login.php">Admin</a></p>
  </div>
</footer>

</body>
</html>

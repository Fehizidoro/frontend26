<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if(estaLogado()){ header('Location: index.php'); exit; }

$erro = $sucesso = '';
$campos_erro = [];

if($_SERVER['REQUEST_METHOD']==='POST'){
    $nome    = limpar($_POST['nome']??'');
    $email   = limpar($_POST['email']??'');
    $usuario = limpar($_POST['usuario']??'');
    $senha   = $_POST['senha']??'';
    $confirma= $_POST['confirma']??'';

    if(empty($nome))       $campos_erro['nome']     = 'Nome obrigatório.';
    if(empty($email))      $campos_erro['email']    = 'E-mail obrigatório.';
    elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)) $campos_erro['email'] = 'E-mail inválido.';
    if(empty($usuario))    $campos_erro['usuario']  = 'Usuário obrigatório.';
    elseif(strlen($usuario)<3) $campos_erro['usuario'] = 'Mínimo 3 caracteres.';
    if(strlen($senha)<6)   $campos_erro['senha']    = 'Mínimo 6 caracteres.';
    if($senha!==$confirma) $campos_erro['confirma'] = 'As senhas não coincidem.';

    if(empty($campos_erro)){
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE usuario=? OR email=?");
        $stmt->execute([$usuario,$email]);
        if($stmt->fetch()){
            $erro='Usuário ou e-mail já cadastrado.';
        } else {
            $hash = password_hash($senha, PASSWORD_DEFAULT);
            $pdo->prepare("INSERT INTO usuarios(nome,email,usuario,senha) VALUES(?,?,?,?)")
                ->execute([$nome,$email,$usuario,$hash]);
            $sucesso='Conta criada com sucesso!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cadastro — Bella Vista Admin</title>
<link rel="stylesheet" href="../css/styles.css">
</head>
<body>

<div class="auth-page">
  <div class="auth-visual">
    <div class="auth-visual-content">
      <a href="../index.php" class="logo">Bella<span>Vista</span></a>
      <p>Crie sua conta para acessar o painel administrativo do restaurante.</p>
      <div class="auth-visual-quote">
        "Cada prato conta uma história. Cada detalhe faz a diferença."
      </div>
    </div>
  </div>

  <div class="auth-form-side">
    <div class="auth-box" style="max-width:460px">
      <h1>Criar <em>conta</em></h1>
      <p class="auth-sub">Preencha os dados abaixo para se cadastrar.</p>

      <?php if($sucesso): ?>
        <div class="flash" style="background:#d4edda;color:#155724">
          ✅ <?= $sucesso ?> <a href="login.php" style="color:#155724;font-weight:700">Fazer login →</a>
        </div>
      <?php endif; ?>
      <?php if($erro): ?>
        <div class="flash flash-erro" style="background:#fde8eb;color:#8b1a2a">❌ <?= htmlspecialchars($erro) ?></div>
      <?php endif; ?>

      <?php if(!$sucesso): ?>
      <form method="POST" id="cadForm" novalidate>

        <div class="input-group">
          <label>Nome completo</label>
          <span class="input-icon">✏️</span>
          <input type="text" name="nome" placeholder="Seu nome"
                 value="<?= htmlspecialchars($_POST['nome']??'') ?>"
                 class="<?= isset($campos_erro['nome'])?'error-field':'' ?>">
          <?php if(isset($campos_erro['nome'])): ?><div class="field-error show"><?= $campos_erro['nome'] ?></div><?php endif; ?>
        </div>

        <div class="input-group">
          <label>E-mail</label>
          <span class="input-icon">✉️</span>
          <input type="email" name="email" placeholder="email@exemplo.com"
                 value="<?= htmlspecialchars($_POST['email']??'') ?>"
                 class="<?= isset($campos_erro['email'])?'error-field':'' ?>">
          <?php if(isset($campos_erro['email'])): ?><div class="field-error show"><?= $campos_erro['email'] ?></div><?php endif; ?>
        </div>

        <div class="input-group">
          <label>Nome de usuário</label>
          <span class="input-icon">👤</span>
          <input type="text" name="usuario" placeholder="sem espaços, mín. 3 caracteres"
                 value="<?= htmlspecialchars($_POST['usuario']??'') ?>"
                 class="<?= isset($campos_erro['usuario'])?'error-field':'' ?>">
          <?php if(isset($campos_erro['usuario'])): ?><div class="field-error show"><?= $campos_erro['usuario'] ?></div><?php endif; ?>
        </div>

        <div class="input-group">
          <label>Senha</label>
          <span class="input-icon">🔒</span>
          <input type="password" id="senhaInput" name="senha" placeholder="mín. 6 caracteres"
                 class="<?= isset($campos_erro['senha'])?'error-field':'' ?>"
                 oninput="checkStrength(this.value)">
          <button type="button" class="toggle-pass" onclick="togglePass('senhaInput')">👁</button>
          <?php if(isset($campos_erro['senha'])): ?><div class="field-error show"><?= $campos_erro['senha'] ?></div><?php endif; ?>
          <!-- Medidor de força -->
          <div class="strength-wrap">
            <div class="strength-bar"><div class="strength-fill" id="strengthFill"></div></div>
            <div class="strength-text" id="strengthText">Digite uma senha</div>
          </div>
        </div>

        <div class="input-group">
          <label>Confirmar senha</label>
          <span class="input-icon">🔒</span>
          <input type="password" id="confirmaInput" name="confirma" placeholder="repita a senha"
                 class="<?= isset($campos_erro['confirma'])?'error-field':'' ?>">
          <button type="button" class="toggle-pass" onclick="togglePass('confirmaInput')">👁</button>
          <?php if(isset($campos_erro['confirma'])): ?><div class="field-error show"><?= $campos_erro['confirma'] ?></div><?php endif; ?>
        </div>

        <button type="submit" class="btn btn-gold btn-full" style="margin-top:6px">
          Criar Conta →
        </button>
      </form>
      <?php endif; ?>

      <div class="auth-footer" style="margin-top:24px">
        Já tem conta? <a href="login.php">Fazer login</a>
      </div>
      <div class="auth-footer" style="margin-top:8px">
        <a href="../index.php">← Voltar ao site</a>
      </div>
    </div>
  </div>
</div>

<script>
function togglePass(id){
  const i = document.getElementById(id);
  i.type = i.type==='password'?'text':'password';
}
function checkStrength(v){
  const fill = document.getElementById('strengthFill');
  const text = document.getElementById('strengthText');
  let score = 0;
  if(v.length>=6) score++;
  if(v.length>=10) score++;
  if(/[A-Z]/.test(v)) score++;
  if(/[0-9]/.test(v)) score++;
  if(/[^A-Za-z0-9]/.test(v)) score++;
  const levels = [
    {w:'0%',   c:'#e74c3c', t:'Muito fraca'},
    {w:'20%',  c:'#e74c3c', t:'Fraca'},
    {w:'40%',  c:'#f39c12', t:'Razoável'},
    {w:'70%',  c:'#f1c40f', t:'Boa'},
    {w:'90%',  c:'#2ecc71', t:'Forte'},
    {w:'100%', c:'#27ae60', t:'Muito forte ✓'},
  ];
  const l = levels[score];
  fill.style.width = l.w;
  fill.style.background = l.c;
  text.textContent = v.length ? l.t : 'Digite uma senha';
  text.style.color = v.length ? l.c : 'var(--muted)';
}
</script>
</body>
</html>

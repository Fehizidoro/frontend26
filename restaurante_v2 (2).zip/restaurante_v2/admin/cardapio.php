<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
requerLogin();

if(isset($_GET['excluir'])){
    $pdo->prepare("DELETE FROM cardapio WHERE id=?")->execute([(int)$_GET['excluir']]);
    flash('✅ Prato removido.'); header('Location: cardapio.php'); exit;
}
if(isset($_GET['toggle'])){
    $p = $pdo->prepare("SELECT ativo FROM cardapio WHERE id=?");
    $p->execute([(int)$_GET['toggle']]);
    $atual = $p->fetchColumn();
    $pdo->prepare("UPDATE cardapio SET ativo=? WHERE id=?")->execute([!$atual,(int)$_GET['toggle']]);
    flash('✅ Status atualizado.'); header('Location: cardapio.php'); exit;
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['salvar_prato'])){
    $id        = (int)($_POST['id']??0);
    $nome      = limpar($_POST['nome']??'');
    $descricao = limpar($_POST['descricao']??'');
    $preco     = (float)str_replace(',','.',$_POST['preco']??0);
    $categoria = limpar($_POST['categoria']??'');
    $foto_url  = limpar($_POST['foto_url']??'');
    $destaque  = isset($_POST['destaque'])?1:0;
    $ativo     = isset($_POST['ativo'])?1:0;

    if(empty($nome)||$preco<=0){ flash('⚠️ Nome e preço são obrigatórios.','erro'); }
    elseif($id>0){
        $pdo->prepare("UPDATE cardapio SET nome=?,descricao=?,preco=?,categoria=?,foto_url=?,destaque=?,ativo=? WHERE id=?")
            ->execute([$nome,$descricao,$preco,$categoria,$foto_url,$destaque,$ativo,$id]);
        flash('✅ Prato atualizado!');
    } else {
        $pdo->prepare("INSERT INTO cardapio(nome,descricao,preco,categoria,foto_url,destaque,ativo) VALUES(?,?,?,?,?,?,?)")
            ->execute([$nome,$descricao,$preco,$categoria,$foto_url,$destaque,$ativo]);
        flash('✅ Prato adicionado!');
    }
    header('Location: cardapio.php'); exit;
}

$editar = null;
if(isset($_GET['editar'])){
    $s=$pdo->prepare("SELECT * FROM cardapio WHERE id=?"); $s->execute([(int)$_GET['editar']]);
    $editar=$s->fetch();
}
$pratos = $pdo->query("SELECT * FROM cardapio ORDER BY categoria,nome")->fetchAll();
$categorias_existentes = array_unique(array_column($pratos,'categoria'));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cardápio — Admin</title>
<link rel="stylesheet" href="../css/styles.css">
</head>
<body>
<div class="admin-layout">
  <?php include 'sidebar.php'; ?>
  <main class="admin-main">
    <div class="admin-topbar">
      <h1>Gerenciar <em>Cardápio</em></h1>
      <span style="color:var(--muted);font-size:.88rem"><?= count($pratos) ?> pratos cadastrados</span>
    </div>
    <?php renderFlash(); ?>

    <!-- Formulário -->
    <div class="admin-card">
      <div class="admin-card-header">
        <h2><?= $editar?'✏️ Editar Prato':'➕ Novo Prato' ?></h2>
        <?php if($editar): ?><a href="cardapio.php" class="btn btn-sm" style="background:#888;color:#fff">Cancelar</a><?php endif; ?>
      </div>
      <form method="POST" class="form-admin">
        <?php if($editar): ?><input type="hidden" name="id" value="<?= $editar['id'] ?>"><?php endif; ?>
        <div class="form-grid-2">
          <div>
            <label>Nome *</label>
            <input type="text" name="nome" required value="<?= htmlspecialchars($editar['nome']??$_POST['nome']??'') ?>">
          </div>
          <div>
            <label>Categoria</label>
            <input type="text" name="categoria" list="cats" value="<?= htmlspecialchars($editar['categoria']??$_POST['categoria']??'') ?>">
            <datalist id="cats">
              <?php foreach($categorias_existentes as $cat): ?>
                <option value="<?= htmlspecialchars($cat) ?>">
              <?php endforeach; ?>
            </datalist>
          </div>
          <div>
            <label>Preço (R$) *</label>
            <input type="text" name="preco" placeholder="Ex: 45.90" required value="<?= $editar?number_format($editar['preco'],2,'.',''): '' ?>">
          </div>
          <div>
            <label>URL da foto (Unsplash etc.)</label>
            <input type="text" name="foto_url" placeholder="https://images.unsplash.com/..." value="<?= htmlspecialchars($editar['foto_url']??'') ?>">
          </div>
        </div>
        <div>
          <label>Descrição</label>
          <textarea name="descricao"><?= htmlspecialchars($editar['descricao']??'') ?></textarea>
        </div>
        <div style="display:flex;gap:24px;margin-bottom:18px">
          <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:.9rem;font-weight:400">
            <input type="checkbox" name="ativo" style="width:auto;accent-color:var(--gold)" <?= (!$editar||$editar['ativo'])?'checked':'' ?>>
            Prato ativo no site
          </label>
          <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:.9rem;font-weight:400">
            <input type="checkbox" name="destaque" style="width:auto;accent-color:var(--gold)" <?= ($editar&&$editar['destaque'])?'checked':'' ?>>
            ✦ Exibir na página inicial como destaque
          </label>
        </div>
        <button type="submit" name="salvar_prato" class="btn btn-gold">
          <?= $editar?'💾 Salvar':'➕ Adicionar Prato' ?>
        </button>
      </form>
    </div>

    <!-- Tabela -->
    <div class="admin-card">
      <div class="admin-card-header"><h2>📋 Lista de Pratos</h2></div>
      <table class="data-table">
        <thead><tr><th>Foto</th><th>Nome</th><th>Categoria</th><th>Preço</th><th>Status</th><th>Ações</th></tr></thead>
        <tbody>
          <?php foreach($pratos as $p): ?>
          <tr>
            <td>
              <?php if($p['foto_url']): ?>
                <img src="<?= htmlspecialchars($p['foto_url']) ?>" style="width:56px;height:42px;object-fit:cover;border-radius:6px">
              <?php else: ?>
                <div style="width:56px;height:42px;background:var(--warm);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:1.2rem">🍽️</div>
              <?php endif; ?>
            </td>
            <td>
              <strong><?= htmlspecialchars($p['nome']) ?></strong>
              <?php if($p['destaque']): ?> <span class="badge badge-yellow">✦ Destaque</span><?php endif; ?>
            </td>
            <td><?= htmlspecialchars($p['categoria']) ?></td>
            <td>R$ <?= number_format($p['preco'],2,',','.') ?></td>
            <td>
              <a href="?toggle=<?= $p['id'] ?>" class="badge <?= $p['ativo']?'badge-green':'badge-red' ?>" style="text-decoration:none;cursor:pointer">
                <?= $p['ativo']?'✅ Ativo':'❌ Inativo' ?>
              </a>
            </td>
            <td style="display:flex;gap:6px;flex-wrap:wrap">
              <a href="?editar=<?= $p['id'] ?>" class="btn btn-sm" style="background:var(--gold);color:var(--noir)">✏️</a>
              <a href="?excluir=<?= $p['id'] ?>" onclick="return confirm('Excluir este prato?')" class="btn btn-sm btn-red">🗑️</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
</body>
</html>

<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
requerLogin();

$total_pratos   = $pdo->query("SELECT COUNT(*) FROM cardapio WHERE ativo=1")->fetchColumn();
$total_usuarios = $pdo->query("SELECT COUNT(*) FROM usuarios")->fetchColumn();
$msgs_novas     = $pdo->query("SELECT COUNT(*) FROM contatos WHERE lida=0")->fetchColumn();
$total_cats     = $pdo->query("SELECT COUNT(DISTINCT categoria) FROM cardapio WHERE ativo=1")->fetchColumn();

$msgs_recentes  = $pdo->query("SELECT * FROM contatos ORDER BY enviado_em DESC LIMIT 5")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard — Admin Bella Vista</title>
<link rel="stylesheet" href="../css/styles.css">
</head>
<body>

<div class="admin-layout">
  <?php include 'sidebar.php'; ?>

  <main class="admin-main">
    <div class="admin-topbar">
      <div>
        <h1>Dashboard <em>Admin</em></h1>
        <p style="color:var(--muted);font-size:.88rem;margin-top:4px">Bem-vindo, <?= htmlspecialchars($_SESSION['nome']) ?>! 👋</p>
      </div>
      <a href="../index.php" target="_blank" class="btn btn-gold btn-sm">🌐 Ver Site</a>
    </div>

    <?php renderFlash(); ?>

    <!-- Stats -->
    <div class="stats-row">
      <div class="stat-card">
        <div class="stat-icon gold">🍝</div>
        <div><div class="stat-num2"><?= $total_pratos ?></div><div class="stat-lbl2">Pratos ativos</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon blue">🏷️</div>
        <div><div class="stat-num2"><?= $total_cats ?></div><div class="stat-lbl2">Categorias</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green">👥</div>
        <div><div class="stat-num2"><?= $total_usuarios ?></div><div class="stat-lbl2">Usuários</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon red">✉️</div>
        <div><div class="stat-num2"><?= $msgs_novas ?></div><div class="stat-lbl2">Msg não lidas</div></div>
      </div>
    </div>

    <!-- Ações rápidas -->
    <div class="admin-card">
      <div class="admin-card-header"><h2>⚡ Acesso Rápido</h2></div>
      <div style="display:flex;gap:12px;flex-wrap:wrap">
        <a href="manage_content.php" class="btn btn-gold btn-sm">✏️ Editar Textos</a>
        <a href="cardapio.php" class="btn btn-sm" style="background:var(--umber);color:#fff">🍝 Cardápio</a>
        <a href="usuarios.php" class="btn btn-sm" style="background:#27ae60;color:#fff">👥 Usuários</a>
        <a href="mensagens.php" class="btn btn-sm" style="background:var(--red);color:#fff">
          ✉️ Mensagens <?= $msgs_novas>0?"($msgs_novas)":'' ?>
        </a>
      </div>
    </div>

    <!-- Mensagens recentes -->
    <div class="admin-card">
      <div class="admin-card-header">
        <h2>📬 Mensagens Recentes</h2>
        <a href="mensagens.php" style="font-size:.85rem;color:var(--gold);text-decoration:none">Ver todas →</a>
      </div>
      <?php if(empty($msgs_recentes)): ?>
        <p style="color:var(--muted);font-size:.9rem">Nenhuma mensagem ainda.</p>
      <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Nome</th><th>Assunto</th><th>Data</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach($msgs_recentes as $m): ?>
          <tr>
            <td><strong><?= htmlspecialchars($m['nome']) ?></strong><br><small style="color:var(--muted)"><?= htmlspecialchars($m['email']) ?></small></td>
            <td><?= htmlspecialchars(substr($m['assunto']?:$m['mensagem'],0,50)) ?>...</td>
            <td><?= date('d/m H:i',strtotime($m['enviado_em'])) ?></td>
            <td><?= $m['lida'] ? '<span class="badge badge-green">Lida</span>' : '<span class="badge badge-red">Nova</span>' ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
  </main>
</div>

</body>
</html>

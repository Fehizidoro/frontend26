<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if(estaLogado()){ header('Location: index.php'); exit; }

$erro = '';
$campos_erro = [];

if($_SERVER['REQUEST_METHOD']==='POST'){
    $usuario = trim($_POST['usuario']??'');
    $senha   = $_POST['senha']??'';

    if(empty($usuario)){
        $campos_erro['usuario'] = 'Informe o usuário ou e-mail.';
    }
    if(empty($senha)){
        $campos_erro['senha'] = 'Informe a senha.';
    }

    if(empty($campos_erro)){
        // aceita login por usuário OU por e-mail
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE usuario=? OR email=? LIMIT 1");
        $stmt->execute([$usuario,$usuario]);
        $user = $stmt->fetch();

        if($user && password_verify($senha, $user['senha'])){
            $_SESSION['uid']   = $user['id'];
            $_SESSION['nome']  = $user['nome'];
            $_SESSION['tipo']  = $user['tipo'];
            // lembrar login
            if(!empty($_POST['lembrar'])){
                setcookie('lembrar_usuario', $user['usuario'], time()+60*60*24*30, '/');
            }
            header('Location: index.php');
            exit;
        } else {
            $erro = 'Usuário/e-mail ou senha incorretos.';
        }
    }
}

$lembrar_val = $_COOKIE['lembrar_usuario'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login — Bella Vista Admin</title>
<link rel="stylesheet" href="../css/styles.css">
</head>
<body>

<div class="auth-page">
  <!-- Visual lateral -->
  <div class="auth-visual">
    <div class="auth-visual-content">
      <a href="../index.php" class="logo">Bella<span>Vista</span></a>
      <p>Painel de gestão do restaurante.<br>Faça login para continuar.</p>
      <div class="auth-visual-quote">
        "A culinária é a arte de transformar ingredientes simples em memórias eternas."
      </div>
    </div>
  </div>

  <!-- Formulário -->
  <div class="auth-form-side">
    <div class="auth-box">
      <h1>Bem-vindo <em>de volta</em></h1>
      <p class="auth-sub">Entre com suas credenciais para acessar o painel.</p>

      <?php if($erro): ?>
        <div class="flash flash-erro" style="background:#fde8eb;color:#8b1a2a">❌ <?= htmlspecialchars($erro) ?></div>
      <?php endif; ?>

      <form method="POST" id="loginForm" novalidate>
        <div class="input-group">
          <label for="usuario">Usuário ou E-mail</label>
          <span class="input-icon">👤</span>
          <input type="text" id="usuario" name="usuario"
                 placeholder="seu_usuario ou email@exemplo.com"
                 value="<?= htmlspecialchars($lembrar_val ?: ($_POST['usuario']??'')) ?>"
                 class="<?= isset($campos_erro['usuario'])?'error-field':'' ?>"
                 autocomplete="username" required>
          <?php if(isset($campos_erro['usuario'])): ?>
            <div class="field-error show"><?= $campos_erro['usuario'] ?></div>
          <?php endif; ?>
        </div>

        <div class="input-group">
          <label for="senha">Senha</label>
          <span class="input-icon">🔒</span>
          <input type="password" id="senha" name="senha"
                 placeholder="••••••••"
                 class="<?= isset($campos_erro['senha'])?'error-field':'' ?>"
                 autocomplete="current-password" required>
          <button type="button" class="toggle-pass" onclick="togglePass()" title="Mostrar/ocultar senha">👁</button>
          <?php if(isset($campos_erro['senha'])): ?>
            <div class="field-error show"><?= $campos_erro['senha'] ?></div>
          <?php endif; ?>
        </div>

        <div class="form-options">
          <label class="checkbox-label">
            <input type="checkbox" name="lembrar" <?= $lembrar_val?'checked':'' ?>>
            Lembrar meu usuário
          </label>
          <a href="recuperar.php" class="forgot-link">Esqueci minha senha</a>
        </div>

        <button type="submit" class="btn btn-gold btn-full" id="submitBtn">
          Entrar no Painel →
        </button>
      </form>

      <div class="auth-divider">ou</div>

      <div class="auth-footer">
        Não tem conta? <a href="cadastro.php">Cadastre-se aqui</a>
      </div>
      <div class="auth-footer" style="margin-top:12px">
        <a href="../index.php">← Voltar ao site</a>
      </div>
    </div>
  </div>
</div>

<script>
function togglePass(){
  const inp = document.getElementById('senha');
  inp.type = inp.type==='password' ? 'text' : 'password';
}
// Loading state ao submeter
document.getElementById('loginForm').addEventListener('submit', function(){
  const btn = document.getElementById('submitBtn');
  btn.textContent = 'Entrando...';
  btn.classList.add('btn-loading');
});
</script>
</body>
</html>

<?php
require_once '../includes/functions.php';
session_destroy();
setcookie('lembrar_usuario','',time()-3600,'/');
header('Location: login.php');
exit;

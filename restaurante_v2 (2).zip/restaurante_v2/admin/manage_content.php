<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
requerLogin();

if($_SERVER['REQUEST_METHOD']==='POST'){
    foreach($_POST as $k=>$v){
        if($k==='salvar') continue;
        $pdo->prepare("UPDATE conteudos SET valor=? WHERE chave=?")->execute([trim($v),$k]);
    }
    flash('✅ Conteúdo atualizado com sucesso!');
    header('Location: manage_content.php'); exit;
}

$stmt = $pdo->query("SELECT chave,valor FROM conteudos");
$c = [];
while($r=$stmt->fetch()) $c[$r['chave']] = $r['valor'];

$grupos = [
    '🏠 Página Inicial'      => ['home_titulo','home_subtitulo','home_descricao'],
    '📖 Página Sobre'         => ['sobre_titulo','sobre_texto','sobre_missao'],
    '📞 Informações de Contato' => ['contato_endereco','contato_telefone','contato_email','contato_horario'],
    '⬇️ Rodapé'              => ['rodape_texto'],
];
$labels = [
    'home_titulo'=>'Título principal','home_subtitulo'=>'Subtítulo','home_descricao'=>'Descrição',
    'sobre_titulo'=>'Título','sobre_texto'=>'Texto da história','sobre_missao'=>'Nossa missão',
    'contato_endereco'=>'Endereço','contato_telefone'=>'Telefone','contato_email'=>'E-mail','contato_horario'=>'Horário',
    'rodape_texto'=>'Texto do rodapé',
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Editar Conteúdo — Admin</title>
<link rel="stylesheet" href="../css/styles.css">
</head>
<body>
<div class="admin-layout">
  <?php include 'sidebar.php'; ?>
  <main class="admin-main">
    <div class="admin-topbar">
      <h1>Editar <em>Conteúdo</em></h1>
    </div>
    <?php renderFlash(); ?>

    <form method="POST" class="form-admin">
      <?php foreach($grupos as $grupo => $chaves): ?>
      <div class="admin-card" style="margin-bottom:24px">
        <div class="admin-card-header"><h2><?= $grupo ?></h2></div>
        <?php foreach($chaves as $chave):
          $val = $c[$chave]??'';
          $longo = strlen($val)>80;
        ?>
        <div>
          <label><?= $labels[$chave]??$chave ?></label>
          <?php if($longo): ?>
            <textarea name="<?= $chave ?>"><?= htmlspecialchars($val) ?></textarea>
          <?php else: ?>
            <input type="text" name="<?= $chave ?>" value="<?= htmlspecialchars($val) ?>">
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endforeach; ?>
      <button type="submit" name="salvar" class="btn btn-gold">💾 Salvar Alterações</button>
    </form>
  </main>
</div>
</body>
</html>

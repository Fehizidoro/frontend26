<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
requerLogin();

if(isset($_GET['lida'])){
    $pdo->prepare("UPDATE contatos SET lida=1 WHERE id=?")->execute([(int)$_GET['lida']]);
    header('Location: mensagens.php'); exit;
}
if(isset($_GET['excluir'])){
    $pdo->prepare("DELETE FROM contatos WHERE id=?")->execute([(int)$_GET['excluir']]);
    flash('✅ Mensagem excluída.'); header('Location: mensagens.php'); exit;
}
if(isset($_GET['lerTodas'])){
    $pdo->query("UPDATE contatos SET lida=1");
    flash('✅ Todas marcadas como lidas.'); header('Location: mensagens.php'); exit;
}

$msgs = $pdo->query("SELECT * FROM contatos ORDER BY enviado_em DESC")->fetchAll();
$novas = array_filter($msgs, fn($m)=>!$m['lida']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mensagens — Admin</title>
<link rel="stylesheet" href="../css/styles.css">
</head>
<body>
<div class="admin-layout">
  <?php include 'sidebar.php'; ?>
  <main class="admin-main">
    <div class="admin-topbar">
      <h1>Mensagens <em>de Contato</em></h1>
      <?php if(count($novas)>0): ?>
        <a href="?lerTodas=1" class="btn btn-sm" style="background:#27ae60;color:#fff">✅ Marcar todas como lidas</a>
      <?php endif; ?>
    </div>
    <?php renderFlash(); ?>

    <div class="admin-card">
      <?php if(empty($msgs)): ?>
        <p style="color:var(--muted)">Nenhuma mensagem recebida.</p>
      <?php else: ?>
      <table class="data-table">
        <thead><tr><th></th><th>Remetente</th><th>Assunto / Mensagem</th><th>Telefone</th><th>Data</th><th>Ações</th></tr></thead>
        <tbody>
          <?php foreach($msgs as $m): ?>
          <tr style="<?= !$m['lida']?'background:#fffbf3':'' ?>">
            <td><?= $m['lida']?'<span class="badge badge-green">Lida</span>':'<span class="badge badge-red">Nova</span>' ?></td>
            <td>
              <strong><?= htmlspecialchars($m['nome']) ?></strong><br>
              <a href="mailto:<?= htmlspecialchars($m['email']) ?>" style="color:var(--gold);font-size:.82rem"><?= htmlspecialchars($m['email']) ?></a>
            </td>
            <td>
              <?php if($m['assunto']): ?><strong style="font-size:.85rem"><?= htmlspecialchars($m['assunto']) ?></strong><br><?php endif; ?>
              <span style="color:var(--muted);font-size:.85rem"><?= htmlspecialchars(substr($m['mensagem'],0,80)) ?>...</span>
            </td>
            <td><?= htmlspecialchars($m['telefone']?:'-') ?></td>
            <td style="font-size:.82rem"><?= date('d/m/Y H:i',strtotime($m['enviado_em'])) ?></td>
            <td style="display:flex;gap:6px">
              <?php if(!$m['lida']): ?>
                <a href="?lida=<?= $m['id'] ?>" class="btn btn-sm" style="background:#27ae60;color:#fff" title="Marcar como lida">✅</a>
              <?php endif; ?>
              <a href="?excluir=<?= $m['id'] ?>" onclick="return confirm('Excluir?')" class="btn btn-sm btn-red">🗑️</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
  </main>
</div>
</body>
</html>

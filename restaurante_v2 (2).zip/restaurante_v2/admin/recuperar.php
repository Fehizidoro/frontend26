<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if(estaLogado()){ header('Location: index.php'); exit; }

$passo   = $_GET['passo'] ?? '1';
$token   = $_GET['token'] ?? '';
$sucesso = $erro = '';

// PASSO 2 — validar token e mostrar form de nova senha
if($passo==='2' && $token){
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE token_reset=? AND token_expira > NOW()");
    $stmt->execute([$token]);
    $user_reset = $stmt->fetch();
    if(!$user_reset){ $erro='Link inválido ou expirado. Solicite um novo.'; $passo='1'; }
}

// PROCESSAR PASSO 1 — gerar token (simulado, exibe na tela pois não temos SMTP)
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['passo']??'')==='1'){
    $email = limpar($_POST['email']??'');
    if(empty($email)||!filter_var($email,FILTER_VALIDATE_EMAIL)){
        $erro='Informe um e-mail válido.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email=?");
        $stmt->execute([$email]);
        $u = $stmt->fetch();
        if($u){
            $tk = bin2hex(random_bytes(24));
            $exp = date('Y-m-d H:i:s', strtotime('+1 hour'));
            $pdo->prepare("UPDATE usuarios SET token_reset=?,token_expira=? WHERE id=?")
                ->execute([$tk, $exp, $u['id']]);
            // Em produção, enviaria e-mail. Aqui exibimos o link:
            $link = "http://localhost/restaurante_v2/admin/recuperar.php?passo=2&token=$tk";
            $sucesso = "Link gerado! Em produção seria enviado por e-mail. Para testar, clique: <a href='$link' style='color:var(--gold)'>Redefinir senha</a>";
        } else {
            // Por segurança, não informamos se o e-mail existe ou não
            $sucesso='Se esse e-mail estiver cadastrado, você receberá as instruções.';
        }
    }
}

// PROCESSAR PASSO 2 — salvar nova senha
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['passo']??'')==='2'){
    $token   = $_POST['token']??'';
    $nova    = $_POST['nova']??'';
    $confirma= $_POST['confirma']??'';

    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE token_reset=? AND token_expira > NOW()");
    $stmt->execute([$token]);
    $u = $stmt->fetch();

    if(!$u){ $erro='Token inválido ou expirado.'; }
    elseif(strlen($nova)<6){ $erro='A senha deve ter ao menos 6 caracteres.'; }
    elseif($nova!==$confirma){ $erro='As senhas não coincidem.'; }
    else {
        $hash = password_hash($nova, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE usuarios SET senha=?,token_reset=NULL,token_expira=NULL WHERE id=?")
            ->execute([$hash, $u['id']]);
        $sucesso='✅ Senha redefinida com sucesso! <a href="login.php" style="color:var(--gold);font-weight:700">Fazer login →</a>';
        $passo = 'ok';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Recuperar Senha — Bella Vista</title>
<link rel="stylesheet" href="../css/styles.css">
</head>
<body>

<div class="auth-page">
  <div class="auth-visual">
    <div class="auth-visual-content">
      <a href="../index.php" class="logo">Bella<span>Vista</span></a>
      <p>Recuperação de acesso ao painel administrativo.</p>
    </div>
  </div>

  <div class="auth-form-side">
    <div class="auth-box">

      <?php if($passo==='1' || $passo==='ok'): ?>
      <h1>Recuperar <em>senha</em></h1>
      <p class="auth-sub">Informe seu e-mail cadastrado.</p>

      <?php if($sucesso): ?>
        <div class="flash" style="background:#d4edda;color:#155724"><?= $sucesso ?></div>
      <?php endif; ?>
      <?php if($erro): ?>
        <div class="flash" style="background:#fde8eb;color:#8b1a2a">❌ <?= htmlspecialchars($erro) ?></div>
      <?php endif; ?>

      <?php if($passo!=='ok'): ?>
      <form method="POST">
        <input type="hidden" name="passo" value="1">
        <div class="input-group">
          <label>E-mail cadastrado</label>
          <span class="input-icon">✉️</span>
          <input type="email" name="email" placeholder="email@exemplo.com" required>
        </div>
        <button type="submit" class="btn btn-gold btn-full">Enviar link de recuperação</button>
      </form>
      <?php endif; ?>

      <?php elseif($passo==='2' && isset($user_reset)): ?>
      <h1>Nova <em>senha</em></h1>
      <p class="auth-sub">Defina sua nova senha de acesso.</p>

      <?php if($erro): ?>
        <div class="flash" style="background:#fde8eb;color:#8b1a2a">❌ <?= htmlspecialchars($erro) ?></div>
      <?php endif; ?>

      <form method="POST">
        <input type="hidden" name="passo" value="2">
        <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
        <div class="input-group">
          <label>Nova senha</label>
          <span class="input-icon">🔒</span>
          <input type="password" name="nova" id="novaSenha" placeholder="mín. 6 caracteres" required oninput="checkStr(this.value)">
          <button type="button" class="toggle-pass" onclick="togglePass('novaSenha')">👁</button>
          <div class="strength-wrap">
            <div class="strength-bar"><div class="strength-fill" id="sf"></div></div>
            <div class="strength-text" id="st">Digite uma senha</div>
          </div>
        </div>
        <div class="input-group">
          <label>Confirmar nova senha</label>
          <span class="input-icon">🔒</span>
          <input type="password" name="confirma" id="conf" placeholder="repita a senha" required>
          <button type="button" class="toggle-pass" onclick="togglePass('conf')">👁</button>
        </div>
        <button type="submit" class="btn btn-gold btn-full">Salvar nova senha</button>
      </form>
      <?php endif; ?>

      <div class="auth-footer" style="margin-top:24px">
        <a href="login.php">← Voltar ao login</a>
      </div>
    </div>
  </div>
</div>

<script>
function togglePass(id){ const i=document.getElementById(id); i.type=i.type==='password'?'text':'password'; }
function checkStr(v){
  const f=document.getElementById('sf'), t=document.getElementById('st');
  let s=0;
  if(v.length>=6)s++; if(v.length>=10)s++; if(/[A-Z]/.test(v))s++; if(/[0-9]/.test(v))s++; if(/[^A-Za-z0-9]/.test(v))s++;
  const ls=[{w:'0%',c:'#e74c3c',t:'Muito fraca'},{w:'20%',c:'#e74c3c',t:'Fraca'},{w:'40%',c:'#f39c12',t:'Razoável'},{w:'70%',c:'#f1c40f',t:'Boa'},{w:'90%',c:'#2ecc71',t:'Forte'},{w:'100%',c:'#27ae60',t:'Muito forte ✓'}];
  const l=ls[s]; f.style.width=l.w; f.style.background=l.c; t.textContent=v.length?l.t:'Digite uma senha'; t.style.color=v.length?l.c:'var(--muted)';
}
</script>
</body>
</html>

<?php
$msgs_novas = $pdo->query("SELECT COUNT(*) FROM contatos WHERE lida=0")->fetchColumn();
$current = basename($_SERVER['PHP_SELF']);
?>
<aside class="admin-sidebar">
  <div class="sidebar-logo">Bella<span>Vista</span></div>

  <div class="sidebar-section">Principal</div>
  <ul class="sidebar-nav">
    <li><a href="index.php" class="<?= $current==='index.php'?'active':'' ?>">🏠 Dashboard</a></li>
    <li><a href="manage_content.php" class="<?= $current==='manage_content.php'?'active':'' ?>">✏️ Editar Conteúdo</a></li>
  </ul>

  <div class="sidebar-section">Cardápio</div>
  <ul class="sidebar-nav">
    <li><a href="cardapio.php" class="<?= $current==='cardapio.php'?'active':'' ?>">🍝 Pratos</a></li>
  </ul>

  <div class="sidebar-section">Usuários</div>
  <ul class="sidebar-nav">
    <li><a href="usuarios.php" class="<?= $current==='usuarios.php'?'active':'' ?>">👥 Gerenciar</a></li>
  </ul>

  <div class="sidebar-section">Comunicação</div>
  <ul class="sidebar-nav">
    <li>
      <a href="mensagens.php" class="<?= $current==='mensagens.php'?'active':'' ?>">
        ✉️ Mensagens
        <?php if($msgs_novas>0): ?><span class="sidebar-badge"><?= $msgs_novas ?></span><?php endif; ?>
      </a>
    </li>
  </ul>

  <div class="sidebar-section">Site</div>
  <ul class="sidebar-nav">
    <li><a href="../index.php" target="_blank">🌐 Ver Site</a></li>
    <li><a href="logout.php" style="color:#ff8080!important">🚪 Sair</a></li>
  </ul>

  <div class="sidebar-user">
    <strong><?= htmlspecialchars($_SESSION['nome']) ?></strong>
    <?= ucfirst($_SESSION['tipo']) ?>
  </div>
</aside>

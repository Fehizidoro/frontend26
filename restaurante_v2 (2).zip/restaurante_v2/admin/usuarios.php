<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
requerLogin();

if(isset($_GET['excluir'])){
    $id=(int)$_GET['excluir'];
    if($id===$_SESSION['uid']){ flash('⚠️ Você não pode excluir sua própria conta.','aviso'); }
    else { $pdo->prepare("DELETE FROM usuarios WHERE id=?")->execute([$id]); flash('✅ Usuário removido.'); }
    header('Location: usuarios.php'); exit;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    $nome    = limpar($_POST['nome']??'');
    $email   = limpar($_POST['email']??'');
    $usuario = limpar($_POST['usuario']??'');
    $senha   = $_POST['senha']??'';
    $tipo    = in_array($_POST['tipo']??'',['admin','editor'])?$_POST['tipo']:'editor';

    if(empty($nome)||empty($email)||empty($usuario)||empty($senha)){
        flash('⚠️ Preencha todos os campos.','erro');
    } elseif(strlen($senha)<6){
        flash('⚠️ Senha mínima de 6 caracteres.','erro');
    } else {
        $s=$pdo->prepare("SELECT id FROM usuarios WHERE usuario=? OR email=?");
        $s->execute([$usuario,$email]);
        if($s->fetch()){ flash('⚠️ Usuário ou e-mail já cadastrado.','erro'); }
        else {
            $pdo->prepare("INSERT INTO usuarios(nome,email,usuario,senha,tipo) VALUES(?,?,?,?,?)")
                ->execute([$nome,$email,$usuario,password_hash($senha,PASSWORD_DEFAULT),$tipo]);
            flash('✅ Usuário criado!');
        }
    }
    header('Location: usuarios.php'); exit;
}

$usuarios = $pdo->query("SELECT id,nome,email,usuario,tipo,criado_em FROM usuarios ORDER BY criado_em DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Usuários — Admin</title>
<link rel="stylesheet" href="../css/styles.css">
</head>
<body>
<div class="admin-layout">
  <?php include 'sidebar.php'; ?>
  <main class="admin-main">
    <div class="admin-topbar"><h1>Gerenciar <em>Usuários</em></h1></div>
    <?php renderFlash(); ?>

    <div class="admin-card">
      <div class="admin-card-header"><h2>➕ Adicionar Usuário</h2></div>
      <form method="POST" class="form-admin">
        <div class="form-grid-2">
          <div><label>Nome completo</label><input type="text" name="nome" required></div>
          <div><label>E-mail</label><input type="email" name="email" required></div>
          <div><label>Usuário</label><input type="text" name="usuario" required></div>
          <div><label>Senha (mín. 6 chars)</label><input type="password" name="senha" required></div>
          <div>
            <label>Tipo de acesso</label>
            <select name="tipo">
              <option value="editor">Editor</option>
              <option value="admin">Administrador</option>
            </select>
          </div>
          <div style="display:flex;align-items:flex-end">
            <button type="submit" class="btn btn-gold" style="width:100%">➕ Criar Usuário</button>
          </div>
        </div>
      </form>
    </div>

    <div class="admin-card">
      <div class="admin-card-header"><h2>👥 Usuários (<?= count($usuarios) ?>)</h2></div>
      <table class="data-table">
        <thead><tr><th>Nome</th><th>Usuário</th><th>E-mail</th><th>Tipo</th><th>Cadastrado</th><th>Ação</th></tr></thead>
        <tbody>
          <?php foreach($usuarios as $u): ?>
          <tr>
            <td>
              <?= htmlspecialchars($u['nome']) ?>
              <?php if($u['id']==$_SESSION['uid']): ?><span class="badge badge-yellow">Você</span><?php endif; ?>
            </td>
            <td><code style="background:var(--warm);padding:2px 8px;border-radius:4px;font-size:.82rem"><?= htmlspecialchars($u['usuario']) ?></code></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td><span class="badge <?= $u['tipo']==='admin'?'badge-red':'badge-blue' ?>"><?= ucfirst($u['tipo']) ?></span></td>
            <td><?= date('d/m/Y',strtotime($u['criado_em'])) ?></td>
            <td>
              <?php if($u['id']!=$_SESSION['uid']): ?>
                <a href="?excluir=<?= $u['id'] ?>" onclick="return confirm('Excluir?')" class="btn btn-sm btn-red">🗑️</a>
              <?php else: ?>—<?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
</body>
</html>

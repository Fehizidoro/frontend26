-- ============================================
-- BANCO DE DADOS: bella_vista
-- Execute no phpMyAdmin > Importar
-- Depois acesse /setup.php para criar o admin
-- ============================================

CREATE DATABASE IF NOT EXISTS bella_vista CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bella_vista;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('admin','editor') DEFAULT 'editor',
    token_reset VARCHAR(100) DEFAULT NULL,
    token_expira DATETIME DEFAULT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS conteudos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chave VARCHAR(100) NOT NULL UNIQUE,
    valor TEXT NOT NULL,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cardapio (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10,2) NOT NULL,
    categoria VARCHAR(50),
    foto_url VARCHAR(500),
    destaque TINYINT(1) DEFAULT 0,
    ativo TINYINT(1) DEFAULT 1,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS contatos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    telefone VARCHAR(20),
    assunto VARCHAR(100),
    mensagem TEXT NOT NULL,
    lida TINYINT(1) DEFAULT 0,
    enviado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Conteudos
INSERT INTO conteudos (chave, valor) VALUES
('home_titulo',       'Sabores que contam histórias'),
('home_subtitulo',    'Culinária italiana autêntica desde 2003'),
('home_descricao',    'Ingredientes frescos, receitas tradicionais e um ambiente acolhedor. Cada prato é preparado com dedicação para criar momentos inesquecíveis à mesa.'),
('sobre_titulo',      'Nossa História'),
('sobre_texto',       'O Bella Vista nasceu do sonho de trazer a verdadeira culinária italiana para o Brasil. Fundado em 2003 pela família Rossi, nosso restaurante preserva receitas passadas de geração em geração, combinadas com ingredientes frescos selecionados diariamente.'),
('sobre_missao',      'Proporcionar experiências gastronômicas inesquecíveis, unindo tradição italiana, ingredientes de qualidade e um atendimento caloroso que faz você se sentir em casa.'),
('contato_endereco',  'Rua das Flores, 123 — Centro, São Paulo/SP'),
('contato_telefone',  '(11) 99999-9999'),
('contato_email',     'contato@bellavista.com.br'),
('contato_horario',   'Seg–Sex: 11h–23h  |  Sáb–Dom: 11h–00h'),
('rodape_texto',      '© 2025 Restaurante Bella Vista. Todos os direitos reservados.');

-- Cardápio com fotos reais do Unsplash
INSERT INTO cardapio (nome, descricao, preco, categoria, foto_url, destaque, ativo) VALUES
-- Entradas
('Bruschetta al Pomodoro',    'Pão rústico tostado com tomate cereja, manjericão fresco e azeite extravirgem',                    28.90, 'Entradas',        'https://images.unsplash.com/photo-1572695157366-5e585ab2b69f?w=600&q=80', 0, 1),
('Carpaccio de Filé',         'Finas fatias de filé mignon curado, alcaparras, rúcula, lascas de parmesão e limão siciliano',     48.90, 'Entradas',        'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600&q=80', 1, 1),
('Burrata com Presunto',      'Burrata cremosa com presunto parma, tomates-cereja e redução de balsâmico',                        52.90, 'Entradas',        'https://images.unsplash.com/photo-1505253716362-afaea1d3d1af?w=600&q=80', 0, 1),
-- Massas
('Spaghetti Carbonara',       'Massa artesanal, pancetta crocante, gema de ovo, pecorino romano e pimenta-do-reino moída na hora',62.90, 'Massas',          'https://images.unsplash.com/photo-1612874742237-6526221588e3?w=600&q=80', 1, 1),
('Fettuccine Funghi Porcini', 'Fettuccine fresco com cogumelos porcini, manteiga trufada, creme e parmesão',                     68.90, 'Massas',          'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&q=80', 0, 1),
('Lasanha da Nonna',          'Camadas de massa fresca, ragù bolonhesa lento, béchamel artesanal e parmesão gratinado',           65.90, 'Massas',          'https://images.unsplash.com/photo-1574894709920-11b28e7367e3?w=600&q=80', 1, 1),
('Rigatoni all\'Amatriciana',  'Rigatoni bronze com guanciale, tomate San Marzano, pecorino e pimenta calabresa',                  59.90, 'Massas',          'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=600&q=80', 0, 1),
-- Pratos Principais
('Frango à Parmegiana',       'Filé de frango empanado na farinha italiana, molho pomodoro, mussarela de búfala e manjericão',    58.90, 'Pratos Principais','https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&q=80', 0, 1),
('Salmão Grelhado',           'Filé de salmão atlântico grelhado, aspargos, purê de ervilha e manteiga de ervas',                 84.90, 'Pratos Principais','https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=600&q=80', 1, 1),
('Ossobuco alla Milanese',    'Jarrete de vitela braseado lentamente com gremolata e risoto de açafrão',                          98.90, 'Pratos Principais','https://images.unsplash.com/photo-1544025162-d76694265947?w=600&q=80', 0, 1),
-- Pizzas
('Pizza Margherita',          'Molho San Marzano, mussarela de búfala, manjericão fresco e azeite aromatizado',                   52.90, 'Pizzas',           'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=600&q=80', 1, 1),
('Pizza Quattro Formaggi',    'Mussarela, gorgonzola, parmesão e fontina sobre base de creme de alho',                           62.90, 'Pizzas',           'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&q=80', 0, 1),
('Pizza Tartufo',             'Base de creme trufado, cogumelos frescos, mussarela e lascas de trufas negras',                    89.90, 'Pizzas',           'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=600&q=80', 0, 1),
-- Sobremesas
('Tiramisù Classico',         'Receita original com savoiardi, mascarpone, café espresso e cacau belga peneirado',                34.90, 'Sobremesas',       'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=600&q=80', 1, 1),
('Panna Cotta al Frutti',     'Panna cotta de baunilha com calda de frutas vermelhas frescas e coulis de framboesa',              29.90, 'Sobremesas',       'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=600&q=80', 0, 1),
('Cannoli Siciliani',         'Cannoli crocantes recheados na hora com ricota adocicada, pistache e frutas cristalizadas',        32.90, 'Sobremesas',       'https://images.unsplash.com/photo-1551024601-bec78aea704b?w=600&q=80', 0, 1);

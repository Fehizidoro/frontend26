<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
$rodape   = getConteudo($pdo,'rodape_texto');
$endereco = getConteudo($pdo,'contato_endereco');
$telefone = getConteudo($pdo,'contato_telefone');
$email    = getConteudo($pdo,'contato_email');
$horario  = getConteudo($pdo,'contato_horario');
$sucesso  = $erro = '';

if($_SERVER['REQUEST_METHOD']==='POST'){
    $nome     = limpar($_POST['nome']??'');
    $emailF   = limpar($_POST['email']??'');
    $tel      = limpar($_POST['telefone']??'');
    $assunto  = limpar($_POST['assunto']??'');
    $mensagem = limpar($_POST['mensagem']??'');
    if(empty($nome)||empty($emailF)||empty($mensagem)){
        $erro='⚠️ Preencha nome, e-mail e mensagem.';
    }elseif(!filter_var($emailF,FILTER_VALIDATE_EMAIL)){
        $erro='⚠️ E-mail inválido.';
    }else{
        $pdo->prepare("INSERT INTO contatos(nome,email,telefone,assunto,mensagem) VALUES(?,?,?,?,?)")
            ->execute([$nome,$emailF,$tel,$assunto,$mensagem]);
        $sucesso='✅ Mensagem enviada! Responderemos em até 24h.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Contato — Bella Vista</title>
<link rel="stylesheet" href="css/styles.css">
</head>
<body>

<header class="site-header">
  <div class="header-inner">
    <a href="index.php" class="site-logo">Bella<span>Vista</span></a>
    <ul class="site-nav">
      <li><a href="index.php">Início</a></li>
      <li><a href="about.php">Sobre</a></li>
      <li><a href="services.php">Cardápio</a></li>
      <li><a href="contact.php" class="active">Contato</a></li>
      <?php if(estaLogado()): ?>
        <li><a href="admin/index.php" class="nav-cta">⚙ Admin</a></li>
      <?php else: ?>
        <li><a href="admin/login.php" class="nav-cta">Entrar</a></li>
      <?php endif; ?>
    </ul>
  </div>
</header>

<section class="section" style="padding-top:110px">
  <div class="section-inner">
    <div class="section-header">
      <span class="section-label">✦ Fale conosco</span>
      <h2 class="section-title">Reservas & <em>Contato</em></h2>
      <div class="divider"></div>
    </div>

    <div class="contato-grid">
      <div>
        <div class="info-item">
          <div class="info-icon">📍</div>
          <div><div class="info-lbl">Endereço</div><div class="info-val"><?= htmlspecialchars($endereco) ?></div></div>
        </div>
        <div class="info-item">
          <div class="info-icon">📞</div>
          <div><div class="info-lbl">Telefone / WhatsApp</div><div class="info-val"><?= htmlspecialchars($telefone) ?></div></div>
        </div>
        <div class="info-item">
          <div class="info-icon">✉️</div>
          <div><div class="info-lbl">E-mail</div><div class="info-val"><?= htmlspecialchars($email) ?></div></div>
        </div>
        <div class="info-item">
          <div class="info-icon">🕐</div>
          <div><div class="info-lbl">Horários</div><div class="info-val"><?= htmlspecialchars($horario) ?></div></div>
        </div>
        <div style="margin-top:24px;background:var(--warm);padding:22px;border-radius:12px">
          <strong style="color:var(--text);font-size:.88rem;text-transform:uppercase;letter-spacing:.5px">Reservas para grupos</strong>
          <p style="color:var(--muted);font-size:.87rem;margin-top:8px;line-height:1.7">Grupos acima de 10 pessoas têm menu especial. Entre em contato com pelo menos 48h de antecedência.</p>
        </div>
      </div>

      <div class="form-card">
        <h3>Envie uma mensagem</h3>
        <?php if($sucesso): ?>
          <div class="flash" style="background:#d4edda;color:#155724"><?= $sucesso ?></div>
        <?php endif; ?>
        <?php if($erro): ?>
          <div class="flash" style="background:#f8d7da;color:#721c24"><?= $erro ?></div>
        <?php endif; ?>

        <form method="POST">
          <div class="form-row">
            <div class="form-group">
              <label>Nome *</label>
              <input type="text" name="nome" required value="<?= htmlspecialchars($_POST['nome']??'') ?>">
            </div>
            <div class="form-group">
              <label>E-mail *</label>
              <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email']??'') ?>">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Telefone</label>
              <input type="text" name="telefone" value="<?= htmlspecialchars($_POST['telefone']??'') ?>">
            </div>
            <div class="form-group">
              <label>Assunto</label>
              <input type="text" name="assunto" placeholder="Ex: Reserva para 4 pessoas" value="<?= htmlspecialchars($_POST['assunto']??'') ?>">
            </div>
          </div>
          <div class="form-group">
            <label>Mensagem *</label>
            <textarea name="mensagem" required><?= htmlspecialchars($_POST['mensagem']??'') ?></textarea>
          </div>
          <button type="submit" class="btn btn-gold btn-full" style="border-radius:10px">Enviar Mensagem →</button>
        </form>
      </div>
    </div>
  </div>
</section>

<footer class="site-footer">
  <div class="footer-bottom" style="border-top:none;padding:24px 40px">
    <p><?= htmlspecialchars($rodape) ?> | <a href="admin/login.php">Admin</a></p>
  </div>
</footer>
</body>
</html>

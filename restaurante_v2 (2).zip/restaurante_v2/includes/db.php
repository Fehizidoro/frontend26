<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'bella_vista');

try {
    $pdo = new PDO(
        "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    die("
    <div style='font-family:sans-serif;max-width:600px;margin:60px auto;padding:30px;background:#fff3cd;border-radius:12px;border:1px solid #ffc107'>
        <h2>⚠️ Erro no Banco de Dados</h2>
        <p><b>Erro:</b> ".htmlspecialchars($e->getMessage())."</p>
        <hr>
        <p>Verifique em <code>includes/db.php</code>:</p>
        <ul>
            <li>MySQL está rodando no XAMPP?</li>
            <li>Você importou o <code>banco_de_dados.sql</code>?</li>
            <li>O banco se chama <b>bella_vista</b>?</li>
            <li>Usuário/senha corretos? (padrão XAMPP: root / sem senha)</li>
        </ul>
        <a href='../setup.php' style='background:#c0392b;color:white;padding:10px 20px;border-radius:6px;text-decoration:none'>Ir para o Setup</a>
    </div>");
}

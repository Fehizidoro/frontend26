<?php
if (session_status() === PHP_SESSION_NONE) session_start();

function getConteudo($pdo, $chave, $fallback = '') {
    $stmt = $pdo->prepare("SELECT valor FROM conteudos WHERE chave = ?");
    $stmt->execute([$chave]);
    $r = $stmt->fetch();
    return $r ? $r['valor'] : $fallback;
}

function estaLogado() {
    return isset($_SESSION['uid']);
}

function requerLogin() {
    if (!estaLogado()) {
        header('Location: ../admin/login.php');
        exit;
    }
}

function limpar($v) {
    return htmlspecialchars(strip_tags(trim($v)));
}

function flash($msg, $tipo = 'ok') {
    $_SESSION['flash'] = ['msg' => $msg, 'tipo' => $tipo];
}

function getFlash() {
    if (!isset($_SESSION['flash'])) return null;
    $f = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $f;
}

function renderFlash() {
    $f = getFlash();
    if (!$f) return;
    $cores = ['ok' => '#d4edda|#155724', 'erro' => '#f8d7da|#721c24', 'aviso' => '#fff3cd|#856404'];
    [$bg, $fg] = explode('|', $cores[$f['tipo']] ?? $cores['ok']);
    echo "<div class='flash flash-{$f['tipo']}' style='background:$bg;color:$fg'>{$f['msg']}</div>";
}

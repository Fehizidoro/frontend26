<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$titulo    = getConteudo($pdo,'home_titulo','Sabores que contam histórias');
$subtitulo = getConteudo($pdo,'home_subtitulo','Culinária italiana autêntica');
$descricao = getConteudo($pdo,'home_descricao','');
$rodape    = getConteudo($pdo,'rodape_texto','');

$destaques = $pdo->query("SELECT * FROM cardapio WHERE destaque=1 AND ativo=1 ORDER BY categoria LIMIT 6")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Bella Vista — Restaurante Italiano</title>
<link rel="stylesheet" href="css/styles.css">
</head>
<body>

<header class="site-header">
  <div class="header-inner">
    <a href="index.php" class="site-logo">Bella<span>Vista</span></a>
    <ul class="site-nav">
      <li><a href="index.php" class="active">Início</a></li>
      <li><a href="about.php">Sobre</a></li>
      <li><a href="services.php">Cardápio</a></li>
      <li><a href="contact.php">Contato</a></li>
      <?php if(estaLogado()): ?>
        <li><a href="admin/index.php" class="nav-cta">⚙ Admin</a></li>
      <?php else: ?>
        <li><a href="admin/login.php" class="nav-cta">Entrar</a></li>
      <?php endif; ?>
    </ul>
  </div>
</header>

<!-- HERO -->
<section class="hero">
  <div>
    <span class="hero-tag">✦ Restaurante Italiano · Desde 2003</span>
    <h1><?= nl2br(htmlspecialchars($titulo)) ?><br><em><?= htmlspecialchars($subtitulo) ?></em></h1>
    <p class="hero-desc"><?= htmlspecialchars($descricao) ?></p>
    <div class="hero-actions">
      <a href="services.php" class="btn btn-gold">Ver Cardápio Completo</a>
      <a href="contact.php" class="btn btn-outline">Reservar uma Mesa</a>
    </div>
  </div>
</section>

<!-- DESTAQUES -->
<section class="section">
  <div class="section-inner">
    <div class="section-header">
      <span class="section-label">✦ Nossos Destaques</span>
      <h2 class="section-title">Pratos que fazem<br><em>você voltar sempre</em></h2>
      <div class="divider"></div>
      <p class="section-sub">Selecionados pelo nosso chef com os melhores ingredientes do dia.</p>
    </div>

    <div class="menu-grid">
      <?php foreach($destaques as $p): ?>
      <div class="menu-card">
        <div class="card-img-wrap">
          <img class="card-img" src="<?= htmlspecialchars($p['foto_url']) ?>" alt="<?= htmlspecialchars($p['nome']) ?>" loading="lazy">
          <span class="badge-destaque">✦ Destaque</span>
        </div>
        <div class="card-body">
          <div class="card-cat"><?= htmlspecialchars($p['categoria']) ?></div>
          <div class="card-name"><?= htmlspecialchars($p['nome']) ?></div>
          <div class="card-desc"><?= htmlspecialchars($p['descricao']) ?></div>
          <div class="card-footer">
            <span class="card-price">R$ <?= number_format($p['preco'],2,',','.') ?></span>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <div style="text-align:center;margin-top:44px">
      <a href="services.php" class="btn btn-gold">Ver Cardápio Completo</a>
    </div>
  </div>
</section>

<!-- BANNER CENTRAL -->
<div style="background:linear-gradient(135deg,var(--espresso),var(--umber));padding:80px 20px;text-align:center">
  <span style="font-size:.72rem;letter-spacing:4px;text-transform:uppercase;color:var(--gold);font-weight:600">✦ Reservas</span>
  <h2 style="font-family:'Cormorant Garamond',serif;font-size:clamp(1.8rem,4vw,3rem);color:#fff;font-weight:300;margin:14px 0">
    Reserve sua mesa e viva<br><em style="color:var(--gold)">uma noite inesquecível</em>
  </h2>
  <p style="color:rgba(255,255,255,.55);margin-bottom:32px;font-size:1rem">Disponível de segunda a domingo. Grupos a partir de 10 pessoas têm menu especial.</p>
  <a href="contact.php" class="btn btn-gold">Fazer Reserva</a>
</div>

<footer class="site-footer">
  <div class="footer-main">
    <div class="footer-brand">
      <div class="logo">Bella<span>Vista</span></div>
      <p>Há mais de 20 anos servindo a autêntica culinária italiana com paixão, tradição e ingredientes selecionados.</p>
    </div>
    <div class="footer-col">
      <h4>Navegação</h4>
      <ul>
        <li><a href="index.php">Início</a></li>
        <li><a href="about.php">Sobre nós</a></li>
        <li><a href="services.php">Cardápio</a></li>
        <li><a href="contact.php">Contato & Reservas</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Contato</h4>
      <p><?= htmlspecialchars(getConteudo($pdo,'contato_endereco')) ?><br><br>
         <?= htmlspecialchars(getConteudo($pdo,'contato_telefone')) ?><br>
         <?= htmlspecialchars(getConteudo($pdo,'contato_horario')) ?></p>
    </div>
  </div>
  <div class="footer-bottom">
    <p><?= htmlspecialchars($rodape) ?> &nbsp;|&nbsp; <a href="admin/login.php">Área Administrativa</a></p>
  </div>
</footer>

</body>
</html>

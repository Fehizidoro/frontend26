<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
$rodape = getConteudo($pdo,'rodape_texto');
$pratos = $pdo->query("SELECT * FROM cardapio WHERE ativo=1 ORDER BY categoria,nome")->fetchAll();
$cats = array_unique(array_column($pratos,'categoria'));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cardápio — Bella Vista</title>
<link rel="stylesheet" href="css/styles.css">
</head>
<body>

<header class="site-header">
  <div class="header-inner">
    <a href="index.php" class="site-logo">Bella<span>Vista</span></a>
    <ul class="site-nav">
      <li><a href="index.php">Início</a></li>
      <li><a href="about.php">Sobre</a></li>
      <li><a href="services.php" class="active">Cardápio</a></li>
      <li><a href="contact.php">Contato</a></li>
      <?php if(estaLogado()): ?>
        <li><a href="admin/index.php" class="nav-cta">⚙ Admin</a></li>
      <?php else: ?>
        <li><a href="admin/login.php" class="nav-cta">Entrar</a></li>
      <?php endif; ?>
    </ul>
  </div>
</header>

<!-- BANNER -->
<div style="background:linear-gradient(rgba(0,0,0,.65),rgba(0,0,0,.65)),url('https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1400&q=80') center/cover;padding:120px 20px 60px;text-align:center;color:#fff">
  <span style="font-size:.72rem;letter-spacing:4px;text-transform:uppercase;color:var(--gold);font-weight:600;display:block;margin-bottom:14px">✦ Cardápio</span>
  <h1 style="font-family:'Cormorant Garamond',serif;font-size:clamp(2.5rem,5vw,4rem);font-weight:300">Nossa <em style="color:var(--gold-lt)">Culinária</em></h1>
  <p style="color:rgba(255,255,255,.6);margin-top:14px;font-size:1rem">Preparado com ingredientes frescos, escolhidos a cada manhã</p>
</div>

<section class="section">
  <div class="section-inner">
    <!-- Tabs -->
    <div class="menu-tabs">
      <button class="tab-btn active" data-cat="todos">Todos</button>
      <?php foreach($cats as $c): ?>
        <button class="tab-btn" data-cat="<?= htmlspecialchars($c) ?>"><?= htmlspecialchars($c) ?></button>
      <?php endforeach; ?>
    </div>

    <!-- Grid -->
    <div class="menu-grid" id="menuGrid">
      <?php foreach($pratos as $p): ?>
      <div class="menu-card" data-cat="<?= htmlspecialchars($p['categoria']) ?>">
        <div class="card-img-wrap">
          <img class="card-img"
               src="<?= htmlspecialchars($p['foto_url'] ?: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600') ?>"
               alt="<?= htmlspecialchars($p['nome']) ?>" loading="lazy">
          <?php if($p['destaque']): ?><span class="badge-destaque">✦ Destaque</span><?php endif; ?>
        </div>
        <div class="card-body">
          <div class="card-cat"><?= htmlspecialchars($p['categoria']) ?></div>
          <div class="card-name"><?= htmlspecialchars($p['nome']) ?></div>
          <div class="card-desc"><?= htmlspecialchars($p['descricao']) ?></div>
          <div class="card-footer">
            <span class="card-price">R$ <?= number_format($p['preco'],2,',','.') ?></span>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<footer class="site-footer">
  <div class="footer-bottom" style="border-top:none;padding:24px 40px">
    <p><?= htmlspecialchars($rodape) ?> | <a href="admin/login.php">Admin</a></p>
  </div>
</footer>

<script>
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const cat = btn.dataset.cat;
    document.querySelectorAll('.menu-card').forEach(card => {
      card.classList.toggle('hidden', cat !== 'todos' && card.dataset.cat !== cat);
    });
  });
});
</script>
</body>
</html>

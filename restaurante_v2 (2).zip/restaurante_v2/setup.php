<?php
require_once 'includes/db.php';
$sucesso = $erro = '';

// Bloquear se já existe admin
$existe = $pdo->query("SELECT COUNT(*) FROM usuarios WHERE tipo='admin'")->fetchColumn();

if($_SERVER['REQUEST_METHOD']==='POST'){
    if($existe){ $erro='Já existe um administrador. Delete este arquivo.'; }
    else {
        $nome    = trim($_POST['nome']??'');
        $usuario = trim($_POST['usuario']??'');
        $senha   = $_POST['senha']??'';
        if(strlen($senha)<6) $erro='Senha mínima de 6 caracteres.';
        elseif(empty($nome)||empty($usuario)) $erro='Preencha todos os campos.';
        else {
            $pdo->prepare("INSERT INTO usuarios(nome,email,usuario,senha,tipo) VALUES(?,?,?,?,'admin')")
                ->execute([$nome,"$usuario@bellavista.com",$usuario,password_hash($senha,PASSWORD_DEFAULT)]);
            $sucesso = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Setup — Bella Vista</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600&family=Cormorant+Garamond:wght@600&display=swap');
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:'DM Sans',sans-serif;background:linear-gradient(135deg,#0e0b08,#3d2b1a);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
  .box{background:#faf6f0;padding:44px;border-radius:16px;width:100%;max-width:420px;box-shadow:0 20px 60px rgba(0,0,0,.4)}
  h1{font-family:'Cormorant Garamond',serif;color:#c9a84c;font-size:1.8rem;margin-bottom:6px}
  p{color:#7a6555;font-size:.88rem;margin-bottom:24px}
  label{display:block;font-size:.75rem;font-weight:600;color:#7a6555;text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px}
  input{width:100%;padding:12px 14px;border:1.5px solid #eeddd0;border-radius:8px;font-size:.93rem;margin-bottom:16px;font-family:inherit;outline:none;transition:border .2s}
  input:focus{border-color:#c9a84c}
  button{width:100%;background:#c9a84c;color:#0e0b08;border:none;padding:13px;border-radius:8px;font-size:.95rem;cursor:pointer;font-weight:700}
  .ok{background:#d4edda;color:#155724;padding:14px;border-radius:8px;margin-bottom:16px;font-size:.9rem}
  .err{background:#fde8eb;color:#8b1a2a;padding:14px;border-radius:8px;margin-bottom:16px;font-size:.9rem}
  .warn{background:#fff3cd;color:#856404;padding:14px;border-radius:8px;margin-bottom:16px;font-size:.9rem}
  a{color:#c9a84c;font-weight:600;text-decoration:none}
  .info{font-size:.78rem;color:#9b8878;margin-top:16px;text-align:center}
</style>
</head>
<body>
<div class="box">
  <h1>🍽️ Setup Inicial</h1>
  <p>Crie o administrador do Bella Vista.<br>Execute apenas uma vez após importar o SQL.</p>

  <?php if($existe): ?>
    <div class="warn">⚠️ Já existe um admin. <a href="admin/login.php">Fazer login →</a><br><small>Delete este arquivo (setup.php) por segurança!</small></div>
  <?php elseif($sucesso): ?>
    <div class="ok">✅ Admin criado! <a href="admin/login.php">Fazer login →</a><br><small style="color:#155724">⚠️ Delete o arquivo setup.php agora!</small></div>
  <?php else: ?>
    <?php if($erro): ?><div class="err">❌ <?= htmlspecialchars($erro) ?></div><?php endif; ?>
    <form method="POST">
      <label>Nome completo</label>
      <input type="text" name="nome" value="Administrador" required>
      <label>Nome de usuário (para login)</label>
      <input type="text" name="usuario" value="admin" required>
      <label>Senha (mínimo 6 caracteres)</label>
      <input type="password" name="senha" placeholder="Crie uma senha segura" required>
      <button>Criar Administrador →</button>
    </form>
  <?php endif; ?>

  <p class="info">Banco: <strong>bella_vista</strong> | Arquivo: <code>includes/db.php</code></p>
</div>
</body>
</html>

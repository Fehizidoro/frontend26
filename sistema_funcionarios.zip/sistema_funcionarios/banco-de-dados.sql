--
-- PostgreSQL database dump
--

\restrict Gy9Yqnp0abiWmLc80R1OgdhpB5E7bXxIiATbuzdCpMRLAIR0rCQdy8xBqOnjfj8

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: employee_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.employee_status AS ENUM (
    'active',
    'inactive'
);


ALTER TYPE public.employee_status OWNER TO postgres;

--
-- Name: role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.role AS ENUM (
    'admin',
    'manager',
    'employee'
);


ALTER TYPE public.role OWNER TO postgres;

--
-- Name: task_priority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.task_priority AS ENUM (
    'low',
    'medium',
    'high',
    'urgent'
);


ALTER TYPE public.task_priority OWNER TO postgres;

--
-- Name: task_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.task_status AS ENUM (
    'pending',
    'in_progress',
    'completed',
    'approved',
    'rejected'
);


ALTER TYPE public.task_status OWNER TO postgres;

--
-- Name: time_record_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.time_record_status AS ENUM (
    'present',
    'absent',
    'partial'
);


ALTER TYPE public.time_record_status OWNER TO postgres;

--
-- Name: vacation_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.vacation_status AS ENUM (
    'pending',
    'approved',
    'rejected'
);


ALTER TYPE public.vacation_status OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    employee_id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    role public.role DEFAULT 'employee'::public.role NOT NULL,
    department text NOT NULL,
    "position" text NOT NULL,
    salary numeric(10,2) NOT NULL,
    hire_date text NOT NULL,
    phone text,
    address text,
    status public.employee_status DEFAULT 'active'::public.employee_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_id_seq OWNER TO postgres;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: observations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.observations (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    content text NOT NULL,
    created_by_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.observations OWNER TO postgres;

--
-- Name: observations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.observations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.observations_id_seq OWNER TO postgres;

--
-- Name: observations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.observations_id_seq OWNED BY public.observations.id;


--
-- Name: payroll; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    base_salary numeric(10,2) NOT NULL,
    total_worked_days integer DEFAULT 0 NOT NULL,
    total_absences integer DEFAULT 0 NOT NULL,
    bonuses numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    deductions numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    net_salary numeric(10,2) NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payroll OWNER TO postgres;

--
-- Name: payroll_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payroll_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payroll_id_seq OWNER TO postgres;

--
-- Name: payroll_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payroll_id_seq OWNED BY public.payroll.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    assigned_to_id integer NOT NULL,
    created_by_id integer NOT NULL,
    status public.task_status DEFAULT 'pending'::public.task_status NOT NULL,
    priority public.task_priority DEFAULT 'medium'::public.task_priority NOT NULL,
    due_date text,
    completed_at timestamp with time zone,
    approved_at timestamp with time zone,
    rejection_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: time_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.time_records (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    date text NOT NULL,
    entry_time text,
    lunch_start text,
    lunch_end text,
    exit_time text,
    total_hours numeric(5,2),
    status public.time_record_status DEFAULT 'partial'::public.time_record_status NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.time_records OWNER TO postgres;

--
-- Name: time_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.time_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.time_records_id_seq OWNER TO postgres;

--
-- Name: time_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.time_records_id_seq OWNED BY public.time_records.id;


--
-- Name: vacations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vacations (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    total_days integer NOT NULL,
    status public.vacation_status DEFAULT 'pending'::public.vacation_status NOT NULL,
    reason text,
    approved_by_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.vacations OWNER TO postgres;

--
-- Name: vacations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vacations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vacations_id_seq OWNER TO postgres;

--
-- Name: vacations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vacations_id_seq OWNED BY public.vacations.id;


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: observations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.observations ALTER COLUMN id SET DEFAULT nextval('public.observations_id_seq'::regclass);


--
-- Name: payroll id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll ALTER COLUMN id SET DEFAULT nextval('public.payroll_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: time_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_records ALTER COLUMN id SET DEFAULT nextval('public.time_records_id_seq'::regclass);


--
-- Name: vacations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacations ALTER COLUMN id SET DEFAULT nextval('public.vacations_id_seq'::regclass);


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (id, employee_id, name, email, password_hash, role, department, "position", salary, hire_date, phone, address, status, created_at) FROM stdin;
1	ADM001	Carlos Admin	admin@empresa.com	$2b$10$s8gRNCY9YoEc/cYv/SMyHOUZr7.WsLaPgVjjfMGUJXTh6zc8CglOu	admin	TI	Administrador do Sistema	15000.00	2020-01-01	(11) 99999-0001	\N	active	2026-06-11 12:19:00.706564+00
2	GER001	Ana Gerente	ana.gerente@empresa.com	$2b$10$S3kD1KJBY7rrlnbUOg/W6OKDQfj8RV3L7w5tvh8fuo3AAWbeO7dXe	manager	Desenvolvimento	Gerente de Desenvolvimento	12000.00	2020-03-15	(11) 99999-0002	\N	active	2026-06-11 12:19:00.706564+00
3	GER002	Ricardo RH	rh@empresa.com	$2b$10$S3kD1KJBY7rrlnbUOg/W6OKDQfj8RV3L7w5tvh8fuo3AAWbeO7dXe	manager	Recursos Humanos	Gerente de RH	11000.00	2021-01-10	(11) 99999-0003	\N	active	2026-06-11 12:19:00.706564+00
4	EMP001	João Silva	joao.silva@empresa.com	$2b$10$IRmJ0R.Q0gqkfqEtAh2Pw.dWS5RbRz1kzN2ixYu.3SlHl5cyPnK/u	employee	Desenvolvimento	Desenvolvedor Frontend	8000.00	2022-06-01	(11) 99999-0004	\N	active	2026-06-11 12:19:00.706564+00
5	EMP002	Maria Santos	maria.santos@empresa.com	$2b$10$IRmJ0R.Q0gqkfqEtAh2Pw.dWS5RbRz1kzN2ixYu.3SlHl5cyPnK/u	employee	Desenvolvimento	Desenvolvedora Backend	8500.00	2022-08-15	(11) 99999-0005	\N	active	2026-06-11 12:19:00.706564+00
6	EMP003	Pedro Oliveira	pedro.oliveira@empresa.com	$2b$10$IRmJ0R.Q0gqkfqEtAh2Pw.dWS5RbRz1kzN2ixYu.3SlHl5cyPnK/u	employee	Infraestrutura	Analista DevOps	9000.00	2021-11-01	(11) 99999-0006	\N	active	2026-06-11 12:19:00.706564+00
7	EMP004	Fernanda Costa	fernanda.costa@empresa.com	$2b$10$IRmJ0R.Q0gqkfqEtAh2Pw.dWS5RbRz1kzN2ixYu.3SlHl5cyPnK/u	employee	QA	Analista de Qualidade	7500.00	2023-02-20	(11) 99999-0007	\N	active	2026-06-11 12:19:00.706564+00
\.


--
-- Data for Name: observations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.observations (id, employee_id, content, created_by_id, created_at) FROM stdin;
1	4	Excelente desempenho no último sprint. Entregou todas as tarefas dentro do prazo com alta qualidade.	2	2026-06-11 12:19:37.245237+00
2	5	Demonstrou grande iniciativa na solução do bug crítico de produção. Merece reconhecimento.	2	2026-06-11 12:19:37.245237+00
\.


--
-- Data for Name: payroll; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payroll (id, employee_id, month, year, base_salary, total_worked_days, total_absences, bonuses, deductions, net_salary, generated_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, title, description, assigned_to_id, created_by_id, status, priority, due_date, completed_at, approved_at, rejection_reason, created_at) FROM stdin;
1	Implementar autenticação OAuth	Adicionar login com Google e GitHub ao sistema interno	4	2	in_progress	high	2026-06-18	\N	\N	\N	2026-06-11 12:19:28.503951+00
2	Refatorar API de relatórios	Melhorar performance das queries de relatório	5	2	pending	medium	2026-06-25	\N	\N	\N	2026-06-11 12:19:28.503951+00
3	Configurar pipeline CI/CD	Configurar GitHub Actions para deploy automático	6	2	completed	urgent	2026-06-10	\N	\N	\N	2026-06-11 12:19:28.503951+00
4	Criar testes automatizados	Cobertura de testes para módulo de pagamento	7	3	pending	medium	2026-06-21	\N	\N	\N	2026-06-11 12:19:28.503951+00
5	Atualizar documentação da API	Documentar todos os endpoints novos no Swagger	4	2	pending	low	2026-07-01	\N	\N	\N	2026-06-11 12:19:28.503951+00
\.


--
-- Data for Name: time_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.time_records (id, employee_id, date, entry_time, lunch_start, lunch_end, exit_time, total_hours, status, notes, created_at) FROM stdin;
1	4	2026-06-09	08:02	12:00	13:05	17:10	8.05	present	\N	2026-06-11 12:19:23.920664+00
2	4	2026-06-10	08:15	12:10	13:00	17:20	8.08	present	\N	2026-06-11 12:19:23.920664+00
3	5	2026-06-09	07:55	12:00	13:00	17:00	8.00	present	\N	2026-06-11 12:19:23.920664+00
4	5	2026-06-10	08:30	12:15	13:10	17:45	8.17	present	\N	2026-06-11 12:19:23.920664+00
5	6	2026-06-09	08:00	12:00	13:00	17:00	8.00	present	\N	2026-06-11 12:19:23.920664+00
6	7	2026-06-10	09:00	12:00	13:00	18:00	8.00	present	\N	2026-06-11 12:19:23.920664+00
\.


--
-- Data for Name: vacations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vacations (id, employee_id, start_date, end_date, total_days, status, reason, approved_by_id, created_at) FROM stdin;
1	4	2026-07-14	2026-07-25	12	pending	Férias anuais programadas	\N	2026-06-11 12:19:32.76602+00
2	5	2026-08-04	2026-08-15	12	approved	Férias de verão	\N	2026-06-11 12:19:32.76602+00
\.


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employees_id_seq', 7, true);


--
-- Name: observations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.observations_id_seq', 2, true);


--
-- Name: payroll_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payroll_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasks_id_seq', 5, true);


--
-- Name: time_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.time_records_id_seq', 6, true);


--
-- Name: vacations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vacations_id_seq', 2, true);


--
-- Name: employees employees_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_email_unique UNIQUE (email);


--
-- Name: employees employees_employee_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_employee_id_unique UNIQUE (employee_id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: observations observations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT observations_pkey PRIMARY KEY (id);


--
-- Name: payroll payroll_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll
    ADD CONSTRAINT payroll_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: time_records time_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_records
    ADD CONSTRAINT time_records_pkey PRIMARY KEY (id);


--
-- Name: vacations vacations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacations
    ADD CONSTRAINT vacations_pkey PRIMARY KEY (id);


--
-- Name: observations observations_created_by_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT observations_created_by_id_employees_id_fk FOREIGN KEY (created_by_id) REFERENCES public.employees(id);


--
-- Name: observations observations_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT observations_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: payroll payroll_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll
    ADD CONSTRAINT payroll_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: tasks tasks_assigned_to_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assigned_to_id_employees_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.employees(id);


--
-- Name: tasks tasks_created_by_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_id_employees_id_fk FOREIGN KEY (created_by_id) REFERENCES public.employees(id);


--
-- Name: time_records time_records_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_records
    ADD CONSTRAINT time_records_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: vacations vacations_approved_by_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacations
    ADD CONSTRAINT vacations_approved_by_id_employees_id_fk FOREIGN KEY (approved_by_id) REFERENCES public.employees(id);


--
-- Name: vacations vacations_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacations
    ADD CONSTRAINT vacations_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- PostgreSQL database dump complete
--

\unrestrict Gy9Yqnp0abiWmLc80R1OgdhpB5E7bXxIiATbuzdCpMRLAIR0rCQdy8xBqOnjfj8


<?php

return [
    'host' => 'localhost',
    'dbname' => 'sistema_funcionarios',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4',
];

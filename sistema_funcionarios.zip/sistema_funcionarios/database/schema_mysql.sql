-- Sistema de Funcionários - MySQL/MariaDB (XAMPP)
-- Importar no phpMyAdmin: criar banco "sistema_funcionarios" e executar este script

CREATE DATABASE IF NOT EXISTS sistema_funcionarios
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sistema_funcionarios;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS observations;
DROP TABLE IF EXISTS payroll;
DROP TABLE IF EXISTS tasks;
DROP TABLE IF EXISTS time_records;
DROP TABLE IF EXISTS vacations;
DROP TABLE IF EXISTS employees;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE employees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_id VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin', 'manager', 'employee') NOT NULL DEFAULT 'employee',
  department VARCHAR(100) NOT NULL,
  position VARCHAR(100) NOT NULL,
  salary DECIMAL(10,2) NOT NULL,
  hire_date DATE NOT NULL,
  phone VARCHAR(30) NULL,
  address TEXT NULL,
  status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE time_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_id INT NOT NULL,
  date DATE NOT NULL,
  entry_time TIME NULL,
  lunch_start TIME NULL,
  lunch_end TIME NULL,
  exit_time TIME NULL,
  total_hours DECIMAL(5,2) NULL,
  status ENUM('present', 'absent', 'partial') NOT NULL DEFAULT 'partial',
  notes TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
  UNIQUE KEY uk_employee_date (employee_id, date)
) ENGINE=InnoDB;

CREATE TABLE vacations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_id INT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  total_days INT NOT NULL,
  status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  reason TEXT NULL,
  approved_by_id INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
  FOREIGN KEY (approved_by_id) REFERENCES employees(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE observations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_id INT NOT NULL,
  content TEXT NOT NULL,
  created_by_id INT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  assigned_to_id INT NOT NULL,
  created_by_id INT NOT NULL,
  status ENUM('pending', 'in_progress', 'completed', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  priority ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium',
  due_date DATE NULL,
  completed_at TIMESTAMP NULL,
  approved_at TIMESTAMP NULL,
  rejection_reason TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (assigned_to_id) REFERENCES employees(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE payroll (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_id INT NOT NULL,
  month TINYINT NOT NULL,
  year SMALLINT NOT NULL,
  base_salary DECIMAL(10,2) NOT NULL,
  total_worked_days INT NOT NULL DEFAULT 0,
  total_absences INT NOT NULL DEFAULT 0,
  bonuses DECIMAL(10,2) NOT NULL DEFAULT 0,
  deductions DECIMAL(10,2) NOT NULL DEFAULT 0,
  net_salary DECIMAL(10,2) NOT NULL,
  generated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
  UNIQUE KEY uk_payroll_employee_month (employee_id, month, year)
) ENGINE=InnoDB;

-- Senhas: admin123, gerente123, func123 (bcrypt)
INSERT INTO employees (employee_id, name, email, password_hash, role, department, position, salary, hire_date, phone, status) VALUES
('ADM001', 'Carlos Admin', 'admin@empresa.com', '$2y$10$s8gRNCY9YoEc/cYv/SMyHOUZr7.WsLaPgVjjfMGUJXTh6zc8CglOu', 'admin', 'TI', 'Administrador do Sistema', 15000.00, '2020-01-01', '(11) 99999-0001', 'active'),
('GER001', 'Ana Gerente', 'ana.gerente@empresa.com', '$2y$10$S3kD1KJBY7rrlnbUOg/W6OKDQfj8RV3L7w5tvh8fuo3AAWbeO7dXe', 'manager', 'Desenvolvimento', 'Gerente de Desenvolvimento', 12000.00, '2020-03-15', '(11) 99999-0002', 'active'),
('GER002', 'Ricardo RH', 'rh@empresa.com', '$2y$10$S3kD1KJBY7rrlnbUOg/W6OKDQfj8RV3L7w5tvh8fuo3AAWbeO7dXe', 'manager', 'Recursos Humanos', 'Gerente de RH', 11000.00, '2021-01-10', '(11) 99999-0003', 'active'),
('EMP001', 'João Silva', 'joao.silva@empresa.com', '$2y$10$IRmJ0R.Q0gqkfqEtAh2Pw.dWS5RbRz1kzN2ixYu.3SlHl5cyPnK/u', 'employee', 'Desenvolvimento', 'Desenvolvedor Frontend', 8000.00, '2022-06-01', '(11) 99999-0004', 'active'),
('EMP002', 'Maria Santos', 'maria.santos@empresa.com', '$2y$10$IRmJ0R.Q0gqkfqEtAh2Pw.dWS5RbRz1kzN2ixYu.3SlHl5cyPnK/u', 'employee', 'Desenvolvimento', 'Desenvolvedora Backend', 8500.00, '2022-08-15', '(11) 99999-0005', 'active'),
('EMP003', 'Pedro Oliveira', 'pedro.oliveira@empresa.com', '$2y$10$IRmJ0R.Q0gqkfqEtAh2Pw.dWS5RbRz1kzN2ixYu.3SlHl5cyPnK/u', 'employee', 'Infraestrutura', 'Analista DevOps', 9000.00, '2021-11-01', '(11) 99999-0006', 'active'),
('EMP004', 'Fernanda Costa', 'fernanda.costa@empresa.com', '$2y$10$IRmJ0R.Q0gqkfqEtAh2Pw.dWS5RbRz1kzN2ixYu.3SlHl5cyPnK/u', 'employee', 'QA', 'Analista de Qualidade', 7500.00, '2023-02-20', '(11) 99999-0007', 'active');

INSERT INTO time_records (employee_id, date, entry_time, lunch_start, lunch_end, exit_time, total_hours, status) VALUES
(4, '2026-06-09', '08:02:00', '12:00:00', '13:05:00', '17:10:00', 8.05, 'present'),
(4, '2026-06-10', '08:15:00', '12:10:00', '13:00:00', '17:20:00', 8.08, 'present'),
(5, '2026-06-09', '07:55:00', '12:00:00', '13:00:00', '17:00:00', 8.00, 'present'),
(5, '2026-06-10', '08:30:00', '12:15:00', '13:10:00', '17:45:00', 8.17, 'present'),
(6, '2026-06-09', '08:00:00', '12:00:00', '13:00:00', '17:00:00', 8.00, 'present'),
(7, '2026-06-10', '09:00:00', '12:00:00', '13:00:00', '18:00:00', 8.00, 'present');

INSERT INTO tasks (title, description, assigned_to_id, created_by_id, status, priority, due_date) VALUES
('Implementar autenticação OAuth', 'Adicionar login com Google e GitHub ao sistema interno', 4, 2, 'in_progress', 'high', '2026-06-18'),
('Refatorar API de relatórios', 'Melhorar performance das queries de relatório', 5, 2, 'pending', 'medium', '2026-06-25'),
('Configurar pipeline CI/CD', 'Configurar GitHub Actions para deploy automático', 6, 2, 'completed', 'urgent', '2026-06-10'),
('Criar testes automatizados', 'Cobertura de testes para módulo de pagamento', 7, 3, 'pending', 'medium', '2026-06-21'),
('Atualizar documentação da API', 'Documentar todos os endpoints novos no Swagger', 4, 2, 'pending', 'low', '2026-07-01');

INSERT INTO vacations (employee_id, start_date, end_date, total_days, status, reason) VALUES
(4, '2026-07-14', '2026-07-25', 12, 'pending', 'Férias anuais programadas'),
(5, '2026-08-04', '2026-08-15', 12, 'approved', 'Férias de verão');

INSERT INTO observations (employee_id, content, created_by_id) VALUES
(4, 'Excelente desempenho no último sprint. Entregou todas as tarefas dentro do prazo com alta qualidade.', 2),
(5, 'Demonstrou grande iniciativa na solução do bug crítico de produção. Merece reconhecimento.', 2);

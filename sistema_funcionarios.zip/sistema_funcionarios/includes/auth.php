<?php

session_start();

function currentUser(): ?array
{
    return $_SESSION['user'] ?? null;
}

function requireLogin(): array
{
    $user = currentUser();
    if (!$user) {
        header('Location: login.php');
        exit;
    }
    return $user;
}

function requireRole(array $roles): array
{
    $user = requireLogin();
    if (!in_array($user['role'], $roles, true)) {
        http_response_code(403);
        die('Acesso negado.');
    }
    return $user;
}

function loginUser(array $employee): void
{
    unset($employee['password_hash']);
    $_SESSION['user'] = $employee;
}

function logoutUser(): void
{
    $_SESSION = [];
    session_destroy();
}

function isAdmin(array $user): bool
{
    return $user['role'] === 'admin';
}

function isManager(array $user): bool
{
    return in_array($user['role'], ['admin', 'manager'], true);
}

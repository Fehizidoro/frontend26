<?php

function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function formatMoney(float $value): string
{
    return 'R$ ' . number_format($value, 2, ',', '.');
}

function formatDate(?string $date): string
{
    if (!$date) {
        return '-';
    }
    return date('d/m/Y', strtotime($date));
}

function formatTime(?string $time): string
{
    if (!$time) {
        return '-';
    }
    return substr($time, 0, 5);
}

function roleLabel(string $role): string
{
    return match ($role) {
        'admin' => 'Administrador',
        'manager' => 'Gerente',
        default => 'Funcionário',
    };
}

function statusLabel(string $status): string
{
    return match ($status) {
        'pending' => 'Pendente',
        'in_progress' => 'Em andamento',
        'completed' => 'Concluída',
        'approved' => 'Aprovada',
        'rejected' => 'Rejeitada',
        'present' => 'Presente',
        'absent' => 'Ausente',
        'partial' => 'Parcial',
        'active' => 'Ativo',
        'inactive' => 'Inativo',
        default => $status,
    };
}

function priorityLabel(string $priority): string
{
    return match ($priority) {
        'low' => 'Baixa',
        'medium' => 'Média',
        'high' => 'Alta',
        'urgent' => 'Urgente',
        default => $priority,
    };
}

function calcHours(?string $entry, ?string $lunchStart, ?string $lunchEnd, ?string $exit): ?float
{
    if (!$entry || !$exit) {
        return null;
    }

    $toMins = static function (string $t): int {
        [$h, $m] = array_map('intval', explode(':', $t));
        return $h * 60 + $m;
    };

    $total = $toMins($exit) - $toMins($entry);

    if ($lunchStart && $lunchEnd) {
        $total -= $toMins($lunchEnd) - $toMins($lunchStart);
    }

    return max(0, round($total / 60, 2));
}

function calcVacationDays(string $start, string $end): int
{
    $startDate = new DateTime($start);
    $endDate = new DateTime($end);
    return max(1, (int) $startDate->diff($endDate)->days + 1);
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

function greeting(): string
{
    $hour = (int) date('H');
    if ($hour < 12) {
        return 'Bom dia';
    }
    if ($hour < 18) {
        return 'Boa tarde';
    }
    return 'Boa noite';
}

function formatPageDate(): string
{
    $days = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
    $months = [
        1 => 'janeiro', 2 => 'fevereiro', 3 => 'março', 4 => 'abril',
        5 => 'maio', 6 => 'junho', 7 => 'julho', 8 => 'agosto',
        9 => 'setembro', 10 => 'outubro', 11 => 'novembro', 12 => 'dezembro',
    ];

    $day = (int) date('j');
    $month = (int) date('n');
    $year = date('Y');

    return $days[(int) date('w')] . ', ' . $day . ' de ' . $months[$month] . ' de ' . $year;
}

function refreshSessionUser(int $id): void
{
    $stmt = getDb()->prepare(
        'SELECT id, employee_id, name, email, role, department, position, salary, hire_date, phone, address, status
         FROM employees WHERE id = ?'
    );
    $stmt->execute([$id]);
    $employee = $stmt->fetch();

    if ($employee && currentUser() && (int) currentUser()['id'] === $id) {
        $_SESSION['user'] = $employee;
    }
}

function employeeFields(): array
{
    return ['id', 'employee_id', 'name', 'email', 'role', 'department', 'position', 'salary', 'hire_date', 'phone', 'address', 'status'];
}

function fetchEmployee(int $id): ?array
{
    $stmt = getDb()->prepare(
        'SELECT id, employee_id, name, email, role, department, position, salary, hire_date, phone, address, status, created_at
         FROM employees WHERE id = ?'
    );
    $stmt->execute([$id]);
    return $stmt->fetch() ?: null;
}

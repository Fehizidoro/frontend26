<?php

function renderHeader(string $title, string $active = '', string $subtitle = '', bool $showDefaultHeader = true): void
{
    $user = currentUser();
    $nav = [
        ['href' => 'dashboard.php', 'label' => 'Dashboard', 'icon' => '📊'],
        ['href' => 'perfil.php', 'label' => 'Meu Perfil', 'icon' => '👤'],
        ['href' => 'funcionarios.php', 'label' => 'Funcionários', 'icon' => '👥', 'admin' => true],
        ['href' => 'ponto.php', 'label' => 'Controle de Ponto', 'icon' => '🕐'],
        ['href' => 'calendario.php', 'label' => 'Calendário', 'icon' => '📅'],
        ['href' => 'ferias.php', 'label' => 'Férias', 'icon' => '✈️'],
        ['href' => 'tarefas.php', 'label' => 'Tarefas', 'icon' => '✅'],
        ['href' => 'folha.php', 'label' => 'Folha de Pagamento', 'icon' => '💰'],
        ['href' => 'relatorios.php', 'label' => 'Relatórios', 'icon' => '📈', 'admin' => true],
    ];
    $initial = strtoupper(substr($user['name'], 0, 1));
    ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?> - PeopleHub RH</title>
    <script>
        (function () {
            if (localStorage.getItem('theme') === 'dark') {
                document.documentElement.setAttribute('data-theme', 'dark');
            }
        })();
    </script>
    <link rel="stylesheet" href="assets/css/style.css?v=3">
</head>
<body>
    <div class="app">
        <aside class="sidebar">
            <div class="sidebar-brand">
                <span class="brand-icon">RH</span>
                <div>
                    <strong>PeopleHub RH</strong>
                    <small>Gestão de pessoas</small>
                </div>
            </div>

            <p class="sidebar-label">Menu principal</p>
            <nav class="sidebar-nav">
                <?php foreach ($nav as $item): ?>
                    <?php if (!empty($item['admin']) && !isAdmin($user)): continue; endif; ?>
                    <a href="<?= e($item['href']) ?>" class="nav-link <?= $active === $item['href'] ? 'active' : '' ?>">
                        <span class="nav-icon"><?= $item['icon'] ?></span>
                        <?= e($item['label']) ?>
                    </a>
                <?php endforeach; ?>
            </nav>

            <div class="sidebar-tools">
                <button type="button" class="btn btn-ghost btn-sm theme-toggle" data-theme-toggle onclick="toggleTheme()" aria-label="Alternar modo escuro">🌙 Modo escuro</button>
            </div>

            <div class="sidebar-user-card">
                <a href="perfil.php" class="sidebar-user-link">
                    <span class="sidebar-avatar"><?= e($initial) ?></span>
                    <span class="sidebar-user-meta">
                        <strong><?= e($user['name']) ?></strong>
                        <small><?= e($user['department']) ?></small>
                    </span>
                </a>
                <span class="badge badge-<?= e($user['role']) ?>"><?= e(roleLabel($user['role'])) ?></span>
                <a href="logout.php" class="btn btn-ghost btn-sm btn-logout">Sair</a>
            </div>
        </aside>

        <div class="main-shell">
            <header class="main-topbar">
                <div class="main-topbar-date">
                    <span class="status-dot" aria-hidden="true"></span>
                    <?= e(formatPageDate()) ?>
                </div>
                <div class="main-topbar-actions">
                    <a href="perfil.php" class="topbar-chip"><?= e($user['employee_id']) ?></a>
                </div>
            </header>

            <main class="main">
                <?php $flash = getFlash(); if ($flash): ?>
                    <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
                <?php endif; ?>

                <?php if ($showDefaultHeader): ?>
                <header class="content-header">
                    <div>
                        <h1><?= e($title) ?></h1>
                        <?php if ($subtitle): ?>
                            <p class="content-subtitle"><?= e($subtitle) ?></p>
                        <?php endif; ?>
                    </div>
                </header>
                <?php endif; ?>

                <div class="content-body">
    <?php
}

function renderFooter(): void
{
    ?>
                </div>
            </main>
        </div>
    </div>
    <script src="assets/js/app.js?v=2"></script>
</body>
</html>
    <?php
}

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Instalação — RH Pro</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Inter,Segoe UI,sans-serif;background:#0b1220;color:#e5e7eb;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.box{background:#111827;border:1px solid #1f2937;border-radius:18px;width:100%;max-width:560px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,.4)}
.top{background:linear-gradient(135deg,#1d4ed8,#2563eb);padding:28px 32px;text-align:center}
.top .icon{font-size:40px;margin-bottom:10px}
.top h1{font-size:22px;font-weight:800;margin-bottom:4px}
.top p{font-size:13px;opacity:.8}
.body{padding:28px 32px}
.step{padding:12px 16px;border-radius:10px;margin-bottom:10px;font-size:13px;display:flex;align-items:center;gap:10px}
.step-ok{background:#14532d;border:1px solid #166534;color:#bbf7d0}
.step-err{background:#7f1d1d;border:1px solid #991b1b;color:#fecaca}
.step-info{background:#1e3a5f;border:1px solid #1d4ed8;color:#bfdbfe}
.step .icon{font-size:18px;flex-shrink:0}
.btn{display:block;width:100%;padding:13px;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;text-align:center;text-decoration:none;margin-top:14px}
.btn-primary{background:#2563eb;color:#fff}
.btn-success{background:#16a34a;color:#fff}
.label{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#6b7280;margin-bottom:8px;margin-top:16px}
input{width:100%;padding:10px 14px;border:1.5px solid #374151;border-radius:8px;font-size:14px;font-family:inherit;color:#e5e7eb;background:#0f172a;margin-bottom:4px}
input:focus{outline:none;border-color:#2563eb}
</style>
</head>
<body>
<?php
$step = $_POST['step'] ?? 'form';

if ($step === 'instalar') {
    $host   = trim($_POST['host']   ?? 'localhost');
    $user   = trim($_POST['user']   ?? 'root');
    $pass   = $_POST['pass']        ?? '';
    $dbname = trim($_POST['dbname'] ?? 'sistema_funcionarios');

    $steps = [];
    $ok = true;

    // 1. Conectar ao MySQL
    try {
        $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
        $steps[] = ['ok', 'Conexão com MySQL estabelecida'];
    } catch (Exception $e) {
        $steps[] = ['err', 'Falha na conexão: ' . $e->getMessage()];
        $ok = false;
    }

    if ($ok) {
        // 2. Criar banco
        try {
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$dbname`");
            $steps[] = ['ok', "Banco de dados '$dbname' criado/selecionado"];
        } catch (Exception $e) {
            $steps[] = ['err', 'Erro ao criar banco: ' . $e->getMessage()];
            $ok = false;
        }
    }

    if ($ok) {
        // 3. Criar tabelas
        $sql = file_get_contents(__DIR__ . '/database/schema_mysql.sql');
        // Remover CREATE DATABASE e USE (já feitos)
        $sql = preg_replace('/CREATE DATABASE.*?;\s*/si', '', $sql);
        $sql = preg_replace('/USE\s+\w+\s*;\s*/si', '', $sql);
        $sql = preg_replace('/SET FOREIGN_KEY_CHECKS\s*=\s*0\s*;\s*/si', '', $sql);
        $sql = preg_replace('/SET FOREIGN_KEY_CHECKS\s*=\s*1\s*;\s*/si', '', $sql);

        // Executar cada statement
        $statements = array_filter(array_map('trim', explode(';', $sql)));
        $errors = [];
        foreach ($statements as $stmt) {
            if (!$stmt) continue;
            try {
                $pdo->exec($stmt);
            } catch (Exception $e) {
                $errors[] = $e->getMessage();
            }
        }
        if (empty($errors)) {
            $steps[] = ['ok', 'Tabelas criadas e dados de demonstração inseridos'];
        } else {
            $steps[] = ['ok', 'Tabelas processadas (' . count($errors) . ' avisos, normal em reinstalação)'];
        }
    }

    if ($ok) {
        // 4. Atualizar config
        $config = "<?php\n\nreturn [\n    'host'    => " . var_export($host, true) . ",\n    'dbname'  => " . var_export($dbname, true) . ",\n    'user'    => " . var_export($user, true) . ",\n    'pass'    => " . var_export($pass, true) . ",\n    'charset' => 'utf8mb4',\n];\n";
        file_put_contents(__DIR__ . '/config/database.php', $config);
        $steps[] = ['ok', 'Arquivo config/database.php atualizado'];
    }

    echo '<div class="box">';
    echo '<div class="top"><div class="icon">' . ($ok ? '✅' : '❌') . '</div>';
    echo '<h1>' . ($ok ? 'Instalação concluída!' : 'Erro na instalação') . '</h1>';
    echo '<p>Sistema RH Pro</p></div>';
    echo '<div class="body">';

    foreach ($steps as [$tipo, $msg]) {
        $cls  = $tipo === 'ok' ? 'step-ok' : 'step-err';
        $icon = $tipo === 'ok' ? '✅' : '❌';
        echo "<div class='step $cls'><span class='icon'>$icon</span><span>" . htmlspecialchars($msg) . "</span></div>";
    }

    if ($ok) {
        echo "<div class='step step-info'><span class='icon'>ℹ️</span><span><strong>Logins de demonstração:</strong><br>
            Admin: <code>ADM001</code> / <code>admin123</code><br>
            Gerente: <code>GER001</code> / <code>gerente123</code><br>
            Funcionário: <code>EMP001</code> / <code>func123</code>
        </span></div>";
        echo "<a href='public/' class='btn btn-success'>Acessar o sistema →</a>";
    } else {
        echo "<a href='instalar.php' class='btn btn-primary'>← Tentar novamente</a>";
    }

    echo '</div></div>';
    exit;
}
?>
<div class="box">
    <div class="top">
        <div class="icon">🏢</div>
        <h1>RH Pro — Instalação</h1>
        <p>Configure o banco de dados para começar</p>
    </div>
    <div class="body">
        <div class="step step-info">
            <span class="icon">ℹ️</span>
            <span>Este script cria o banco de dados e insere dados de demonstração automaticamente.</span>
        </div>

        <form method="POST">
            <input type="hidden" name="step" value="instalar">

            <div class="label">Host MySQL</div>
            <input type="text" name="host" value="localhost" placeholder="localhost">

            <div class="label">Usuário</div>
            <input type="text" name="user" value="root" placeholder="root">

            <div class="label">Senha <small style="color:#6b7280">(vazio no XAMPP padrão)</small></div>
            <input type="password" name="pass" placeholder="">

            <div class="label">Nome do Banco</div>
            <input type="text" name="dbname" value="sistema_funcionarios">

            <button type="submit" class="btn btn-primary">Instalar agora</button>
        </form>
    </div>
</div>
</body>
</html>

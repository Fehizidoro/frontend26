(function () {
  function getTheme() {
    return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  }

  function applyTheme(theme) {
    if (theme === 'dark') {
      document.documentElement.setAttribute('data-theme', 'dark');
    } else {
      document.documentElement.removeAttribute('data-theme');
    }
    localStorage.setItem('theme', theme);
    updateThemeButtons(theme);
  }

  function updateThemeButtons(theme) {
    const isDark = theme === 'dark';
    const label = isDark ? '☀️ Modo claro' : '🌙 Modo escuro';
    const icon = isDark ? '☀️' : '🌙';

    document.querySelectorAll('[data-theme-toggle]').forEach((button) => {
      if (button.classList.contains('login-theme-toggle')) {
        button.textContent = icon;
      } else {
        button.textContent = label;
      }
      button.setAttribute('aria-label', isDark ? 'Ativar modo claro' : 'Ativar modo escuro');
    });
  }

  window.toggleTheme = function () {
    applyTheme(getTheme() === 'dark' ? 'light' : 'dark');
  };

  document.addEventListener('DOMContentLoaded', function () {
    updateThemeButtons(getTheme());

    const clock = document.getElementById('live-clock');
    if (clock) {
      const updateClock = function () {
        const now = new Date();
        clock.textContent = now.toLocaleTimeString('pt-BR', { hour12: false });
      };

      updateClock();
      setInterval(updateClock, 1000);
    }
  });
})();

<?php

require_once __DIR__ . '/bootstrap.php';
$user = requireLogin();
$db = getDb();

$employeeId = (int) ($_GET['employee_id'] ?? $user['id']);
if (!isAdmin($user) && $employeeId !== (int) $user['id']) {
    $employeeId = (int) $user['id'];
}

$month = $_GET['month'] ?? date('Y-m');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isAdmin($user)) {
    $date = $_POST['date'];
    $entry = $_POST['entry_time'] ?: null;
    $lunchStart = $_POST['lunch_start'] ?: null;
    $lunchEnd = $_POST['lunch_end'] ?: null;
    $exit = $_POST['exit_time'] ?: null;
    $notes = trim($_POST['notes'] ?? '');
    $hours = calcHours($entry, $lunchStart, $lunchEnd, $exit);
    $status = $_POST['status'] ?? ($exit ? 'present' : ($entry ? 'partial' : 'absent'));

    $stmt = $db->prepare('SELECT id FROM time_records WHERE employee_id = ? AND date = ?');
    $stmt->execute([(int) $_POST['employee_id'], $date]);
    $existingId = $stmt->fetchColumn();

    if ($existingId) {
        $stmt = $db->prepare('UPDATE time_records SET entry_time = ?, lunch_start = ?, lunch_end = ?, exit_time = ?, total_hours = ?, status = ?, notes = ? WHERE id = ?');
        $stmt->execute([$entry, $lunchStart, $lunchEnd, $exit, $hours, $status, $notes, $existingId]);
    } else {
        $stmt = $db->prepare('INSERT INTO time_records (employee_id, date, entry_time, lunch_start, lunch_end, exit_time, total_hours, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([(int) $_POST['employee_id'], $date, $entry, $lunchStart, $lunchEnd, $exit, $hours, $status, $notes]);
    }

    flash('success', 'Registro de ponto atualizado.');
    header('Location: calendario.php?employee_id=' . (int) $_POST['employee_id'] . '&month=' . urlencode(substr($date, 0, 7)));
    exit;
}

$editDate = $_GET['edit_date'] ?? null;
$editRecord = null;
if ($editDate && isAdmin($user)) {
    $stmt = $db->prepare('SELECT * FROM time_records WHERE employee_id = ? AND date = ?');
    $stmt->execute([$employeeId, $editDate]);
    $editRecord = $stmt->fetch() ?: ['date' => $editDate];
}
$stmt = $db->prepare('SELECT name FROM employees WHERE id = ?');
$stmt->execute([$employeeId]);
$employeeName = $stmt->fetchColumn() ?: 'Funcionário';

$stmt = $db->prepare('SELECT date, status, entry_time, exit_time, total_hours FROM time_records WHERE employee_id = ? AND date LIKE ?');
$stmt->execute([$employeeId, $month . '%']);
$records = [];
foreach ($stmt->fetchAll() as $row) {
    $records[$row['date']] = $row;
}

$employees = [];
if (isAdmin($user)) {
    $employees = $db->query('SELECT id, name FROM employees WHERE status = "active" ORDER BY name')->fetchAll();
}

$firstDay = new DateTime($month . '-01');
$daysInMonth = (int) $firstDay->format('t');
$startWeekday = (int) $firstDay->format('w');

renderHeader('Calendário de Presença', 'calendario.php', e($employeeName) . ' — referência ' . $firstDay->format('m/Y'));
?>
<div class="card filters card-elevated">
    <form method="get" class="form inline-filters">
        <?php if (isAdmin($user)): ?>
        <label>Funcionário
            <select name="employee_id" onchange="this.form.submit()">
                <?php foreach ($employees as $emp): ?>
                    <option value="<?= (int) $emp['id'] ?>" <?= $employeeId === (int) $emp['id'] ? 'selected' : '' ?>><?= e($emp['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <?php endif; ?>
        <label>Mês
            <input type="month" name="month" value="<?= e($month) ?>" onchange="this.form.submit()">
        </label>
    </form>
    <div class="legend">
        <span class="legend-item present">Presente</span>
        <span class="legend-item partial">Parcial</span>
        <span class="legend-item absent">Ausente</span>
    </div>
</div>

<div class="calendar">
    <div class="calendar-header">Dom</div>
    <div class="calendar-header">Seg</div>
    <div class="calendar-header">Ter</div>
    <div class="calendar-header">Qua</div>
    <div class="calendar-header">Qui</div>
    <div class="calendar-header">Sex</div>
    <div class="calendar-header">Sáb</div>

    <?php for ($i = 0; $i < $startWeekday; $i++): ?>
        <div class="calendar-day empty"></div>
    <?php endfor; ?>

    <?php for ($day = 1; $day <= $daysInMonth; $day++):
        $date = sprintf('%s-%02d', $month, $day);
        $record = $records[$date] ?? null;
        $status = $record['status'] ?? (date('Y-m-d') < $date ? '' : 'absent');
        $class = $status ?: 'future';
    ?>
        <div class="calendar-day <?= e($class) ?>" title="<?= $record ? formatTime($record['entry_time']) . ' - ' . formatTime($record['exit_time']) : '' ?>">
            <?php if (isAdmin($user)): ?>
                <a class="day-link" href="calendario.php?employee_id=<?= $employeeId ?>&month=<?= e($month) ?>&edit_date=<?= e($date) ?>"><?= $day ?></a>
            <?php else: ?>
                <span class="day-num"><?= $day ?></span>
            <?php endif; ?>
            <?php if ($record && $record['total_hours']): ?>
                <small><?= number_format((float) $record['total_hours'], 1) ?>h</small>
            <?php endif; ?>
        </div>
    <?php endfor; ?>
</div>

<?php if (isAdmin($user)): ?>
<div class="card mt-4">
    <h3><?= $editRecord ? 'Editar registro de ponto' : 'Ajustar registro de ponto (admin)' ?></h3>
    <form method="post" class="form">
        <input type="hidden" name="employee_id" value="<?= $employeeId ?>">
        <div class="form-row">
            <label>Data<input type="date" name="date" value="<?= e($editRecord['date'] ?? date('Y-m-d')) ?>" required></label>
            <label>Entrada<input type="time" name="entry_time" value="<?= e(isset($editRecord['entry_time']) ? substr($editRecord['entry_time'], 0, 5) : '') ?>"></label>
            <label>Almoço (saída)<input type="time" name="lunch_start" value="<?= e(isset($editRecord['lunch_start']) ? substr($editRecord['lunch_start'], 0, 5) : '') ?>"></label>
            <label>Almoço (retorno)<input type="time" name="lunch_end" value="<?= e(isset($editRecord['lunch_end']) ? substr($editRecord['lunch_end'], 0, 5) : '') ?>"></label>
            <label>Saída<input type="time" name="exit_time" value="<?= e(isset($editRecord['exit_time']) ? substr($editRecord['exit_time'], 0, 5) : '') ?>"></label>
            <label>Status
                <select name="status">
                    <?php foreach (['present', 'partial', 'absent'] as $s): ?>
                        <option value="<?= $s ?>" <?= ($editRecord['status'] ?? '') === $s ? 'selected' : '' ?>><?= e(statusLabel($s)) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>
        <label>Observações<textarea name="notes" rows="2"><?= e($editRecord['notes'] ?? '') ?></textarea></label>
        <button type="submit" class="btn btn-primary">Salvar registro</button>
    </form>
    <p class="muted small mt-3">Clique em um dia no calendário para editar rapidamente.</p>
</div>
<?php endif; ?>
<?php renderFooter(); ?>

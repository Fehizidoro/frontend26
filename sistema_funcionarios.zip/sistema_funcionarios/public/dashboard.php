<?php

require_once __DIR__ . '/bootstrap.php';
$user = requireLogin();
$db = getDb();

$totalEmployees = (int) $db->query("SELECT COUNT(*) FROM employees")->fetchColumn();
$activeEmployees = (int) $db->query("SELECT COUNT(*) FROM employees WHERE status = 'active'")->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM tasks WHERE assigned_to_id = ? AND status IN ('pending', 'in_progress')");
$stmt->execute([$user['id']]);
$pendingTasks = (int) $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM tasks WHERE assigned_to_id = ? AND status = 'completed'");
$stmt->execute([$user['id']]);
$completedTasks = (int) $stmt->fetchColumn();

$today = date('Y-m-d');
$stmt = $db->prepare('SELECT * FROM time_records WHERE employee_id = ? AND date = ?');
$stmt->execute([$user['id'], $today]);
$todayRecord = $stmt->fetch() ?: null;

$stmt = $db->prepare("SELECT title, status, priority, due_date FROM tasks WHERE assigned_to_id = ? ORDER BY created_at DESC LIMIT 4");
$stmt->execute([$user['id']]);
$recentTasks = $stmt->fetchAll();

$firstName = explode(' ', $user['name'])[0];
renderHeader('Dashboard', 'dashboard.php', greeting() . ', ' . $firstName . '! Acompanhe seu dia e acesse os módulos do sistema.');
?>
<section class="welcome-banner">
    <div>
        <p class="welcome-eyebrow">Painel do colaborador</p>
        <h2>Bem-vindo de volta, <?= e($firstName) ?></h2>
        <p>Você está em <strong><?= e($user['department']) ?></strong> como <strong><?= e($user['position']) ?></strong>. Use o painel abaixo para registrar ponto, acompanhar tarefas e solicitar férias.</p>
    </div>
    <div class="welcome-actions">
        <a href="ponto.php" class="btn btn-primary">Registrar ponto</a>
        <a href="tarefas.php" class="btn btn-ghost btn-sm">Ver tarefas</a>
    </div>
</section>

<div class="grid grid-4">
    <?php if (isAdmin($user)): ?>
    <div class="card stat-card stat-card-blue">
        <span class="stat-icon">👥</span>
        <span class="stat-label">Total de funcionários</span>
        <strong class="stat-value"><?= $totalEmployees ?></strong>
        <small><?= $activeEmployees ?> ativos no sistema</small>
    </div>
    <?php endif; ?>
    <div class="card stat-card stat-card-amber">
        <span class="stat-icon">✅</span>
        <span class="stat-label">Tarefas pendentes</span>
        <strong class="stat-value"><?= $pendingTasks ?></strong>
        <small>aguardando ou em andamento</small>
    </div>
    <div class="card stat-card stat-card-green">
        <span class="stat-icon">🏁</span>
        <span class="stat-label">Tarefas concluídas</span>
        <strong class="stat-value"><?= $completedTasks ?></strong>
        <small>finalizadas por você</small>
    </div>
    <div class="card stat-card stat-card-purple">
        <span class="stat-icon">🕐</span>
        <span class="stat-label">Ponto de hoje</span>
        <strong class="stat-value"><?= $todayRecord && $todayRecord['entry_time'] ? formatTime($todayRecord['entry_time']) : '--:--' ?></strong>
        <small><?= $todayRecord && $todayRecord['exit_time'] ? 'Saída: ' . formatTime($todayRecord['exit_time']) : 'sem saída registrada' ?></small>
    </div>
</div>

<div class="grid grid-2 mt-4">
    <div class="card card-elevated">
        <div class="card-heading">
            <h3>Acesso rápido</h3>
            <p>Atalhos para as áreas mais usadas</p>
        </div>
        <div class="quick-links quick-links-grid">
            <a href="ponto.php" class="quick-link">
                <span class="quick-link-icon">🕐</span>
                <span>
                    <strong>Controle de ponto</strong>
                    <small>Registrar entrada, almoço e saída</small>
                </span>
            </a>
            <a href="tarefas.php" class="quick-link">
                <span class="quick-link-icon">✅</span>
                <span>
                    <strong>Minhas tarefas</strong>
                    <small>Acompanhar pendências e prazos</small>
                </span>
            </a>
            <a href="ferias.php" class="quick-link">
                <span class="quick-link-icon">✈️</span>
                <span>
                    <strong>Solicitar férias</strong>
                    <small>Enviar pedido ao gestor</small>
                </span>
            </a>
            <a href="calendario.php" class="quick-link">
                <span class="quick-link-icon">📅</span>
                <span>
                    <strong>Calendário</strong>
                    <small>Visualizar presença mensal</small>
                </span>
            </a>
            <?php if (isAdmin($user)): ?>
            <a href="funcionarios.php" class="quick-link">
                <span class="quick-link-icon">👥</span>
                <span>
                    <strong>Funcionários</strong>
                    <small>Gerenciar cadastros da equipe</small>
                </span>
            </a>
            <a href="relatorios.php" class="quick-link">
                <span class="quick-link-icon">📈</span>
                <span>
                    <strong>Relatórios</strong>
                    <small>Indicadores e frequência</small>
                </span>
            </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="card card-elevated">
        <div class="card-heading">
            <h3>Resumo do perfil</h3>
            <p>Informações da sua conta corporativa</p>
        </div>
        <dl class="info-list info-list-clean">
            <dt>ID</dt><dd><?= e($user['employee_id']) ?></dd>
            <dt>Departamento</dt><dd><?= e($user['department']) ?></dd>
            <dt>Cargo</dt><dd><?= e($user['position']) ?></dd>
            <dt>E-mail</dt><dd><?= e($user['email']) ?></dd>
            <dt>Admissão</dt><dd><?= formatDate($user['hire_date']) ?></dd>
        </dl>
        <a href="perfil.php" class="btn btn-primary btn-sm mt-3">Abrir perfil completo</a>
    </div>
</div>

<?php if ($recentTasks): ?>
<div class="card card-elevated mt-4">
    <div class="card-heading">
        <h3>Últimas tarefas</h3>
        <p>Atividades recentes atribuídas a você</p>
    </div>
    <div class="table-wrap">
        <table class="table table-modern">
            <thead>
                <tr>
                    <th>Tarefa</th>
                    <th>Prioridade</th>
                    <th>Prazo</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentTasks as $task): ?>
                <tr>
                    <td><strong><?= e($task['title']) ?></strong></td>
                    <td><?= e(priorityLabel($task['priority'])) ?></td>
                    <td><?= formatDate($task['due_date']) ?></td>
                    <td><span class="badge badge-<?= e($task['status']) ?>"><?= e(statusLabel($task['status'])) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<?php renderFooter(); ?>

<?php

require_once __DIR__ . '/bootstrap.php';
$user = requireLogin();
$db = getDb();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'request') {
        $start = $_POST['start_date'];
        $end = $_POST['end_date'];
        $days = calcVacationDays($start, $end);
        $empId = isManager($user) && !empty($_POST['employee_id']) ? (int) $_POST['employee_id'] : (int) $user['id'];

        $stmt = $db->prepare('INSERT INTO vacations (employee_id, start_date, end_date, total_days, reason, status) VALUES (?, ?, ?, ?, ?, "pending")');
        $stmt->execute([$empId, $start, $end, $days, trim($_POST['reason'] ?? '')]);
        flash('success', 'Solicitação de férias enviada.');
    }

    if ($action === 'status' && isManager($user)) {
        $stmt = $db->prepare('UPDATE vacations SET status = ?, approved_by_id = ? WHERE id = ?');
        $stmt->execute([$_POST['status'], $user['id'], (int) $_POST['id']]);
        flash('success', 'Status da férias atualizado.');
    }

    if ($action === 'update' && isAdmin($user)) {
        $start = $_POST['start_date'];
        $end = $_POST['end_date'];
        $days = calcVacationDays($start, $end);
        $stmt = $db->prepare('UPDATE vacations SET employee_id = ?, start_date = ?, end_date = ?, total_days = ?, reason = ?, status = ? WHERE id = ?');
        $stmt->execute([
            (int) $_POST['employee_id'],
            $start,
            $end,
            $days,
            trim($_POST['reason'] ?? ''),
            $_POST['status'],
            (int) $_POST['id'],
        ]);
        flash('success', 'Solicitação de férias atualizada.');
        header('Location: ferias.php');
        exit;
    }

    if ($action === 'delete' && isAdmin($user)) {
        $stmt = $db->prepare('DELETE FROM vacations WHERE id = ?');
        $stmt->execute([(int) $_POST['id']]);
        flash('success', 'Solicitação de férias excluída.');
    }

    header('Location: ferias.php');
    exit;
}

$editId = (int) ($_GET['edit'] ?? 0);
$editVacation = null;
if ($editId && isAdmin($user)) {
    $stmt = $db->prepare('SELECT * FROM vacations WHERE id = ?');
    $stmt->execute([$editId]);
    $editVacation = $stmt->fetch() ?: null;
}

$sql = 'SELECT v.*, e.name AS employee_name FROM vacations v JOIN employees e ON e.id = v.employee_id';
$params = [];
if (!isManager($user)) {
    $sql .= ' WHERE v.employee_id = ?';
    $params[] = $user['id'];
}
$sql .= ' ORDER BY v.created_at DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$vacations = $stmt->fetchAll();

$employees = isManager($user) ? $db->query('SELECT id, name FROM employees WHERE status = "active" ORDER BY name')->fetchAll() : [];

renderHeader('Férias', 'ferias.php', 'Solicite períodos de descanso e acompanhe aprovações.');
?>
<?php if ($editVacation): ?>
<div class="card mb-4">
    <h3>Editar férias (admin)</h3>
    <form method="post" class="form">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="<?= (int) $editVacation['id'] ?>">
        <label>Funcionário
            <select name="employee_id" required>
                <?php foreach ($employees as $emp): ?>
                    <option value="<?= (int) $emp['id'] ?>" <?= (int) $editVacation['employee_id'] === (int) $emp['id'] ? 'selected' : '' ?>><?= e($emp['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <div class="form-row">
            <label>Início<input type="date" name="start_date" value="<?= e($editVacation['start_date']) ?>" required></label>
            <label>Fim<input type="date" name="end_date" value="<?= e($editVacation['end_date']) ?>" required></label>
            <label>Status
                <select name="status">
                    <?php foreach (['pending', 'approved', 'rejected'] as $s): ?>
                        <option value="<?= $s ?>" <?= $editVacation['status'] === $s ? 'selected' : '' ?>><?= e(statusLabel($s)) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>
        <label>Motivo<textarea name="reason" rows="2"><?= e($editVacation['reason'] ?? '') ?></textarea></label>
        <div class="actions">
            <button type="submit" class="btn btn-primary">Salvar alterações</button>
            <a href="ferias.php" class="btn btn-ghost btn-sm">Cancelar</a>
        </div>
    </form>
</div>
<?php endif; ?>

<div class="grid grid-2">
    <div class="card">
        <h3>Nova solicitação</h3>
        <form method="post" class="form">
            <input type="hidden" name="action" value="request">
            <?php if (isManager($user)): ?>
            <label>Funcionário
                <select name="employee_id">
                    <?php foreach ($employees as $emp): ?>
                        <option value="<?= (int) $emp['id'] ?>"><?= e($emp['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <?php endif; ?>
            <div class="form-row">
                <label>Início<input type="date" name="start_date" required></label>
                <label>Fim<input type="date" name="end_date" required></label>
            </div>
            <label>Motivo<textarea name="reason" rows="2"></textarea></label>
            <button type="submit" class="btn btn-primary">Solicitar</button>
        </form>
    </div>

    <div class="card">
        <h3>Solicitações</h3>
        <div class="table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <?php if (isManager($user)): ?><th>Funcionário</th><?php endif; ?>
                        <th>Período</th>
                        <th>Dias</th>
                        <th>Status</th>
                        <?php if (isManager($user)): ?><th>Ações</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($vacations as $vac): ?>
                    <tr>
                        <?php if (isManager($user)): ?><td><?= e($vac['employee_name']) ?></td><?php endif; ?>
                        <td><?= formatDate($vac['start_date']) ?> — <?= formatDate($vac['end_date']) ?></td>
                        <td><?= (int) $vac['total_days'] ?></td>
                        <td><span class="badge badge-<?= e($vac['status']) ?>"><?= e(statusLabel($vac['status'])) ?></span></td>
                        <?php if (isManager($user) && $vac['status'] === 'pending'): ?>
                        <td class="actions">
                            <form method="post" class="inline-form">
                                <input type="hidden" name="action" value="status">
                                <input type="hidden" name="id" value="<?= (int) $vac['id'] ?>">
                                <input type="hidden" name="status" value="approved">
                                <button class="btn btn-success btn-sm">Aprovar</button>
                            </form>
                            <form method="post" class="inline-form">
                                <input type="hidden" name="action" value="status">
                                <input type="hidden" name="id" value="<?= (int) $vac['id'] ?>">
                                <input type="hidden" name="status" value="rejected">
                                <button class="btn btn-danger btn-sm">Rejeitar</button>
                            </form>
                            <?php if (isAdmin($user)): ?>
                                <a href="ferias.php?edit=<?= (int) $vac['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                                <form method="post" class="inline-form" onsubmit="return confirm('Excluir esta solicitação?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= (int) $vac['id'] ?>">
                                    <button class="btn btn-danger btn-sm">Excluir</button>
                                </form>
                            <?php endif; ?>
                        </td>
                        <?php elseif (isManager($user)): ?>
                        <td class="actions">
                            <?php if (isAdmin($user)): ?>
                                <a href="ferias.php?edit=<?= (int) $vac['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                                <form method="post" class="inline-form" onsubmit="return confirm('Excluir esta solicitação?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= (int) $vac['id'] ?>">
                                    <button class="btn btn-danger btn-sm">Excluir</button>
                                </form>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php renderFooter(); ?>

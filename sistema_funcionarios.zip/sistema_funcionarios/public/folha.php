<?php

require_once __DIR__ . '/bootstrap.php';
$user = requireLogin();
$db = getDb();

$month = (int) ($_GET['month'] ?? date('n'));
$year = (int) ($_GET['year'] ?? date('Y'));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isAdmin($user)) {
    $action = $_POST['action'] ?? 'generate';

    if ($action === 'update') {
        $bonuses = (float) ($_POST['bonuses'] ?? 0);
        $deductions = (float) ($_POST['deductions'] ?? 0);
        $baseSalary = (float) $_POST['base_salary'];
        $workedDays = (int) $_POST['total_worked_days'];
        $absences = (int) $_POST['total_absences'];
        $netSalary = $baseSalary + $bonuses - $deductions;

        $stmt = $db->prepare('UPDATE payroll SET base_salary = ?, total_worked_days = ?, total_absences = ?, bonuses = ?, deductions = ?, net_salary = ?, generated_at = NOW() WHERE id = ?');
        $stmt->execute([$baseSalary, $workedDays, $absences, $bonuses, $deductions, $netSalary, (int) $_POST['id']]);
        flash('success', 'Folha atualizada com sucesso.');
        header('Location: folha.php?month=' . (int) $_POST['month'] . '&year=' . (int) $_POST['year']);
        exit;
    }

    if ($action === 'delete') {
        $stmt = $db->prepare('DELETE FROM payroll WHERE id = ?');
        $stmt->execute([(int) $_POST['id']]);
        flash('success', 'Registro de folha excluído.');
        header('Location: folha.php?month=' . (int) $_POST['month'] . '&year=' . (int) $_POST['year']);
        exit;
    }

    $empId = (int) $_POST['employee_id'];
    $monthPost = (int) $_POST['month'];
    $yearPost = (int) $_POST['year'];
    $bonuses = (float) ($_POST['bonuses'] ?? 0);
    $deductions = (float) ($_POST['deductions'] ?? 0);

    $stmt = $db->prepare('SELECT salary FROM employees WHERE id = ?');
    $stmt->execute([$empId]);
    $baseSalary = (float) $stmt->fetchColumn();

    $monthStr = sprintf('%04d-%02d', $yearPost, $monthPost);
    $stmt = $db->prepare('SELECT COUNT(*) FROM time_records WHERE employee_id = ? AND date LIKE ? AND status = "present"');
    $stmt->execute([$empId, $monthStr . '%']);
    $workedDays = (int) $stmt->fetchColumn();

    $stmt = $db->prepare('SELECT COUNT(*) FROM time_records WHERE employee_id = ? AND date LIKE ? AND status = "absent"');
    $stmt->execute([$empId, $monthStr . '%']);
    $absences = (int) $stmt->fetchColumn();

    $netSalary = $baseSalary + $bonuses - $deductions;

    $stmt = $db->prepare('INSERT INTO payroll (employee_id, month, year, base_salary, total_worked_days, total_absences, bonuses, deductions, net_salary)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE base_salary = VALUES(base_salary), total_worked_days = VALUES(total_worked_days),
        total_absences = VALUES(total_absences), bonuses = VALUES(bonuses), deductions = VALUES(deductions),
        net_salary = VALUES(net_salary), generated_at = NOW()');
    $stmt->execute([$empId, $monthPost, $yearPost, $baseSalary, $workedDays, $absences, $bonuses, $deductions, $netSalary]);

    flash('success', 'Folha gerada com sucesso.');
    header('Location: folha.php?month=' . $monthPost . '&year=' . $yearPost);
    exit;
}

$sql = 'SELECT p.*, e.name, e.employee_id AS emp_code FROM payroll p JOIN employees e ON e.id = p.employee_id WHERE p.month = ? AND p.year = ?';
$params = [$month, $year];

if (!isAdmin($user)) {
    $sql .= ' AND p.employee_id = ?';
    $params[] = $user['id'];
}
$sql .= ' ORDER BY e.name';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$payrolls = $stmt->fetchAll();

$employees = isAdmin($user) ? $db->query('SELECT id, name FROM employees WHERE status = "active" ORDER BY name')->fetchAll() : [];

$editId = (int) ($_GET['edit'] ?? 0);
$editPayroll = null;
if ($editId && isAdmin($user)) {
    $stmt = $db->prepare('SELECT p.*, e.name FROM payroll p JOIN employees e ON e.id = p.employee_id WHERE p.id = ?');
    $stmt->execute([$editId]);
    $editPayroll = $stmt->fetch() ?: null;
}

renderHeader('Folha de Pagamento', 'folha.php', 'Referência: ' . sprintf('%02d/%d', $month, $year));
?>
<div class="card filters card-elevated mb-4">
    <form method="get" class="form inline-filters">
        <label>Mês<input type="number" min="1" max="12" name="month" value="<?= $month ?>"></label>
        <label>Ano<input type="number" name="year" value="<?= $year ?>"></label>
        <button type="submit" class="btn btn-primary">Filtrar</button>
    </form>
</div>

<?php if ($editPayroll): ?>
<div class="card mb-4">
    <h3>Editar folha de <?= e($editPayroll['name']) ?> (admin)</h3>
    <form method="post" class="form">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="<?= (int) $editPayroll['id'] ?>">
        <input type="hidden" name="month" value="<?= $month ?>">
        <input type="hidden" name="year" value="<?= $year ?>">
        <div class="form-row">
            <label>Salário base<input type="number" step="0.01" name="base_salary" value="<?= e((string) $editPayroll['base_salary']) ?>" required></label>
            <label>Dias trabalhados<input type="number" name="total_worked_days" value="<?= (int) $editPayroll['total_worked_days'] ?>" required></label>
            <label>Faltas<input type="number" name="total_absences" value="<?= (int) $editPayroll['total_absences'] ?>" required></label>
            <label>Bônus<input type="number" step="0.01" name="bonuses" value="<?= e((string) $editPayroll['bonuses']) ?>"></label>
            <label>Descontos<input type="number" step="0.01" name="deductions" value="<?= e((string) $editPayroll['deductions']) ?>"></label>
        </div>
        <div class="actions">
            <button type="submit" class="btn btn-primary">Salvar alterações</button>
            <a href="folha.php?month=<?= $month ?>&year=<?= $year ?>" class="btn btn-ghost btn-sm">Cancelar</a>
        </div>
    </form>
</div>
<?php endif; ?>

<?php if (isAdmin($user)): ?>
<div class="card mb-4">
    <h3>Gerar folha</h3>
    <form method="post" class="form">
        <input type="hidden" name="action" value="generate">
        <div class="form-row">
            <label>Funcionário
                <select name="employee_id" required>
                    <?php foreach ($employees as $emp): ?>
                        <option value="<?= (int) $emp['id'] ?>"><?= e($emp['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Mês<input type="number" min="1" max="12" name="month" value="<?= $month ?>" required></label>
            <label>Ano<input type="number" name="year" value="<?= $year ?>" required></label>
            <label>Bônus<input type="number" step="0.01" name="bonuses" value="0"></label>
            <label>Descontos<input type="number" step="0.01" name="deductions" value="0"></label>
        </div>
        <button type="submit" class="btn btn-primary">Gerar</button>
    </form>
</div>
<?php endif; ?>

<div class="card">
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Funcionário</th>
                    <th>Salário base</th>
                    <th>Dias trabalhados</th>
                    <th>Faltas</th>
                    <th>Bônus</th>
                    <th>Descontos</th>
                    <th>Líquido</th>
                    <?php if (isAdmin($user)): ?><th>Ações</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($payrolls as $p): ?>
                <tr>
                    <td><?= e($p['name']) ?> (<?= e($p['emp_code']) ?>)</td>
                    <td><?= formatMoney((float) $p['base_salary']) ?></td>
                    <td><?= (int) $p['total_worked_days'] ?></td>
                    <td><?= (int) $p['total_absences'] ?></td>
                    <td><?= formatMoney((float) $p['bonuses']) ?></td>
                    <td><?= formatMoney((float) $p['deductions']) ?></td>
                    <td><strong><?= formatMoney((float) $p['net_salary']) ?></strong></td>
                    <?php if (isAdmin($user)): ?>
                    <td class="actions">
                        <a href="folha.php?month=<?= $month ?>&year=<?= $year ?>&edit=<?= (int) $p['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                        <form method="post" class="inline-form" onsubmit="return confirm('Excluir este registro de folha?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                            <input type="hidden" name="month" value="<?= $month ?>">
                            <input type="hidden" name="year" value="<?= $year ?>">
                            <button class="btn btn-danger btn-sm">Excluir</button>
                        </form>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
                <?php if (!$payrolls): ?>
                <tr><td colspan="<?= isAdmin($user) ? 8 : 7 ?>" class="muted">Nenhuma folha gerada para este período.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php renderFooter(); ?>

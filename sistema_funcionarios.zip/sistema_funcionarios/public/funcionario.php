<?php

require_once __DIR__ . '/bootstrap.php';
$user = requireRole(['admin']);
$db = getDb();
$id = (int) ($_GET['id'] ?? 0);
$editMode = isset($_GET['edit']);

$employee = fetchEmployee($id);
if (!$employee) {
    flash('error', 'Funcionário não encontrado.');
    header('Location: funcionarios.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update') {
        $sql = 'UPDATE employees SET employee_id = ?, name = ?, email = ?, role = ?, department = ?, position = ?, salary = ?, hire_date = ?, phone = ?, address = ?, status = ?';
        $params = [
            trim($_POST['employee_id']),
            trim($_POST['name']),
            trim($_POST['email']),
            $_POST['role'],
            trim($_POST['department']),
            trim($_POST['position']),
            (float) $_POST['salary'],
            $_POST['hire_date'],
            trim($_POST['phone'] ?? ''),
            trim($_POST['address'] ?? ''),
            $_POST['status'],
        ];

        if (!empty($_POST['password'])) {
            $sql .= ', password_hash = ?';
            $params[] = password_hash($_POST['password'], PASSWORD_DEFAULT);
        }

        $sql .= ' WHERE id = ?';
        $params[] = $id;

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        refreshSessionUser($id);
        flash('success', 'Funcionário atualizado com sucesso.');
        header('Location: funcionario.php?id=' . $id);
        exit;
    }

    if ($action === 'observation') {
        $stmt = $db->prepare('INSERT INTO observations (employee_id, content, created_by_id) VALUES (?, ?, ?)');
        $stmt->execute([$id, trim($_POST['content']), $user['id']]);
        flash('success', 'Observação adicionada.');
        header('Location: funcionario.php?id=' . $id);
        exit;
    }

    if ($action === 'update_observation') {
        $stmt = $db->prepare('UPDATE observations SET content = ? WHERE id = ? AND employee_id = ?');
        $stmt->execute([trim($_POST['content']), (int) $_POST['obs_id'], $id]);
        flash('success', 'Observação atualizada.');
        header('Location: funcionario.php?id=' . $id);
        exit;
    }

    if ($action === 'delete_observation') {
        $stmt = $db->prepare('DELETE FROM observations WHERE id = ? AND employee_id = ?');
        $stmt->execute([(int) $_POST['obs_id'], $id]);
        flash('success', 'Observação removida.');
        header('Location: funcionario.php?id=' . $id);
        exit;
    }

    header('Location: funcionario.php?id=' . $id);
    exit;
}

$employee = fetchEmployee($id);
$stmt = $db->prepare('SELECT o.*, e.name AS author_name FROM observations o JOIN employees e ON e.id = o.created_by_id WHERE o.employee_id = ? ORDER BY o.created_at DESC');
$stmt->execute([$id]);
$observations = $stmt->fetchAll();

renderHeader('Gerenciar Funcionário', 'funcionarios.php', '', false);
?>
<div class="profile-hero card card-elevated">
    <div class="profile-identity">
        <div class="profile-avatar"><?= e(strtoupper(substr($employee['name'], 0, 1))) ?></div>
        <div>
            <h1><?= e($employee['name']) ?></h1>
            <p><?= e($employee['employee_id']) ?> · <?= e($employee['department']) ?></p>
        </div>
    </div>
    <div class="profile-actions">
        <a href="perfil.php?id=<?= $id ?>" class="btn btn-primary btn-sm">Ver perfil</a>
        <?php if (!$editMode): ?>
            <a href="funcionario.php?id=<?= $id ?>&edit=1" class="btn btn-warning btn-sm">Editar dados</a>
        <?php else: ?>
            <a href="funcionario.php?id=<?= $id ?>" class="btn btn-ghost btn-sm">Cancelar edição</a>
        <?php endif; ?>
    </div>
</div>

<?php if ($editMode): ?>
<div class="card mb-4">
    <h3>Editar funcionário</h3>
    <form method="post" class="form">
        <input type="hidden" name="action" value="update">
        <div class="form-row">
            <label>ID<input name="employee_id" value="<?= e($employee['employee_id']) ?>" required></label>
            <label>Nome<input name="name" value="<?= e($employee['name']) ?>" required></label>
        </div>
        <div class="form-row">
            <label>E-mail<input type="email" name="email" value="<?= e($employee['email']) ?>" required></label>
            <label>Nova senha <small class="muted">(deixe em branco para manter)</small><input type="password" name="password"></label>
        </div>
        <div class="form-row">
            <label>Departamento<input name="department" value="<?= e($employee['department']) ?>" required></label>
            <label>Cargo<input name="position" value="<?= e($employee['position']) ?>" required></label>
        </div>
        <div class="form-row">
            <label>Salário<input type="number" step="0.01" name="salary" value="<?= e((string) $employee['salary']) ?>" required></label>
            <label>Admissão<input type="date" name="hire_date" value="<?= e($employee['hire_date']) ?>" required></label>
        </div>
        <div class="form-row">
            <label>Telefone<input name="phone" value="<?= e($employee['phone'] ?? '') ?>"></label>
            <label>Papel
                <select name="role">
                    <option value="employee" <?= $employee['role'] === 'employee' ? 'selected' : '' ?>>Funcionário</option>
                    <option value="manager" <?= $employee['role'] === 'manager' ? 'selected' : '' ?>>Gerente</option>
                    <option value="admin" <?= $employee['role'] === 'admin' ? 'selected' : '' ?>>Administrador</option>
                </select>
            </label>
        </div>
        <label>Endereço<textarea name="address" rows="2"><?= e($employee['address'] ?? '') ?></textarea></label>
        <label>Status
            <select name="status">
                <option value="active" <?= $employee['status'] === 'active' ? 'selected' : '' ?>>Ativo</option>
                <option value="inactive" <?= $employee['status'] === 'inactive' ? 'selected' : '' ?>>Inativo</option>
            </select>
        </label>
        <button type="submit" class="btn btn-primary">Salvar alterações</button>
    </form>
</div>
<?php endif; ?>

<div class="grid grid-2">
    <div class="card">
        <h3>Dados cadastrais</h3>
        <dl class="info-list">
            <dt>E-mail</dt><dd><?= e($employee['email']) ?></dd>
            <dt>Cargo</dt><dd><?= e($employee['position']) ?></dd>
            <dt>Salário</dt><dd><?= formatMoney((float) $employee['salary']) ?></dd>
            <dt>Admissão</dt><dd><?= formatDate($employee['hire_date']) ?></dd>
            <dt>Telefone</dt><dd><?= e($employee['phone'] ?: '-') ?></dd>
            <dt>Endereço</dt><dd><?= e($employee['address'] ?: '-') ?></dd>
            <dt>Papel</dt><dd><?= e(roleLabel($employee['role'])) ?></dd>
            <dt>Status</dt><dd><?= e(statusLabel($employee['status'])) ?></dd>
        </dl>
        <a href="calendario.php?employee_id=<?= $id ?>" class="btn btn-primary mt-3">Ver calendário</a>
    </div>

    <div class="card">
        <h3>Observações</h3>
        <form method="post" class="form">
            <input type="hidden" name="action" value="observation">
            <label>
                Nova observação
                <textarea name="content" rows="3" required></textarea>
            </label>
            <button type="submit" class="btn btn-primary">Salvar</button>
        </form>
        <div class="obs-list mt-3">
            <?php foreach ($observations as $obs): ?>
                <div class="obs-item">
                    <form method="post" class="form obs-edit-form">
                        <input type="hidden" name="action" value="update_observation">
                        <input type="hidden" name="obs_id" value="<?= (int) $obs['id'] ?>">
                        <textarea name="content" rows="2" required><?= e($obs['content']) ?></textarea>
                        <div class="obs-edit-actions">
                            <small><?= e($obs['author_name']) ?> · <?= date('d/m/Y H:i', strtotime($obs['created_at'])) ?></small>
                            <button type="submit" class="btn btn-info btn-sm">Atualizar</button>
                        </div>
                    </form>
                    <form method="post" class="inline-form mt-3">
                        <input type="hidden" name="action" value="delete_observation">
                        <input type="hidden" name="obs_id" value="<?= (int) $obs['id'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Excluir observação</button>
                    </form>
                </div>
            <?php endforeach; ?>
            <?php if (!$observations): ?>
                <p class="muted">Nenhuma observação registrada.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php renderFooter(); ?>

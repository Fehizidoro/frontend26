<?php

require_once __DIR__ . '/bootstrap.php';
$user = requireRole(['admin']);
$db = getDb();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt = $db->prepare('INSERT INTO employees (employee_id, name, email, password_hash, role, department, position, salary, hire_date, phone, address, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            trim($_POST['employee_id']),
            trim($_POST['name']),
            trim($_POST['email']),
            $hash,
            $_POST['role'],
            trim($_POST['department']),
            trim($_POST['position']),
            (float) $_POST['salary'],
            $_POST['hire_date'],
            trim($_POST['phone'] ?? ''),
            trim($_POST['address'] ?? ''),
            $_POST['status'] ?? 'active',
        ]);
        flash('success', 'Funcionário cadastrado com sucesso.');
    }

    if ($action === 'toggle_status') {
        $stmt = $db->prepare('UPDATE employees SET status = IF(status = "active", "inactive", "active") WHERE id = ?');
        $stmt->execute([(int) $_POST['id']]);
        flash('success', 'Status atualizado.');
    }

    header('Location: funcionarios.php');
    exit;
}

$employees = $db->query('SELECT id, employee_id, name, email, role, department, position, salary, hire_date, phone, status FROM employees ORDER BY name')->fetchAll();

renderHeader('Funcionários', 'funcionarios.php', 'Cadastro, edição e gestão completa dos colaboradores.');
?>
<div class="grid grid-2">
    <div class="card">
        <h3>Novo funcionário</h3>
        <form method="post" class="form">
            <input type="hidden" name="action" value="create">
            <div class="form-row">
                <label>ID<input name="employee_id" required></label>
                <label>Nome<input name="name" required></label>
            </div>
            <div class="form-row">
                <label>E-mail<input type="email" name="email" required></label>
                <label>Senha<input type="password" name="password" required></label>
            </div>
            <div class="form-row">
                <label>Departamento<input name="department" required></label>
                <label>Cargo<input name="position" required></label>
            </div>
            <div class="form-row">
                <label>Salário<input type="number" step="0.01" name="salary" required></label>
                <label>Admissão<input type="date" name="hire_date" required></label>
            </div>
            <label>Endereço<textarea name="address" rows="2"></textarea></label>
            <div class="form-row">
                <label>Telefone<input name="phone"></label>
                <label>Papel
                    <select name="role">
                        <option value="employee">Funcionário</option>
                        <option value="manager">Gerente</option>
                        <option value="admin">Administrador</option>
                    </select>
                </label>
            </div>
            <button type="submit" class="btn btn-primary">Cadastrar</button>
        </form>
    </div>

    <div class="card">
        <h3>Lista (<?= count($employees) ?>)</h3>
        <div class="table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Departamento</th>
                        <th>Papel</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($employees as $emp): ?>
                    <tr>
                        <td><?= e($emp['employee_id']) ?></td>
                        <td><a href="funcionario.php?id=<?= (int) $emp['id'] ?>"><?= e($emp['name']) ?></a></td>
                        <td><?= e($emp['department']) ?></td>
                        <td><?= e(roleLabel($emp['role'])) ?></td>
                        <td><span class="badge"><?= e(statusLabel($emp['status'])) ?></span></td>
                        <td class="actions">
                            <a href="funcionario.php?id=<?= (int) $emp['id'] ?>&edit=1" class="btn btn-warning btn-sm">Editar</a>
                            <form method="post" class="inline-form">
                                <input type="hidden" name="action" value="toggle_status">
                                <input type="hidden" name="id" value="<?= (int) $emp['id'] ?>">
                                <button class="btn btn-ghost btn-sm" type="submit">Status</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php renderFooter(); ?>

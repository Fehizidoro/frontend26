<?php

require_once __DIR__ . '/bootstrap.php';

if (currentUser()) {
    header('Location: dashboard.php');
    exit;
}

$db = getDb();
$stats = [
    'employees' => (int) $db->query("SELECT COUNT(*) FROM employees WHERE status = 'active'")->fetchColumn(),
    'departments' => (int) $db->query('SELECT COUNT(DISTINCT department) FROM employees')->fetchColumn(),
    'tasks' => (int) $db->query("SELECT COUNT(*) FROM tasks WHERE status IN ('pending', 'in_progress')")->fetchColumn(),
    'vacations' => (int) $db->query("SELECT COUNT(*) FROM vacations WHERE status = 'pending'")->fetchColumn(),
];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employeeId = trim($_POST['employee_id'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($employeeId === '' || $password === '') {
        $error = 'Informe o ID e a senha.';
    } else {
        $stmt = getDb()->prepare('SELECT * FROM employees WHERE employee_id = ? LIMIT 1');
        $stmt->execute([$employeeId]);
        $employee = $stmt->fetch();

        if (!$employee || $employee['status'] !== 'active' || !password_verify($password, $employee['password_hash'])) {
            $error = 'ID ou senha inválidos.';
        } else {
            loginUser($employee);
            header('Location: dashboard.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema RH</title>
    <script>
        (function () {
            if (localStorage.getItem('theme') === 'dark') {
                document.documentElement.setAttribute('data-theme', 'dark');
            }
        })();
    </script>
    <script src="assets/js/app.js?v=2"></script>
    <link rel="stylesheet" href="assets/css/style.css?v=3">
</head>
<body class="login-page">
    <button type="button" class="login-theme-toggle" data-theme-toggle onclick="toggleTheme()" aria-label="Alternar modo escuro">🌙</button>
    <div class="login-shell">
        <header class="login-topbar">
            <div class="login-brand">
                <span class="login-brand-icon" aria-hidden="true">RH</span>
                <div>
                    <strong>PeopleHub RH</strong>
                    <small>Plataforma corporativa de gestão de pessoas</small>
                </div>
            </div>
            <div class="login-topbar-meta">
                <span><?= date('d/m/Y') ?></span>
                <span class="login-status-dot"></span>
                <span>Sistema operacional</span>
            </div>
        </header>

        <div class="login-container">
            <section class="login-hero">
                <p class="login-eyebrow">Gestão integrada de recursos humanos</p>
                <h1>Controle completo da sua equipe em um só lugar</h1>
                <p class="login-lead">
                    Centralize ponto eletrônico, férias, tarefas, folha de pagamento e relatórios
                    gerenciais com segurança, rastreabilidade e visão em tempo real.
                </p>

                <div class="login-stats">
                    <article class="login-stat">
                        <strong><?= $stats['employees'] ?></strong>
                        <span>Colaboradores ativos</span>
                    </article>
                    <article class="login-stat">
                        <strong><?= $stats['departments'] ?></strong>
                        <span>Departamentos</span>
                    </article>
                    <article class="login-stat">
                        <strong><?= $stats['tasks'] ?></strong>
                        <span>Tarefas em aberto</span>
                    </article>
                    <article class="login-stat">
                        <strong><?= $stats['vacations'] ?></strong>
                        <span>Férias pendentes</span>
                    </article>
                </div>

                <div class="login-features">
                    <article class="login-feature">
                        <span class="login-feature-icon">🕐</span>
                        <div>
                            <strong>Controle de ponto</strong>
                            <p>Registro de entrada, intervalo e saída com histórico diário.</p>
                        </div>
                    </article>
                    <article class="login-feature">
                        <span class="login-feature-icon">📅</span>
                        <div>
                            <strong>Calendário de presença</strong>
                            <p>Visualização mensal de presenças, faltas e horários parciais.</p>
                        </div>
                    </article>
                    <article class="login-feature">
                        <span class="login-feature-icon">✅</span>
                        <div>
                            <strong>Tarefas e aprovações</strong>
                            <p>Distribuição de atividades com prioridade e acompanhamento.</p>
                        </div>
                    </article>
                    <article class="login-feature">
                        <span class="login-feature-icon">💰</span>
                        <div>
                            <strong>Folha e relatórios</strong>
                            <p>Consolidação salarial e indicadores para a liderança.</p>
                        </div>
                    </article>
                </div>
            </section>

            <section class="login-card">
                <div class="login-card-header">
                    <h2>Acesso ao sistema</h2>
                    <p class="subtitle">Informe seu ID corporativo e senha para continuar</p>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-error"><?= e($error) ?></div>
                <?php endif; ?>

                <form method="post" class="form login-form">
                    <label>
                        ID do funcionário
                        <input type="text" name="employee_id" placeholder="Ex.: ADM001, GER001 ou EMP001" required autofocus>
                    </label>
                    <label>
                        Senha de acesso
                        <input type="password" name="password" placeholder="Digite sua senha" required>
                    </label>
                    <button type="submit" class="btn btn-primary btn-block">Entrar na plataforma</button>
                </form>

                <div class="login-security-note">
                    <strong>Ambiente seguro</strong>
                    <p>Sessões autenticadas, perfis de acesso por função e registro de atividades críticas.</p>
                </div>

                <div class="demo-logins">
                    <div class="demo-logins-header">
                        <strong>Acesso rápido para demonstração</strong>
                        <p>Selecione um perfil para entrar automaticamente e explorar o sistema.</p>
                    </div>
                    <div class="demo-buttons">
                        <form method="post">
                            <input type="hidden" name="employee_id" value="ADM001">
                            <input type="hidden" name="password" value="admin123">
                            <button type="submit" class="btn btn-demo btn-demo-admin">
                                <span class="btn-demo-top">
                                    <span class="btn-demo-role">Administrador</span>
                                    <span class="badge badge-admin">ADM001</span>
                                </span>
                                <small>Carlos Admin · TI</small>
                                <span class="btn-demo-desc">Acesso total: funcionários, relatórios, folha e configurações.</span>
                            </button>
                        </form>
                        <form method="post">
                            <input type="hidden" name="employee_id" value="GER001">
                            <input type="hidden" name="password" value="gerente123">
                            <button type="submit" class="btn btn-demo btn-demo-manager">
                                <span class="btn-demo-top">
                                    <span class="btn-demo-role">Gerente</span>
                                    <span class="badge badge-manager">GER001</span>
                                </span>
                                <small>Ana Gerente · Desenvolvimento</small>
                                <span class="btn-demo-desc">Gestão de equipe, aprovação de férias e acompanhamento de tarefas.</span>
                            </button>
                        </form>
                        <form method="post">
                            <input type="hidden" name="employee_id" value="EMP001">
                            <input type="hidden" name="password" value="func123">
                            <button type="submit" class="btn btn-demo btn-demo-employee">
                                <span class="btn-demo-top">
                                    <span class="btn-demo-role">Funcionário</span>
                                    <span class="badge badge-employee">EMP001</span>
                                </span>
                                <small>João Silva · Desenvolvimento</small>
                                <span class="btn-demo-desc">Registro de ponto, consulta de férias e execução de tarefas.</span>
                            </button>
                        </form>
                    </div>
                </div>
            </section>
        </div>

        <footer class="login-footer">
            <span>PeopleHub RH · Sistema de Controle de Funcionários</span>
            <span>Versão 1.0 · Ambiente de demonstração</span>
        </footer>
    </div>
</body>
</html>

<?php

require_once __DIR__ . '/bootstrap.php';
$user = requireLogin();
$db = getDb();

$profileId = (int) ($_GET['id'] ?? $user['id']);
$isOwnProfile = $profileId === (int) $user['id'];
$canManage = isAdmin($user);

if (!$isOwnProfile && !$canManage) {
    header('Location: perfil.php');
    exit;
}

$employee = fetchEmployee($profileId);
if (!$employee) {
    flash('error', 'Perfil não encontrado.');
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_self' && $isOwnProfile) {
        $stmt = $db->prepare('UPDATE employees SET email = ?, phone = ?, address = ? WHERE id = ?');
        $stmt->execute([
            trim($_POST['email']),
            trim($_POST['phone'] ?? ''),
            trim($_POST['address'] ?? ''),
            $profileId,
        ]);
        refreshSessionUser($profileId);
        flash('success', 'Perfil atualizado com sucesso.');
    }

    if ($action === 'update_password' && $isOwnProfile) {
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        $stmt = $db->prepare('SELECT password_hash FROM employees WHERE id = ?');
        $stmt->execute([$profileId]);
        $hash = $stmt->fetchColumn();

        if (!password_verify($current, $hash)) {
            flash('error', 'Senha atual incorreta.');
        } elseif (strlen($new) < 6) {
            flash('error', 'A nova senha deve ter pelo menos 6 caracteres.');
        } elseif ($new !== $confirm) {
            flash('error', 'A confirmação da senha não confere.');
        } else {
            $stmt = $db->prepare('UPDATE employees SET password_hash = ? WHERE id = ?');
            $stmt->execute([password_hash($new, PASSWORD_DEFAULT), $profileId]);
            flash('success', 'Senha alterada com sucesso.');
        }
    }

    header('Location: perfil.php' . ($isOwnProfile ? '' : '?id=' . $profileId));
    exit;
}

$stmt = $db->prepare("SELECT COUNT(*) FROM tasks WHERE assigned_to_id = ? AND status IN ('pending', 'in_progress')");
$stmt->execute([$profileId]);
$openTasks = (int) $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM vacations WHERE employee_id = ? AND status = 'approved' AND end_date >= CURDATE()");
$stmt->execute([$profileId]);
$upcomingVacations = (int) $stmt->fetchColumn();

$stmt = $db->prepare('SELECT COUNT(*) FROM time_records WHERE employee_id = ? AND date LIKE ? AND status = "present"');
$stmt->execute([$profileId, date('Y-m') . '%']);
$monthPresence = (int) $stmt->fetchColumn();

$stmt = $db->prepare('SELECT o.*, e.name AS author_name FROM observations o JOIN employees e ON e.id = o.created_by_id WHERE o.employee_id = ? ORDER BY o.created_at DESC LIMIT 5');
$stmt->execute([$profileId]);
$observations = $stmt->fetchAll();

renderHeader($isOwnProfile ? 'Meu Perfil' : 'Perfil do Funcionário', 'perfil.php', '', false);
?>
<div class="profile-hero card card-elevated">
    <div class="profile-identity">
        <div class="profile-avatar"><?= e(strtoupper(substr($employee['name'], 0, 1))) ?></div>
        <div>
            <h1><?= e($employee['name']) ?></h1>
            <p><?= e($employee['employee_id']) ?> · <?= e($employee['department']) ?> · <?= e($employee['position']) ?></p>
            <div class="profile-badges">
                <span class="badge badge-<?= e($employee['role']) ?>"><?= e(roleLabel($employee['role'])) ?></span>
                <span class="badge"><?= e(statusLabel($employee['status'])) ?></span>
            </div>
        </div>
    </div>
    <div class="profile-actions">
        <a href="calendario.php?employee_id=<?= $profileId ?>" class="btn btn-primary btn-sm">Calendário</a>
        <?php if ($canManage && !$isOwnProfile): ?>
            <a href="funcionario.php?id=<?= $profileId ?>&edit=1" class="btn btn-warning btn-sm">Editar (admin)</a>
        <?php endif; ?>
    </div>
</div>

<div class="grid grid-4 mb-4">
    <div class="card stat-card">
        <span class="stat-label">Tarefas em aberto</span>
        <strong class="stat-value"><?= $openTasks ?></strong>
    </div>
    <div class="card stat-card">
        <span class="stat-label">Férias futuras</span>
        <strong class="stat-value"><?= $upcomingVacations ?></strong>
    </div>
    <div class="card stat-card">
        <span class="stat-label">Presenças no mês</span>
        <strong class="stat-value"><?= $monthPresence ?></strong>
    </div>
    <div class="card stat-card">
        <span class="stat-label">Admissão</span>
        <strong class="stat-value stat-value-sm"><?= formatDate($employee['hire_date']) ?></strong>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <h3>Informações profissionais</h3>
        <dl class="info-list">
            <dt>E-mail</dt><dd><?= e($employee['email']) ?></dd>
            <dt>Telefone</dt><dd><?= e($employee['phone'] ?: '-') ?></dd>
            <dt>Endereço</dt><dd><?= e($employee['address'] ?: '-') ?></dd>
            <?php if ($canManage): ?>
            <dt>Salário</dt><dd><?= formatMoney((float) $employee['salary']) ?></dd>
            <?php endif; ?>
            <dt>Cadastro</dt><dd><?= date('d/m/Y', strtotime($employee['created_at'])) ?></dd>
        </dl>
    </div>

    <?php if ($isOwnProfile): ?>
    <div class="card">
        <h3>Atualizar meus dados</h3>
        <form method="post" class="form">
            <input type="hidden" name="action" value="update_self">
            <label>E-mail<input type="email" name="email" value="<?= e($employee['email']) ?>" required></label>
            <label>Telefone<input name="phone" value="<?= e($employee['phone'] ?? '') ?>"></label>
            <label>Endereço<textarea name="address" rows="2"><?= e($employee['address'] ?? '') ?></textarea></label>
            <button type="submit" class="btn btn-primary">Salvar alterações</button>
        </form>
    </div>

    <div class="card">
        <h3>Alterar senha</h3>
        <form method="post" class="form">
            <input type="hidden" name="action" value="update_password">
            <label>Senha atual<input type="password" name="current_password" required></label>
            <label>Nova senha<input type="password" name="new_password" minlength="6" required></label>
            <label>Confirmar nova senha<input type="password" name="confirm_password" minlength="6" required></label>
            <button type="submit" class="btn btn-warning">Alterar senha</button>
        </form>
    </div>
    <?php endif; ?>

    <div class="card">
        <h3>Observações recentes</h3>
        <div class="obs-list">
            <?php foreach ($observations as $obs): ?>
                <div class="obs-item">
                    <p><?= e($obs['content']) ?></p>
                    <small><?= e($obs['author_name']) ?> · <?= date('d/m/Y H:i', strtotime($obs['created_at'])) ?></small>
                </div>
            <?php endforeach; ?>
            <?php if (!$observations): ?>
                <p class="muted">Nenhuma observação registrada.</p>
            <?php endif; ?>
        </div>
        <?php if ($canManage && !$isOwnProfile): ?>
            <a href="funcionario.php?id=<?= $profileId ?>" class="btn btn-ghost btn-sm mt-3">Gerenciar observações</a>
        <?php endif; ?>
    </div>
</div>
<?php renderFooter(); ?>

<?php

require_once __DIR__ . '/bootstrap.php';
$user = requireLogin();
$db = getDb();
$today = date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $now = date('H:i:s');
    $fieldMap = [
        'entry' => 'entry_time',
        'lunch_start' => 'lunch_start',
        'lunch_end' => 'lunch_end',
        'exit' => 'exit_time',
    ];

    if (!isset($fieldMap[$action])) {
        flash('error', 'Ação inválida.');
    } else {
        $field = $fieldMap[$action];
        $stmt = $db->prepare('SELECT * FROM time_records WHERE employee_id = ? AND date = ?');
        $stmt->execute([$user['id'], $today]);
        $record = $stmt->fetch();

        if ($record) {
            $updated = array_merge($record, [$field => $now]);
            $hours = calcHours($updated['entry_time'], $updated['lunch_start'], $updated['lunch_end'], $updated['exit_time']);
            $status = $updated['exit_time'] ? 'present' : 'partial';

            $stmt = $db->prepare("UPDATE time_records SET {$field} = ?, total_hours = ?, status = ? WHERE id = ?");
            $stmt->execute([$now, $hours, $status, $record['id']]);
        } else {
            $stmt = $db->prepare("INSERT INTO time_records (employee_id, date, {$field}, status) VALUES (?, ?, ?, 'partial')");
            $stmt->execute([$user['id'], $today, $now]);
        }

        $labels = [
            'entry' => 'Entrada registrada!',
            'lunch_start' => 'Saída para almoço registrada!',
            'lunch_end' => 'Retorno do almoço registrado!',
            'exit' => 'Saída registrada!',
        ];
        flash('success', $labels[$action]);
    }

    header('Location: ponto.php');
    exit;
}

$stmt = $db->prepare('SELECT * FROM time_records WHERE employee_id = ? AND date = ?');
$stmt->execute([$user['id'], $today]);
$record = $stmt->fetch() ?: [];

$canEntry = empty($record['entry_time']);
$canLunchStart = !empty($record['entry_time']) && empty($record['lunch_start']);
$canLunchEnd = !empty($record['lunch_start']) && empty($record['lunch_end']);
$canExit = !empty($record['entry_time']) && empty($record['exit_time']) && (empty($record['lunch_start']) || !empty($record['lunch_end']));

renderHeader('Controle de Ponto', 'ponto.php', 'Registre entrada, intervalo e saída do expediente em tempo real.');
?>
<div class="card clock-card card-elevated">
    <div class="clock-display" id="live-clock"><?= date('H:i:s') ?></div>
    <p class="clock-date"><?= formatDate($today) ?></p>
</div>

<div class="grid grid-4">
    <form method="post" class="clock-action">
        <input type="hidden" name="action" value="entry">
        <button class="btn btn-success btn-block" <?= $canEntry ? '' : 'disabled' ?>>Entrada</button>
    </form>
    <form method="post" class="clock-action">
        <input type="hidden" name="action" value="lunch_start">
        <button class="btn btn-warning btn-block" <?= $canLunchStart ? '' : 'disabled' ?>>Saída Almoço</button>
    </form>
    <form method="post" class="clock-action">
        <input type="hidden" name="action" value="lunch_end">
        <button class="btn btn-info btn-block" <?= $canLunchEnd ? '' : 'disabled' ?>>Retorno Almoço</button>
    </form>
    <form method="post" class="clock-action">
        <input type="hidden" name="action" value="exit">
        <button class="btn btn-danger btn-block" <?= $canExit ? '' : 'disabled' ?>>Saída</button>
    </form>
</div>

<div class="card mt-4">
    <h3>Registro de hoje</h3>
    <table class="table">
        <thead>
            <tr>
                <th>Entrada</th>
                <th>Almoço (saída)</th>
                <th>Almoço (retorno)</th>
                <th>Saída</th>
                <th>Total</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?= formatTime($record['entry_time'] ?? null) ?></td>
                <td><?= formatTime($record['lunch_start'] ?? null) ?></td>
                <td><?= formatTime($record['lunch_end'] ?? null) ?></td>
                <td><?= formatTime($record['exit_time'] ?? null) ?></td>
                <td><?= isset($record['total_hours']) ? number_format((float) $record['total_hours'], 2, ',', '.') . 'h' : '-' ?></td>
                <td><span class="badge"><?= e(statusLabel($record['status'] ?? 'partial')) ?></span></td>
            </tr>
        </tbody>
    </table>
</div>
<?php renderFooter(); ?>

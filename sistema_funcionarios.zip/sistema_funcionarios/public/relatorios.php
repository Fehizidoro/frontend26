<?php

require_once __DIR__ . '/bootstrap.php';
$user = requireRole(['admin']);
$db = getDb();

$month = $_GET['month'] ?? date('Y-m');

$stmt = $db->prepare('
    SELECT e.id, e.employee_id, e.name, e.department,
           COUNT(tr.id) AS total_records,
           SUM(CASE WHEN tr.status = "present" THEN 1 ELSE 0 END) AS present_days,
           SUM(CASE WHEN tr.status = "absent" THEN 1 ELSE 0 END) AS absent_days,
           SUM(COALESCE(tr.total_hours, 0)) AS total_hours
    FROM employees e
    LEFT JOIN time_records tr ON tr.employee_id = e.id AND tr.date LIKE ?
    WHERE e.status = "active"
    GROUP BY e.id, e.employee_id, e.name, e.department
    ORDER BY e.name
');
$stmt->execute([$month . '%']);
$report = $stmt->fetchAll();

$totals = [
    'employees' => count($report),
    'present' => array_sum(array_column($report, 'present_days')),
    'absent' => array_sum(array_column($report, 'absent_days')),
    'hours' => array_sum(array_column($report, 'total_hours')),
];

renderHeader('Relatórios de Frequência', 'relatorios.php', 'Resumo mensal de presença, faltas e horas trabalhadas.');
?>
<div class="grid grid-4 mb-4">
    <div class="card stat-card stat-card-blue">
        <span class="stat-label">Colaboradores</span>
        <strong class="stat-value"><?= $totals['employees'] ?></strong>
    </div>
    <div class="card stat-card stat-card-green">
        <span class="stat-label">Dias presentes</span>
        <strong class="stat-value"><?= $totals['present'] ?></strong>
    </div>
    <div class="card stat-card stat-card-amber">
        <span class="stat-label">Faltas</span>
        <strong class="stat-value"><?= $totals['absent'] ?></strong>
    </div>
    <div class="card stat-card stat-card-purple">
        <span class="stat-label">Horas totais</span>
        <strong class="stat-value"><?= number_format((float) $totals['hours'], 1, ',', '.') ?></strong>
    </div>
</div>

<div class="card filters card-elevated mb-4">
    <form method="get" class="form inline-filters">
        <label>Mês<input type="month" name="month" value="<?= e($month) ?>"></label>
        <button type="submit" class="btn btn-primary">Gerar</button>
    </form>
</div>

<div class="card card-elevated">
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Funcionário</th>
                    <th>Departamento</th>
                    <th>Presentes</th>
                    <th>Faltas</th>
                    <th>Horas</th>
                    <th>Média/dia</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($report as $row): ?>
                <tr>
                    <td><?= e($row['name']) ?> (<?= e($row['employee_id']) ?>)</td>
                    <td><?= e($row['department']) ?></td>
                    <td><?= (int) $row['present_days'] ?></td>
                    <td><?= (int) $row['absent_days'] ?></td>
                    <td><?= number_format((float) $row['total_hours'], 1, ',', '.') ?>h</td>
                    <td><?= $row['present_days'] > 0 ? number_format((float) $row['total_hours'] / (int) $row['present_days'], 1, ',', '.') . 'h' : '-' ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php renderFooter(); ?>

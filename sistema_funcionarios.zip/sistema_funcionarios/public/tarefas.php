<?php

require_once __DIR__ . '/bootstrap.php';
$user = requireLogin();
$db = getDb();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create' && isManager($user)) {
        $stmt = $db->prepare('INSERT INTO tasks (title, description, assigned_to_id, created_by_id, priority, due_date, status) VALUES (?, ?, ?, ?, ?, ?, "pending")');
        $stmt->execute([
            trim($_POST['title']),
            trim($_POST['description']),
            (int) $_POST['assigned_to_id'],
            $user['id'],
            $_POST['priority'],
            $_POST['due_date'] ?: null,
        ]);
        flash('success', 'Tarefa criada.');
    }

    if ($action === 'status') {
        $taskId = (int) $_POST['id'];
        $status = $_POST['status'];
        $stmt = $db->prepare('SELECT * FROM tasks WHERE id = ?');
        $stmt->execute([$taskId]);
        $task = $stmt->fetch();

        if ($task && ((int) $task['assigned_to_id'] === (int) $user['id'] || isManager($user))) {
            $completedAt = $status === 'completed' ? date('Y-m-d H:i:s') : null;
            $stmt = $db->prepare('UPDATE tasks SET status = ?, completed_at = COALESCE(?, completed_at) WHERE id = ?');
            $stmt->execute([$status, $completedAt, $taskId]);
            flash('success', 'Status da tarefa atualizado.');
        }
    }

    if ($action === 'approve' && isAdmin($user)) {
        $status = $_POST['status'];
        $stmt = $db->prepare('UPDATE tasks SET status = ?, approved_at = NOW(), rejection_reason = ? WHERE id = ?');
        $stmt->execute([
            $status,
            $status === 'rejected' ? trim($_POST['reason'] ?? '') : null,
            (int) $_POST['id'],
        ]);
        flash('success', 'Tarefa revisada pelo admin.');
    }

    if ($action === 'update' && isAdmin($user)) {
        $stmt = $db->prepare('UPDATE tasks SET title = ?, description = ?, assigned_to_id = ?, priority = ?, due_date = ?, status = ? WHERE id = ?');
        $stmt->execute([
            trim($_POST['title']),
            trim($_POST['description']),
            (int) $_POST['assigned_to_id'],
            $_POST['priority'],
            $_POST['due_date'] ?: null,
            $_POST['status'],
            (int) $_POST['id'],
        ]);
        flash('success', 'Tarefa atualizada.');
        header('Location: tarefas.php');
        exit;
    }

    if ($action === 'delete' && isAdmin($user)) {
        $stmt = $db->prepare('DELETE FROM tasks WHERE id = ?');
        $stmt->execute([(int) $_POST['id']]);
        flash('success', 'Tarefa excluída.');
    }

    header('Location: tarefas.php');
    exit;
}

$editId = (int) ($_GET['edit'] ?? 0);
$editTask = null;
if ($editId && isAdmin($user)) {
    $stmt = $db->prepare('SELECT * FROM tasks WHERE id = ?');
    $stmt->execute([$editId]);
    $editTask = $stmt->fetch() ?: null;
}

$sql = 'SELECT t.*, a.name AS assigned_name, c.name AS created_name FROM tasks t
        JOIN employees a ON a.id = t.assigned_to_id
        JOIN employees c ON c.id = t.created_by_id';
$params = [];

if (!isManager($user)) {
    $sql .= ' WHERE t.assigned_to_id = ?';
    $params[] = $user['id'];
}
$sql .= ' ORDER BY t.created_at DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$tasks = $stmt->fetchAll();

$employees = isManager($user) ? $db->query('SELECT id, name FROM employees WHERE status = "active" ORDER BY name')->fetchAll() : [];
$allEmployees = isAdmin($user) ? $employees : [];

renderHeader('Tarefas', 'tarefas.php', 'Gestão de atividades, entregas e aprovações da equipe.');
?>

<?php if ($editTask): ?>
<div class="card mb-4">
    <h3>Editar tarefa (admin)</h3>
    <form method="post" class="form">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="<?= (int) $editTask['id'] ?>">
        <label>Título<input name="title" value="<?= e($editTask['title']) ?>" required></label>
        <label>Descrição<textarea name="description" rows="2" required><?= e($editTask['description']) ?></textarea></label>
        <div class="form-row">
            <label>Responsável
                <select name="assigned_to_id" required>
                    <?php foreach ($allEmployees as $emp): ?>
                        <option value="<?= (int) $emp['id'] ?>" <?= (int) $editTask['assigned_to_id'] === (int) $emp['id'] ? 'selected' : '' ?>><?= e($emp['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Prioridade
                <select name="priority">
                    <?php foreach (['low', 'medium', 'high', 'urgent'] as $p): ?>
                        <option value="<?= $p ?>" <?= $editTask['priority'] === $p ? 'selected' : '' ?>><?= e(priorityLabel($p)) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Prazo<input type="date" name="due_date" value="<?= e($editTask['due_date'] ?? '') ?>"></label>
            <label>Status
                <select name="status">
                    <?php foreach (['pending', 'in_progress', 'completed', 'approved', 'rejected'] as $s): ?>
                        <option value="<?= $s ?>" <?= $editTask['status'] === $s ? 'selected' : '' ?>><?= e(statusLabel($s)) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>
        <div class="actions">
            <button type="submit" class="btn btn-primary">Salvar alterações</button>
            <a href="tarefas.php" class="btn btn-ghost btn-sm">Cancelar</a>
        </div>
    </form>
</div>
<?php endif; ?>

<?php if (isManager($user)): ?>
<div class="card mb-4">
    <h3>Nova tarefa</h3>
    <form method="post" class="form">
        <input type="hidden" name="action" value="create">
        <label>Título<input name="title" required></label>
        <label>Descrição<textarea name="description" rows="2" required></textarea></label>
        <div class="form-row">
            <label>Responsável
                <select name="assigned_to_id" required>
                    <?php foreach ($employees as $emp): ?>
                        <option value="<?= (int) $emp['id'] ?>"><?= e($emp['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Prioridade
                <select name="priority">
                    <option value="low">Baixa</option>
                    <option value="medium" selected>Média</option>
                    <option value="high">Alta</option>
                    <option value="urgent">Urgente</option>
                </select>
            </label>
            <label>Prazo<input type="date" name="due_date"></label>
        </div>
        <button type="submit" class="btn btn-primary">Criar tarefa</button>
    </form>
</div>
<?php endif; ?>

<div class="card">
    <h3>Lista de tarefas</h3>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Responsável</th>
                    <th>Prioridade</th>
                    <th>Prazo</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tasks as $task): ?>
                <tr>
                    <td>
                        <strong><?= e($task['title']) ?></strong>
                        <div class="muted small"><?= e($task['description']) ?></div>
                    </td>
                    <td><?= e($task['assigned_name']) ?></td>
                    <td><?= e(priorityLabel($task['priority'])) ?></td>
                    <td><?= formatDate($task['due_date']) ?></td>
                    <td><span class="badge badge-<?= e($task['status']) ?>"><?= e(statusLabel($task['status'])) ?></span></td>
                    <td class="actions">
                        <?php if ((int) $task['assigned_to_id'] === (int) $user['id'] && in_array($task['status'], ['pending', 'in_progress'], true)): ?>
                            <?php if ($task['status'] === 'pending'): ?>
                            <form method="post" class="inline-form">
                                <input type="hidden" name="action" value="status">
                                <input type="hidden" name="id" value="<?= (int) $task['id'] ?>">
                                <input type="hidden" name="status" value="in_progress">
                                <button class="btn btn-info btn-sm">Iniciar</button>
                            </form>
                            <?php endif; ?>
                            <form method="post" class="inline-form">
                                <input type="hidden" name="action" value="status">
                                <input type="hidden" name="id" value="<?= (int) $task['id'] ?>">
                                <input type="hidden" name="status" value="completed">
                                <button class="btn btn-success btn-sm">Concluir</button>
                            </form>
                        <?php endif; ?>

                        <?php if (isAdmin($user)): ?>
                            <a href="tarefas.php?edit=<?= (int) $task['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                            <form method="post" class="inline-form" onsubmit="return confirm('Excluir esta tarefa?');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= (int) $task['id'] ?>">
                                <button class="btn btn-danger btn-sm">Excluir</button>
                            </form>
                            <?php if ($task['status'] === 'completed'): ?>
                            <form method="post" class="inline-form">
                                <input type="hidden" name="action" value="approve">
                                <input type="hidden" name="id" value="<?= (int) $task['id'] ?>">
                                <input type="hidden" name="status" value="approved">
                                <button class="btn btn-success btn-sm">Aprovar</button>
                            </form>
                            <form method="post" class="inline-form">
                                <input type="hidden" name="action" value="approve">
                                <input type="hidden" name="id" value="<?= (int) $task['id'] ?>">
                                <input type="hidden" name="status" value="rejected">
                                <button class="btn btn-danger btn-sm">Rejeitar</button>
                            </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php renderFooter(); ?>

/* ============================================================
   APROVA+ | JavaScript Principal v2
   ============================================================ */

'use strict';

/* ── TEMA ── */
const Theme = {
  init() {
    const saved = localStorage.getItem('ap_theme') || 'light';
    this.set(saved);
  },
  toggle() {
    const cur = document.documentElement.getAttribute('data-theme') || 'light';
    this.set(cur === 'dark' ? 'light' : 'dark');
  },
  set(t) {
    document.documentElement.setAttribute('data-theme', t);
    localStorage.setItem('ap_theme', t);
    const btn = document.getElementById('themeBtn');
    if (btn) btn.textContent = t === 'dark' ? '☀️' : '🌙';
  }
};

/* ── SIDEBAR MOBILE ── */
const Sidebar = {
  init() {
    const toggle  = document.getElementById('menuToggle');
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if (!sidebar) return;

    toggle?.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      overlay?.classList.toggle('active');
    });

    overlay?.addEventListener('click', () => {
      sidebar.classList.remove('open');
      overlay.classList.remove('active');
    });
  }
};

/* ── MODAL ── */
const Modal = {
  open(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.add('active');
    document.body.style.overflow = 'hidden';
    el.querySelector('[autofocus]')?.focus();
  },
  close(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.remove('active');
    document.body.style.overflow = '';
  },
  closeAll() {
    document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
    document.body.style.overflow = '';
  },
  init() {
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', e => { if (e.target === overlay) this.closeAll(); });
    });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') this.closeAll(); });
    document.querySelectorAll('.modal-x, [data-close]').forEach(btn => {
      btn.addEventListener('click', () => this.closeAll());
    });
  }
};

/* ── TOAST ── */
const Toast = {
  show(msg, type = 'info', ms = 3800) {
    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
    let c = document.getElementById('toastContainer');
    if (!c) { c = document.createElement('div'); c.id = 'toastContainer'; document.body.appendChild(c); }

    const t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = `<span class="toast-icon">${icons[type]||'ℹ️'}</span><span>${msg}</span>`;
    c.appendChild(t);

    setTimeout(() => {
      t.classList.add('toast-out');
      setTimeout(() => t.remove(), 300);
    }, ms);
  }
};

/* ── CONTADOR ANIMADO ── */
function animCount(el, target, dur = 1100) {
  let start = null;
  const step = ts => {
    if (!start) start = ts;
    const prog = Math.min((ts - start) / dur, 1);
    const ease = 1 - Math.pow(1 - prog, 3);
    el.textContent = Math.floor(ease * target);
    if (prog < 1) requestAnimationFrame(step);
    else el.textContent = target;
  };
  requestAnimationFrame(step);
}

/* ── CONFIRM DELETE ── */
function confirmDel(msg = 'Deseja realmente excluir este item?') {
  return confirm(msg);
}

/* ── BUSCA EM TEMPO REAL ── */
function filterList(inputId, selector, attr = 'data-search') {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.addEventListener('input', () => {
    const q = input.value.toLowerCase().trim();
    document.querySelectorAll(selector).forEach(el => {
      const val = (el.getAttribute(attr) || el.textContent).toLowerCase();
      el.style.display = !q || val.includes(q) ? '' : 'none';
    });
  });
}

/* ── HIGHLIGHT MENU ATIVO ── */
function highlightNav() {
  const cur = window.location.pathname.split('/').pop();
  document.querySelectorAll('.nav-link').forEach(a => {
    const href = a.getAttribute('href') || '';
    const page = href.split('/').pop();
    if (page && cur === page) a.classList.add('active');
  });
}

/* ── INIT ── */
document.addEventListener('DOMContentLoaded', () => {
  Theme.init();
  Sidebar.init();
  Modal.init();
  highlightNav();

  /* Contador animado para stat-num */
  document.querySelectorAll('[data-count]').forEach(el => {
    const n = parseFloat(el.getAttribute('data-count'));
    if (!isNaN(n) && Number.isInteger(n)) animCount(el, n);
  });

  /* Auto-resize textarea */
  document.querySelectorAll('textarea').forEach(ta => {
    ta.addEventListener('input', () => {
      ta.style.height = 'auto';
      ta.style.height = ta.scrollHeight + 'px';
    });
  });
});

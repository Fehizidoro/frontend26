-- ============================================
-- Banco de Dados: aprovamais
-- Sistema: Aprova+ | Organizador de Vestibulandos
-- ============================================

CREATE DATABASE IF NOT EXISTS aprovamais
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE aprovamais;

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    meta_horas INT DEFAULT 20,
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de matérias
CREATE TABLE IF NOT EXISTS materias (
    id_materia INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cor VARCHAR(7) DEFAULT '#6c63ff',
    id_usuario INT NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de cronograma
CREATE TABLE IF NOT EXISTS cronograma (
    id_cronograma INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_materia INT,
    data DATE NOT NULL,
    horario TIME NOT NULL,
    duracao INT DEFAULT 60,
    conteudo VARCHAR(255) NOT NULL,
    status ENUM('pendente','concluido') DEFAULT 'pendente',
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE,
    FOREIGN KEY (id_materia) REFERENCES materias(id_materia) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de aulas
CREATE TABLE IF NOT EXISTS aulas (
    id_aula INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    titulo VARCHAR(150) NOT NULL,
    materia VARCHAR(100),
    professor VARCHAR(100),
    data DATE,
    link VARCHAR(500),
    anotacoes TEXT,
    status ENUM('pendente','assistida') DEFAULT 'pendente',
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de redações
CREATE TABLE IF NOT EXISTS redacoes (
    id_redacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tema VARCHAR(255) NOT NULL,
    texto TEXT,
    competencia1 INT DEFAULT 0,
    competencia2 INT DEFAULT 0,
    competencia3 INT DEFAULT 0,
    competencia4 INT DEFAULT 0,
    competencia5 INT DEFAULT 0,
    nota_final INT GENERATED ALWAYS AS (competencia1 + competencia2 + competencia3 + competencia4 + competencia5) STORED,
    data DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de tarefas
CREATE TABLE IF NOT EXISTS tarefas (
    id_tarefa INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    descricao VARCHAR(255) NOT NULL,
    prioridade ENUM('baixa','media','alta') DEFAULT 'media',
    prazo DATE,
    status ENUM('pendente','concluida') DEFAULT 'pendente',
    data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de materiais
CREATE TABLE IF NOT EXISTS materiais (
    id_material INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    tipo ENUM('resumo','link','pdf','anotacao','outro') DEFAULT 'anotacao',
    conteudo TEXT,
    link VARCHAR(500),
    data DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

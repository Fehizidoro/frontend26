<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'aprovamais');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die('<div style="font-family:sans-serif;padding:20px;background:#fee;border:1px solid red;margin:20px;border-radius:8px;">
        <strong>Erro de conexão:</strong> ' . htmlspecialchars($conn->connect_error) . '<br>
        Verifique as configurações em config/conexao.php
    </div>');
}

$conn->set_charset('utf8mb4');

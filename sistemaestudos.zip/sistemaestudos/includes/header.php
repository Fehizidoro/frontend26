<?php
if (session_status() === PHP_SESSION_NONE) session_start();

$pub = ['login.php','cadastro.php'];
if (!isset($_SESSION['id_usuario']) && !in_array(basename($_SERVER['PHP_SELF']), $pub)) {
    header('Location: ../pages/login.php'); exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR" data-theme="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle).' | Aprova+' : 'Aprova+ | Organizador de Vestibulandos' ?></title>
  <link rel="icon" href="../assets/img/favicon.svg" type="image/svg+xml">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div id="toastContainer"></div>
<div id="sidebarOverlay"></div>

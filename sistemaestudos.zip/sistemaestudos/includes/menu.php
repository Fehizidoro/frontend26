<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$nome    = $_SESSION['nome'] ?? 'Estudante';
$inicial = strtoupper(mb_substr($nome, 0, 1));
$cur     = basename($_SERVER['PHP_SELF']);

function navCls($p, $c) { return $p === $c ? ' active' : ''; }

/* Badge de tarefas pendentes */
$badge = '';
if (isset($conn)) {
    $uid = (int)($_SESSION['id_usuario'] ?? 0);
    $rr  = $conn->query("SELECT COUNT(*) c FROM tarefas WHERE id_usuario=$uid AND status='pendente'");
    $cnt = $rr ? $rr->fetch_assoc()['c'] : 0;
    if ($cnt > 0) $badge = '<span class="nav-badge">'.$cnt.'</span>';
}
?>
<aside class="sidebar" id="sidebar">

  <!-- Logo -->
  <div class="sidebar-logo">
    <a href="dashboard.php" class="logo-brand">
      <div class="logo-icon">🎯</div>
      <div>
        <div class="logo-name">Aprova+</div>
        <div class="logo-tag">Organizador de Vestibulandos</div>
      </div>
    </a>
  </div>

  <!-- Nav -->
  <nav class="sidebar-nav">
    <div class="nav-section">Principal</div>

    <a href="dashboard.php" class="nav-link<?= navCls('dashboard.php',$cur) ?>">
      <span class="nav-icon">🏠</span>
      <span>Dashboard</span>
    </a>

    <div class="nav-section">Estudos</div>

    <a href="cronograma.php" class="nav-link<?= navCls('cronograma.php',$cur) ?>">
      <span class="nav-icon">📅</span>
      <span>Cronograma</span>
    </a>

    <a href="aulas.php" class="nav-link<?= navCls('aulas.php',$cur) ?>">
      <span class="nav-icon">🎬</span>
      <span>Aulas</span>
    </a>

    <a href="redacoes.php" class="nav-link<?= navCls('redacoes.php',$cur) ?>">
      <span class="nav-icon">✍️</span>
      <span>Redações</span>
    </a>

    <a href="materiais.php" class="nav-link<?= navCls('materiais.php',$cur) ?>">
      <span class="nav-icon">📚</span>
      <span>Materiais</span>
    </a>

    <div class="nav-section">Organização</div>

    <a href="tarefas.php" class="nav-link<?= navCls('tarefas.php',$cur) ?>">
      <span class="nav-icon">✅</span>
      <span>Tarefas</span>
      <?= $badge ?>
    </a>

    <a href="relatorios.php" class="nav-link<?= navCls('relatorios.php',$cur) ?>">
      <span class="nav-icon">📊</span>
      <span>Relatórios</span>
    </a>
  </nav>

  <!-- Footer -->
  <div class="sidebar-footer">
    <div class="user-card">
      <div class="user-avatar"><?= htmlspecialchars($inicial) ?></div>
      <div style="overflow:hidden;">
        <div class="user-info-name"><?= htmlspecialchars(explode(' ',$nome)[0]) ?></div>
        <div class="user-info-role">Vestibulando 🎓</div>
      </div>
    </div>
    <a href="logout.php" class="logout-btn">
      <span>🚪</span> Sair da conta
    </a>
  </div>

</aside>

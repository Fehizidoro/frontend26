<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Instalar Aprova+</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body {
  font-family:'Segoe UI',sans-serif;
  background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);
  min-height:100vh;
  display:flex;
  align-items:center;
  justify-content:center;
  padding:20px;
}
.box {
  background:#fff;
  border-radius:24px;
  padding:44px;
  max-width:680px;
  width:100%;
  box-shadow:0 40px 80px rgba(0,0,0,0.5);
}
h1 { font-size:28px; color:#1e1b4b; margin-bottom:4px; font-weight:800; }
.sub { color:#64748b; font-size:14px; margin-bottom:28px; }
.step {
  background:#f8fafc;
  border-radius:12px;
  padding:14px 18px;
  margin-bottom:10px;
  border-left:4px solid #7c3aed;
  font-size:13.5px;
  line-height:1.6;
}
.step.ok   { border-color:#10b981; background:#f0fdf4; }
.step.erro { border-color:#ef4444; background:#fff5f5; color:#dc2626; }
.step strong { display:block; margin-bottom:3px; font-size:14px; }
.btn {
  display:block; width:100%; padding:15px;
  background:linear-gradient(135deg,#7c3aed,#06b6d4);
  color:#fff; border:none; border-radius:12px;
  font-size:16px; font-weight:800; cursor:pointer;
  text-align:center; text-decoration:none; margin-top:22px;
  box-shadow:0 8px 24px rgba(124,58,237,0.35);
  transition:all .2s;
}
.btn:hover { transform:translateY(-2px); filter:brightness(1.08); }
code { background:#f1f5f9; padding:2px 7px; border-radius:5px; font-family:monospace; font-size:12px; }
.section-title {
  font-size:13px; font-weight:700; color:#7c3aed;
  text-transform:uppercase; letter-spacing:1px;
  margin:22px 0 10px;
}
.badge-count {
  display:inline-block; background:#7c3aed; color:#fff;
  border-radius:99px; padding:1px 8px; font-size:12px;
  font-weight:700; margin-left:6px;
}
</style>
</head>
<body>
<div class="box">
  <h1>🎯 Aprova+ — Instalação</h1>
  <p class="sub">Configurando banco de dados, tabelas e conteúdo de exemplo...</p>

<?php
$erros = 0;

try {
    /* ── Conexão ── */
    $db = new mysqli('localhost','root','','');
    if ($db->connect_error) throw new Exception($db->connect_error);
    echo '<div class="step ok"><strong>✅ MySQL conectado</strong>Servidor MySQL respondendo corretamente.</div>';

    /* ── Banco ── */
    $db->query("CREATE DATABASE IF NOT EXISTS aprovamais CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $db->select_db('aprovamais');
    $db->set_charset('utf8mb4');
    echo '<div class="step ok"><strong>✅ Banco de dados</strong>Banco <code>aprovamais</code> pronto.</div>';

    /* ── Tabelas ── */
    echo '<div class="section-title">📋 Criando tabelas</div>';

    $tabelas = [
      'usuarios' => "CREATE TABLE IF NOT EXISTS usuarios (
        id_usuario INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL UNIQUE,
        senha VARCHAR(255) NOT NULL,
        meta_horas INT DEFAULT 20,
        data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

      'materias' => "CREATE TABLE IF NOT EXISTS materias (
        id_materia INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        cor VARCHAR(7) DEFAULT '#7c3aed',
        id_usuario INT NOT NULL,
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

      'cronograma' => "CREATE TABLE IF NOT EXISTS cronograma (
        id_cronograma INT AUTO_INCREMENT PRIMARY KEY,
        id_usuario INT NOT NULL,
        id_materia INT,
        data DATE NOT NULL,
        horario TIME NOT NULL,
        duracao INT DEFAULT 60,
        conteudo VARCHAR(255) NOT NULL,
        status ENUM('pendente','concluido') DEFAULT 'pendente',
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE,
        FOREIGN KEY (id_materia) REFERENCES materias(id_materia) ON DELETE SET NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

      'aulas' => "CREATE TABLE IF NOT EXISTS aulas (
        id_aula INT AUTO_INCREMENT PRIMARY KEY,
        id_usuario INT NOT NULL,
        titulo VARCHAR(150) NOT NULL,
        materia VARCHAR(100),
        professor VARCHAR(100),
        data DATE,
        link VARCHAR(500),
        anotacoes TEXT,
        status ENUM('pendente','assistida') DEFAULT 'pendente',
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

      'redacoes' => "CREATE TABLE IF NOT EXISTS redacoes (
        id_redacao INT AUTO_INCREMENT PRIMARY KEY,
        id_usuario INT NOT NULL,
        tema VARCHAR(255) NOT NULL,
        texto TEXT,
        competencia1 INT DEFAULT 0,
        competencia2 INT DEFAULT 0,
        competencia3 INT DEFAULT 0,
        competencia4 INT DEFAULT 0,
        competencia5 INT DEFAULT 0,
        nota_final INT GENERATED ALWAYS AS (competencia1+competencia2+competencia3+competencia4+competencia5) STORED,
        data DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

      'tarefas' => "CREATE TABLE IF NOT EXISTS tarefas (
        id_tarefa INT AUTO_INCREMENT PRIMARY KEY,
        id_usuario INT NOT NULL,
        descricao VARCHAR(255) NOT NULL,
        prioridade ENUM('baixa','media','alta') DEFAULT 'media',
        prazo DATE,
        status ENUM('pendente','concluida') DEFAULT 'pendente',
        data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

      'materiais' => "CREATE TABLE IF NOT EXISTS materiais (
        id_material INT AUTO_INCREMENT PRIMARY KEY,
        id_usuario INT NOT NULL,
        titulo VARCHAR(200) NOT NULL,
        tipo ENUM('resumo','link','pdf','anotacao','outro') DEFAULT 'anotacao',
        conteudo TEXT,
        link VARCHAR(500),
        data DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    ];

    foreach ($tabelas as $nome => $sql) {
        if ($db->query($sql))
            echo "<div class='step ok'><strong>✅ Tabela <code>$nome</code></strong>Criada/verificada com sucesso.</div>";
        else {
            echo "<div class='step erro'><strong>❌ Tabela $nome</strong>".$db->error."</div>";
            $erros++;
        }
    }

    /* ── Migração: adicionar coluna anotacoes se não existir ── */
    $db->query("ALTER TABLE aulas ADD COLUMN IF NOT EXISTS anotacoes TEXT");


    /* ══════════════════════════════════════════════
       USUÁRIO DE DEMONSTRAÇÃO
       Login: demo@aprovamais.com / Senha: demo123
    ══════════════════════════════════════════════ */
    echo '<div class="section-title">👤 Usuário de demonstração</div>';

    $demoEmail = 'demo@aprovamais.com';
    $demoSenha = password_hash('demo123', PASSWORD_DEFAULT);
    $demoNome  = 'Estudante Demo';

    $ck = $db->prepare("SELECT id_usuario FROM usuarios WHERE email=?");
    $ck->bind_param('s', $demoEmail);
    $ck->execute();
    $ck->store_result();

    if ($ck->num_rows > 0) {
        $ck->bind_result($uid);
        $ck->fetch();
        echo "<div class='step ok'><strong>✅ Usuário demo já existe</strong>Email: <code>$demoEmail</code> | Senha: <code>demo123</code></div>";
    } else {
        $ins = $db->prepare("INSERT INTO usuarios (nome,email,senha,meta_horas) VALUES (?,?,?,25)");
        $ins->bind_param('sss', $demoNome, $demoEmail, $demoSenha);
        $ins->execute();
        $uid = $db->insert_id;
        echo "<div class='step ok'><strong>✅ Usuário demo criado</strong>Email: <code>$demoEmail</code> | Senha: <code>demo123</code></div>";
    }

    /* ══════════════════════════════════════════════
       MATÉRIAS
    ══════════════════════════════════════════════ */
    echo '<div class="section-title">📚 Matérias</div>';
    $chkMat = $db->query("SELECT COUNT(*) c FROM materias WHERE id_usuario=$uid")->fetch_assoc()['c'];
    if ($chkMat == 0) {
        $mats = [
            ['Matemática','#7c3aed'],['Português','#ec4899'],['Redação','#06b6d4'],
            ['Biologia','#10b981'],['Química','#f59e0b'],['Física','#3b82f6'],
            ['História','#8b5cf6'],['Geografia','#14b8a6'],['Inglês','#f97316'],['Literatura','#e11d48']
        ];
        $sm = $db->prepare("INSERT INTO materias (nome,cor,id_usuario) VALUES (?,?,?)");
        foreach ($mats as [$mn,$mc]) { $sm->bind_param('ssi',$mn,$mc,$uid); $sm->execute(); }
        echo "<div class='step ok'><strong>✅ Matérias inseridas</strong>".count($mats)." matérias adicionadas.</div>";
    } else {
        echo "<div class='step ok'><strong>✅ Matérias já existem</strong>$chkMat matérias encontradas.</div>";
    }


    /* ══════════════════════════════════════════════
       AULAS DE EXEMPLO — YouTube (canais reais)
    ══════════════════════════════════════════════ */
    echo '<div class="section-title">🎬 Aulas em vídeo</div>';
    $chkAulas = $db->query("SELECT COUNT(*) c FROM aulas WHERE id_usuario=$uid")->fetch_assoc()['c'];
    if ($chkAulas == 0) {

        $hoje = date('Y-m-d');
        $aulas = [
            /* MATEMÁTICA */
            ['Funções do 1º Grau — Teoria Completa','Matemática','Prof. Ferreto','https://www.youtube.com/watch?v=GKyZf2aAzLM','pendente',
             "Função afim f(x)=ax+b.\nA=coef. angular (inclinação)\nB=coef. linear (onde cruza eixo y)\nGráfico: reta"],
            ['Equação do 2º Grau — Bhaskara e Fatoração','Matemática','Ferretto Matemática','https://www.youtube.com/watch?v=z3ywOHtpS8k','pendente',
             "Fórmula de Bhaskara: x=(-b±√Δ)/2a\nΔ=b²-4ac\nΔ>0: 2 raízes reais\nΔ=0: 1 raiz real\nΔ<0: sem raízes reais"],
            ['Trigonometria no Triângulo Retângulo','Matemática','Prof. Ferreto','https://www.youtube.com/watch?v=LD7rZZpnLiw','pendente',
             "Seno = CO/H\nCosseno = CA/H\nTangente = CO/CA\nMnemônico: SOH-CAH-TOA"],
            ['Progressão Aritmética (PA) — ENEM','Matemática','Matemática Rio','https://www.youtube.com/watch?v=sX2TXZgMJnQ','pendente',''],
            ['Geometria Plana — Área e Perímetro','Matemática','Toda Matemática','https://www.youtube.com/watch?v=B6z9NjXU7mQ','pendente',''],

            /* PORTUGUÊS / REDAÇÃO */
            ['Como fazer uma Redação Nota 1000 no ENEM','Redação','Descomplica','https://www.youtube.com/watch?v=KD9NfGGRFco','pendente',
             "Estrutura dissertativa-argumentativa:\n1. Introdução (apresentar tema + tese)\n2. Desenvolvimento P1 (argumento + exemplos)\n3. Desenvolvimento P2 (argumento + exemplos)\n4. Conclusão (proposta de intervenção detalhada)"],
            ['Proposta de Intervenção Perfeita — Redação ENEM','Redação','Redação Nota 1000','https://www.youtube.com/watch?v=Y7gfuKmwCMU','pendente',
             "Proposta deve ter 5 elementos:\n1. Agente (quem vai agir?)\n2. Ação (o que será feito?)\n3. Meio/Modo (como será feito?)\n4. Efeito/Finalidade (para quê?)\n5. Detalhamento (exemplificar)"],
            ['Coesão e Coerência Textual — Conectivos','Português','Prof. Noslen','https://www.youtube.com/watch?v=lEMONh0wQCU','pendente',
             "Adição: e, também, além disso\nContraste: mas, porém, contudo, entretanto\nCausa: porque, pois, já que\nConsequência: logo, portanto, assim\nConcessão: embora, ainda que, mesmo que"],
            ['Análise Sintática Completa — Sujeito e Predicado','Português','Prof. Noslen','https://www.youtube.com/watch?v=A_qOjaTzabs','pendente',''],

            /* HISTÓRIA */
            ['Revolução Industrial — ENEM e Vestibulares','História','Parabólica','https://www.youtube.com/watch?v=HcNP0X7KWng','pendente',
             "1ª Rev. Industrial: Inglaterra, séc. XVIII\nMáquina a vapor, indústria têxtil\n2ª Rev. Industrial: aço, eletricidade, petróleo\nProblemas: exploração do trabalho, urbanização"],
            ['Segunda Guerra Mundial — Resumo Completo','História','Parabólica','https://www.youtube.com/watch?v=J4s3MrAVGgM','pendente',''],
            ['Ditadura Militar no Brasil (1964-1985)','História','Me Salva!','https://www.youtube.com/watch?v=hTSv7kFE7OQ','pendente',''],

            /* BIOLOGIA */
            ['Genética — Leis de Mendel para o ENEM','Biologia','Descomplica','https://www.youtube.com/watch?v=X_y8GBr8QeU','pendente',
             "1ª Lei de Mendel: Segregação dos fatores\nDominância e Recessividade\nGenótipo vs Fenótipo\nCruzamento monoíbrido — quadro de Punnett"],
            ['Divisão Celular — Mitose e Meiose','Biologia','Prof. Guilherme Goulart','https://www.youtube.com/watch?v=yBEFNBs_8cE','pendente',
             "Mitose: 2 células iguais (crescimento)\nMeiose: 4 células haploides (reprodução)\nFases: Prófase, Metáfase, Anáfase, Telófase"],
            ['Ecologia — Cadeias e Teias Alimentares','Biologia','Biologia com Samuel Cunha','https://www.youtube.com/watch?v=4rNnmZl6dRE','pendente',''],

            /* QUÍMICA */
            ['Tabela Periódica — Tudo que você precisa saber','Química','Química com o Dede','https://www.youtube.com/watch?v=VrWlVgDtD5E','pendente',
             "Grupos/Famílias (vertical) = mesmas propriedades\nPeríodos (horizontal) = mesma qtd de camadas\nMetais, Não-metais, Semimetais, Gases nobres"],
            ['Ligações Químicas — Iônica, Covalente e Metálica','Química','Prof. Guilherme Goulart','https://www.youtube.com/watch?v=Z6pFp5zDI4k','pendente',''],

            /* FÍSICA */
            ['Cinemática — MRU e MRUV no ENEM','Física','Física com Douglas','https://www.youtube.com/watch?v=Q7L22zMIyDs','pendente',
             "MRU: v=constante, s=s0+v.t\nMRUV: v=v0+a.t, s=s0+v0.t+at²/2\nv²=v0²+2a.Δs\nGráficos: posição x tempo, velocidade x tempo"],
            ['Leis de Newton — Teoria e Exercícios','Física','Física com Douglas','https://www.youtube.com/watch?v=bqZPCE4VJXI','pendente',
             "1ª Lei: Inércia\n2ª Lei: F=m.a\n3ª Lei: Ação e Reação\nPeso = m.g (g≈10 m/s²)"],

            /* GEOGRAFIA */
            ['Globalização e Geopolítica — ENEM','Geografia','Geobrasil','https://www.youtube.com/watch?v=_GwHjQNFEes','pendente',''],
            ['Clima e Vegetação do Brasil','Geografia','Me Salva!','https://www.youtube.com/watch?v=jKP8JdaJJig','pendente',''],
        ];

        $sa = $db->prepare("INSERT INTO aulas (id_usuario,titulo,materia,professor,data,link,anotacoes,status) VALUES (?,?,?,?,?,?,?,?)");
        $inseridas = 0;
        foreach ($aulas as [$titulo,$materia,$prof,$link,$status,$ann]) {
            $sa->bind_param('isssssss', $uid, $titulo, $materia, $prof, $hoje, $link, $ann, $status);
            if ($sa->execute()) $inseridas++;
        }
        echo "<div class='step ok'><strong>✅ Aulas inseridas <span class='badge-count'>$inseridas aulas</span></strong>Matemática, Redação, História, Biologia, Química, Física e Geografia.</div>";
    } else {
        echo "<div class='step ok'><strong>✅ Aulas já existem</strong>$chkAulas aulas encontradas no banco.</div>";
    }


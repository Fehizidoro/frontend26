<?php
$pageTitle='Aulas';
require_once '../config/conexao.php';
require_once '../includes/header.php';
$uid=(int)$_SESSION['id_usuario'];
$msg='';

/* ── CRUD ── */
if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    if($action==='add'){
        $t=$conn->real_escape_string($_POST['titulo']);
        $m=$conn->real_escape_string($_POST['materia']);
        $p=$conn->real_escape_string($_POST['professor']);
        $d=$_POST['data']?"'".$conn->real_escape_string($_POST['data'])."'":'NULL';
        $l=$conn->real_escape_string($_POST['link']);
        $ann=$conn->real_escape_string($_POST['anotacoes']??'');
        $conn->query("INSERT INTO aulas (id_usuario,titulo,materia,professor,data,link,anotacoes) VALUES ($uid,'$t','$m','$p',$d,'$l','$ann')");
        $msg='success|Aula adicionada!';
    }
    if($action==='edit'){
        $id=(int)$_POST['id'];
        $t=$conn->real_escape_string($_POST['titulo']);
        $m=$conn->real_escape_string($_POST['materia']);
        $p=$conn->real_escape_string($_POST['professor']);
        $d=$_POST['data']?"'".$conn->real_escape_string($_POST['data'])."'":'NULL';
        $l=$conn->real_escape_string($_POST['link']);
        $ann=$conn->real_escape_string($_POST['anotacoes']??'');
        $conn->query("UPDATE aulas SET titulo='$t',materia='$m',professor='$p',data=$d,link='$l',anotacoes='$ann' WHERE id_aula=$id AND id_usuario=$uid");
        $msg='success|Aula atualizada!';
    }
    if($action==='delete'){
        $conn->query("DELETE FROM aulas WHERE id_aula=".(int)$_POST['id']." AND id_usuario=$uid");
        $msg='success|Aula excluída.'; header('Location: aulas.php'); exit;
    }
    if($action==='toggle'){
        $conn->query("UPDATE aulas SET status=IF(status='pendente','assistida','pendente') WHERE id_aula=".(int)$_POST['id']." AND id_usuario=$uid");
        header('Location: aulas.php?f='.($_GET['f']??'todas').'&ver='.($_GET['ver']??'')); exit;
    }
}

/* ── Adicionar coluna anotacoes se não existir ── */
$conn->query("ALTER TABLE aulas ADD COLUMN IF NOT EXISTS anotacoes TEXT");

/* ── Filtro e listagem ── */
$f=$_GET['f']??'todas';
$where="WHERE id_usuario=$uid";
if($f==='pendente')  $where.=" AND status='pendente'";
if($f==='assistida') $where.=" AND status='assistida'";

$rows=$conn->query("SELECT * FROM aulas $where ORDER BY status ASC, data ASC, id_aula DESC");
$list=[]; while($r=$rows->fetch_assoc()) $list[]=$r;

$tP=(int)$conn->query("SELECT COUNT(*) c FROM aulas WHERE id_usuario=$uid AND status='pendente'")->fetch_assoc()['c'];
$tA=(int)$conn->query("SELECT COUNT(*) c FROM aulas WHERE id_usuario=$uid AND status='assistida'")->fetch_assoc()['c'];
$tot=$tP+$tA;

/* ── Aula selecionada para player ── */
$verId=(int)($_GET['ver']??0);
$aulaVer=null;
if($verId>0){
    $rv=$conn->query("SELECT * FROM aulas WHERE id_aula=$verId AND id_usuario=$uid");
    if($rv&&$rv->num_rows>0) $aulaVer=$rv->fetch_assoc();
}
/* Primeira pendente como padrão */
if(!$aulaVer && count($list)>0) $aulaVer=$list[0];

/* ── Helpers PHP ── */
function getEmbedUrl(string $link): string {
    if(empty($link)) return '';
    /* YouTube */
    if(preg_match('/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_\-]{11})/', $link, $m))
        return 'https://www.youtube.com/embed/'.$m[1].'?rel=0&modestbranding=1&autoplay=1';
    /* Vimeo */
    if(preg_match('/vimeo\.com\/(?:video\/)?(\d+)/', $link, $m))
        return 'https://player.vimeo.com/video/'.$m[1].'?autoplay=1&color=7c3aed';
    /* Google Drive */
    if(preg_match('/drive\.google\.com\/file\/d\/([^\/]+)/', $link, $m))
        return 'https://drive.google.com/file/d/'.$m[1].'/preview';
    return '';
}

function getThumb(string $link): string {
    if(empty($link)) return '';
    if(preg_match('/(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([A-Za-z0-9_\-]{11})/', $link, $m))
        return 'https://img.youtube.com/vi/'.$m[1].'/mqdefault.jpg';
    if(preg_match('/vimeo\.com\/(?:video\/)?(\d+)/', $link, $m))
        return 'https://vumbnail.com/'.$m[1].'.jpg';
    return '';
}

function getVideoType(string $link): string {
    if(preg_match('/youtube\.com|youtu\.be/', $link)) return 'youtube';
    if(preg_match('/vimeo\.com/', $link))             return 'vimeo';
    if(preg_match('/drive\.google\.com/', $link))     return 'gdrive';
    if(preg_match('/\.(mp4|webm|ogg)$/i', $link))     return 'direct';
    return 'link';
}

$embedUrl = $aulaVer ? getEmbedUrl($aulaVer['link']??'') : '';
$videoType = $aulaVer ? getVideoType($aulaVer['link']??'') : '';

/* Próxima aula */
$proxima = null;
foreach($list as $i=>$a){
    if($aulaVer && $a['id_aula']==$aulaVer['id_aula'] && isset($list[$i+1])){
        $proxima=$list[$i+1]; break;
    }
}
?>

<div class="app-wrapper">
<?php include '../includes/menu.php'; ?>
<div class="main-content">

<!-- Topbar -->
<div class="topbar">
  <button class="menu-toggle" id="menuToggle">☰</button>
  <div class="topbar-left">
    <div class="topbar-page">🎬 Aulas em Vídeo</div>
    <div class="topbar-hint">Assista, anote e acompanhe seu progresso</div>
  </div>
  <div class="topbar-right">
    <button class="btn btn-primary" onclick="Modal.open('mAdd')">+ Nova aula</button>
    <button class="icon-btn" id="themeBtn" onclick="Theme.toggle()">🌙</button>
  </div>
</div>

<div class="page-content">

<?php if($msg):[$t2,$tx]=explode('|',$msg,2);?>
<script>document.addEventListener('DOMContentLoaded',()=>Toast.show('<?=addslashes($tx)?>','<?=$t2?>'));</script>
<?php endif;?>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:24px;">
  <div class="stat-card anim-up">
    <div class="stat-icon-wrap si-purple">🎬</div>
    <div class="stat-num" data-count="<?=$tot?>"><?=$tot?></div>
    <div class="stat-lbl">Total de aulas</div>
  </div>
  <div class="stat-card anim-up">
    <div class="stat-icon-wrap si-orange">⏳</div>
    <div class="stat-num" data-count="<?=$tP?>"><?=$tP?></div>
    <div class="stat-lbl">Pendentes</div>
  </div>
  <div class="stat-card anim-up">
    <div class="stat-icon-wrap si-green">✅</div>
    <div class="stat-num" data-count="<?=$tA?>"><?=$tA?></div>
    <div class="stat-lbl">Assistidas</div>
  </div>
  <div class="stat-card anim-up">
    <div class="stat-icon-wrap si-cyan">📊</div>
    <div class="stat-num"><?=$tot>0?round($tA/$tot*100):0?>%</div>
    <div class="stat-lbl">Progresso</div>
    <?php if($tot>0):?>
    <div style="margin-top:10px;"><div class="progress progress-sm"><div class="progress-fill" style="width:<?=round($tA/$tot*100)?>%"></div></div></div>
    <?php endif;?>
  </div>
</div>

<?php if(!$tot):?>
<!-- Empty state -->
<div class="card anim-up" style="text-align:center;padding:60px 20px;">
  <div style="font-size:80px;margin-bottom:20px;">🎬</div>
  <h2 style="font-size:22px;font-weight:800;color:var(--tx1);margin-bottom:8px;">Nenhuma aula cadastrada</h2>
  <p style="color:var(--tx3);margin-bottom:24px;">Adicione aulas do YouTube, Vimeo ou qualquer link de vídeo.</p>
  <button class="btn btn-primary" onclick="Modal.open('mAdd')">+ Adicionar primeira aula</button>
</div>
<?php else:?>

<!-- Layout principal: Player + Lista -->
<div class="aulas-layout">

  <!-- ── PLAYER PRINCIPAL ── -->
  <div class="player-section">

    <?php if($aulaVer && $aulaVer['link']):?>

    <!-- Video embed -->
    <div class="video-container" id="videoContainer">
      <?php if($videoType==='direct'):?>
        <video controls autoplay style="width:100%;height:100%;border-radius:16px 16px 0 0;background:#000;">
          <source src="<?=htmlspecialchars($aulaVer['link'])?>" type="video/mp4">
          Seu navegador não suporta vídeo HTML5.
        </video>
      <?php elseif($embedUrl):?>
        <iframe
          id="videoFrame"
          src="<?=htmlspecialchars($embedUrl)?>"
          title="<?=htmlspecialchars($aulaVer['titulo'])?>"
          frameborder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowfullscreen
          loading="lazy">
        </iframe>
      <?php else:?>
        <!-- Link genérico — não embeddável -->
        <div class="video-placeholder">
          <div class="vp-icon">🔗</div>
          <div class="vp-title">Link externo</div>
          <div class="vp-sub">Este link não pode ser reproduzido diretamente.<br>Use o botão abaixo para abrir.</div>
          <a href="<?=htmlspecialchars($aulaVer['link'])?>" target="_blank" rel="noopener" class="btn btn-primary" style="margin-top:20px;">
            ▶️ Abrir aula externamente
          </a>
        </div>
      <?php endif;?>
    </div>

    <?php elseif($aulaVer):?>
    <!-- Sem link -->
    <div class="video-container">
      <div class="video-placeholder">
        <div class="vp-icon">📚</div>
        <div class="vp-title"><?=htmlspecialchars($aulaVer['titulo'])?></div>
        <div class="vp-sub">Esta aula não possui link de vídeo cadastrado.</div>
        <button class="btn btn-primary" style="margin-top:20px;" onclick="openEditA(<?=htmlspecialchars(json_encode($aulaVer))?>)">✏️ Adicionar link de vídeo</button>
      </div>
    </div>
    <?php endif;?>

    <!-- Informações da aula -->
    <?php if($aulaVer):?>
    <div class="player-info">
      <div class="player-info-header">
        <div style="flex:1;min-width:0;">
          <div class="player-title"><?=htmlspecialchars($aulaVer['titulo'])?></div>
          <div class="player-meta">
            <?php if($aulaVer['materia']):?>
              <span class="player-tag">📚 <?=htmlspecialchars($aulaVer['materia'])?></span>
            <?php endif;?>
            <?php if($aulaVer['professor']):?>
              <span class="player-tag">👨‍🏫 <?=htmlspecialchars($aulaVer['professor'])?></span>
            <?php endif;?>
            <?php if($aulaVer['data']):?>
              <span class="player-tag">📅 <?=date('d/m/Y',strtotime($aulaVer['data']))?></span>
            <?php endif;?>
            <span class="player-tag <?=$aulaVer['status']==='assistida'?'tag-green':'tag-orange'?>">
              <?=$aulaVer['status']==='assistida'?'✅ Assistida':'⏳ Pendente'?>
            </span>
          </div>
        </div>
        <div class="player-actions">
          <?php if($aulaVer['link']):?>
            <a href="<?=htmlspecialchars($aulaVer['link'])?>" target="_blank" rel="noopener" class="btn btn-ghost btn-sm">🔗 Abrir original</a>
          <?php endif;?>
          <form method="POST" style="display:inline;">
            <input type="hidden" name="action" value="toggle">
            <input type="hidden" name="id" value="<?=$aulaVer['id_aula']?>">
            <input type="hidden" name="f" value="<?=$f?>">
            <button type="submit" class="btn btn-sm <?=$aulaVer['status']==='assistida'?'btn-warning':'btn-success'?>">
              <?=$aulaVer['status']==='assistida'?'↩️ Desfazer':'✅ Marcar assistida'?>
            </button>
          </form>
          <button class="btn btn-ghost btn-sm" onclick="openEditA(<?=htmlspecialchars(json_encode($aulaVer))?>)">✏️</button>
          <form method="POST" style="display:inline;" onsubmit="return confirmDel('Excluir esta aula?')">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?=$aulaVer['id_aula']?>">
            <button type="submit" class="btn btn-danger btn-sm">🗑️</button>
          </form>
        </div>
      </div>

      <!-- Próxima aula -->
      <?php if($proxima):?>
      <div class="next-aula-bar">
        <div class="next-label">▶ A seguir</div>
        <a href="?ver=<?=$proxima['id_aula']?>&f=<?=$f?>" class="next-link">
          <?php $thumb=getThumb($proxima['link']??''); ?>
          <?php if($thumb):?>
            <img src="<?=htmlspecialchars($thumb)?>" alt="" class="next-thumb" onerror="this.style.display='none'">
          <?php else:?>
            <div class="next-thumb next-thumb-empty">🎬</div>
          <?php endif;?>
          <div>
            <div class="next-title"><?=htmlspecialchars($proxima['titulo'])?></div>
            <?php if($proxima['materia']):?>
              <div class="next-sub"><?=htmlspecialchars($proxima['materia'])?></div>
            <?php endif;?>
          </div>
          <span style="margin-left:auto;font-size:18px;color:var(--p1)">→</span>
        </a>
      </div>
      <?php endif;?>

      <!-- Anotações da aula -->
      <div class="notes-section">
        <div class="notes-header">
          <span>📝 Anotações da aula</span>
          <button class="btn btn-ghost btn-sm" id="btnSaveNote" onclick="saveNote(<?=$aulaVer['id_aula']?>)">💾 Salvar</button>
        </div>
        <textarea id="noteArea" class="form-control" rows="5"
          placeholder="Anote pontos importantes, dúvidas, fórmulas..."
          style="resize:vertical;"><?=htmlspecialchars($aulaVer['anotacoes']??'')?></textarea>
      </div>
    </div>
    <?php endif;?>

  </div><!-- /.player-section -->

  <!-- ── PLAYLIST ── -->
  <div class="playlist-section">
    <div class="playlist-header">
      <div class="playlist-title">📋 Playlist (<?=$tot?>)</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <a href="?f=todas&ver=<?=$aulaVer?$aulaVer['id_aula']:''?>" class="btn btn-xs <?=$f==='todas'?'btn-primary':'btn-ghost'?>">Todas</a>
        <a href="?f=pendente&ver=<?=$aulaVer?$aulaVer['id_aula']:''?>" class="btn btn-xs <?=$f==='pendente'?'btn-primary':'btn-ghost'?>">Pendentes</a>
        <a href="?f=assistida&ver=<?=$aulaVer?$aulaVer['id_aula']:''?>" class="btn btn-xs <?=$f==='assistida'?'btn-primary':'btn-ghost'?>">Assistidas</a>
      </div>
      <input type="text" id="searchA" placeholder="🔍 Buscar..." class="form-control" style="margin-top:10px;">
    </div>

    <div class="playlist-list" id="playlistList">
      <?php foreach($list as $a):
        $isAtiva=$aulaVer&&$a['id_aula']==$aulaVer['id_aula'];
        $thumb=getThumb($a['link']??'');
        $vtype=getVideoType($a['link']??'');
        $vicons=['youtube'=>'▶️','vimeo'=>'🎞️','gdrive'=>'📁','direct'=>'🎬','link'=>'🔗'];
      ?>
      <a href="?ver=<?=$a['id_aula']?>&f=<?=$f?>"
         class="playlist-item aula-item <?=$isAtiva?'active':''?>"
         data-search="<?=strtolower(htmlspecialchars($a['titulo'].' '.($a['materia']??'')))?>">

        <!-- Thumbnail -->
        <div class="pl-thumb-wrap">
          <?php if($thumb):?>
            <img src="<?=htmlspecialchars($thumb)?>" alt="" class="pl-thumb" loading="lazy" onerror="this.parentNode.innerHTML='<div class=pl-thumb-empty><?=$vicons[$vtype]?></div>'">
          <?php else:?>
            <div class="pl-thumb-empty"><?=$vicons[$vtype]?></div>
          <?php endif;?>
          <?php if($isAtiva):?>
            <div class="pl-playing-badge">▶ Reproduzindo</div>
          <?php endif;?>
          <?php if($a['status']==='assistida'):?>
            <div class="pl-done-badge">✓</div>
          <?php endif;?>
        </div>

        <!-- Info -->
        <div class="pl-info">
          <div class="pl-title <?=$isAtiva?'active':''?>"><?=htmlspecialchars($a['titulo'])?></div>
          <div class="pl-meta">
            <?php if($a['materia']):?><span><?=htmlspecialchars($a['materia'])?></span><?php endif;?>
            <?php if($a['professor']):?><span>· <?=htmlspecialchars($a['professor'])?></span><?php endif;?>
          </div>
          <div style="display:flex;align-items:center;gap:6px;margin-top:4px;">
            <span class="badge badge-<?=$a['status']==='assistida'?'green':'orange'?>" style="font-size:10px;">
              <?=$a['status']==='assistida'?'✅':'⏳'?>
            </span>
            <?php if($a['data']):?>
              <span style="font-size:10.5px;color:var(--tx3);"><?=date('d/m',strtotime($a['data']))?></span>
            <?php endif;?>
          </div>
        </div>
      </a>
      <?php endforeach;?>
    </div>

    <!-- Botão adicionar na playlist -->
    <div style="padding:16px;">
      <button class="btn btn-primary" style="width:100%;" onclick="Modal.open('mAdd')">+ Adicionar aula</button>
    </div>
  </div><!-- /.playlist-section -->

</div><!-- /.aulas-layout -->
<?php endif;?>

</div><!-- /.page-content -->
</div><!-- /.main-content -->
</div><!-- /.app-wrapper -->

<!-- ── MODAL ADICIONAR ── -->
<div class="modal-overlay" id="mAdd">
  <div class="modal modal-lg">
    <div class="modal-header">
      <div class="modal-title">🎬 Nova Aula</div>
      <button class="modal-x">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Título da aula *</label>
          <input type="text" name="titulo" class="form-control" placeholder="Ex: Funções do 2º grau — Exercícios" required autofocus>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Matéria</label>
            <input type="text" name="materia" class="form-control" placeholder="Ex: Matemática">
          </div>
          <div class="form-group">
            <label class="form-label">Professor</label>
            <input type="text" name="professor" class="form-control" placeholder="Nome do professor">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">🔗 Link do vídeo</label>
          <input type="url" name="link" id="addLink" class="form-control"
                 placeholder="https://youtube.com/watch?v=... ou Vimeo, Google Drive..."
                 oninput="previewLink(this.value)">
          <div id="linkPreview" style="margin-top:10px;display:none;"></div>
          <div style="margin-top:8px;font-size:12px;color:var(--tx3);">
            ✅ Suporta: <strong>YouTube</strong>, <strong>Vimeo</strong>, <strong>Google Drive</strong>, links MP4/WebM diretos
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Data da aula</label>
          <input type="date" name="data" class="form-control">
        </div>
        <div class="form-group">
          <label class="form-label">Anotações iniciais</label>
          <textarea name="anotacoes" class="form-control" rows="3" placeholder="Escreva anotações sobre esta aula..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost modal-x">Cancelar</button>
        <button type="submit" class="btn btn-primary">Salvar aula</button>
      </div>
    </form>
  </div>
</div>

<!-- ── MODAL EDITAR ── -->
<div class="modal-overlay" id="mEdit">
  <div class="modal modal-lg">
    <div class="modal-header">
      <div class="modal-title">✏️ Editar Aula</div>
      <button class="modal-x">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="eAId">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Título *</label>
          <input type="text" name="titulo" id="eATitulo" class="form-control" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Matéria</label>
            <input type="text" name="materia" id="eAMat" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">Professor</label>
            <input type="text" name="professor" id="eAProf" class="form-control">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">🔗 Link do vídeo</label>
          <input type="url" name="link" id="eALink" class="form-control" oninput="previewLinkEdit(this.value)">
          <div id="linkPreviewEdit" style="margin-top:10px;display:none;"></div>
        </div>
        <div class="form-group">
          <label class="form-label">Data</label>
          <input type="date" name="data" id="eAData" class="form-control">
        </div>
        <div class="form-group">
          <label class="form-label">Anotações</label>
          <textarea name="anotacoes" id="eAAnn" class="form-control" rows="4"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost modal-x">Cancelar</button>
        <button type="submit" class="btn btn-primary">Salvar alterações</button>
      </div>
    </form>
  </div>
</div>

<!-- ── SALVAR ANOTAÇÕES (AJAX) ── -->
<form id="formNote" method="POST" style="display:none;">
  <input type="hidden" name="action" value="edit">
  <input type="hidden" name="id" id="noteId">
  <input type="hidden" name="titulo" id="noteTitulo">
  <input type="hidden" name="materia" id="noteMateria">
  <input type="hidden" name="professor" id="noteProfessor">
  <input type="hidden" name="data" id="noteData">
  <input type="hidden" name="link" id="noteLink">
  <input type="hidden" name="anotacoes" id="noteContent">
</form>

<?php include '../includes/footer.php'; ?>

<style>
/* ── Layout Aulas ── */
.aulas-layout {
  display: grid;
  grid-template-columns: 1fr 360px;
  gap: 20px;
  align-items: start;
}

/* Player */
.player-section {
  background: var(--card);
  border-radius: 20px;
  border: 1px solid var(--border);
  overflow: hidden;
  box-shadow: var(--shadow-md);
}

.video-container {
  position: relative;
  width: 100%;
  aspect-ratio: 16/9;
  background: #000;
  border-radius: 0;
  overflow: hidden;
}

.video-container iframe,
.video-container video {
  position: absolute;
  top: 0; left: 0;
  width: 100%; height: 100%;
  border: none;
}

.video-placeholder {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: linear-gradient(145deg, #0f0c29, #1a1636);
  color: #fff;
  text-align: center;
  padding: 32px;
}
.vp-icon  { font-size: 64px; margin-bottom: 16px; }
.vp-title { font-size: 20px; font-weight: 800; margin-bottom: 8px; font-family:'Plus Jakarta Sans',sans-serif; }
.vp-sub   { font-size: 14px; opacity: 0.65; line-height: 1.6; }

/* Player info */
.player-info { padding: 20px; }

.player-info-header {
  display: flex;
  align-items: flex-start;
  gap: 16px;
  flex-wrap: wrap;
  margin-bottom: 16px;
}

.player-title {
  font-size: 18px;
  font-weight: 800;
  color: var(--tx1);
  font-family: 'Plus Jakarta Sans', sans-serif;
  margin-bottom: 8px;
  line-height: 1.3;
}

.player-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.player-tag {
  font-size: 12px;
  background: var(--bg2);
  color: var(--tx2);
  padding: 4px 10px;
  border-radius: 99px;
  border: 1px solid var(--border);
  font-weight: 500;
}
.player-tag.tag-green { background: rgba(16,185,129,0.1); color: #059669; border-color: rgba(16,185,129,0.2); }
.player-tag.tag-orange{ background: rgba(245,158,11,0.1); color: #d97706; border-color: rgba(245,158,11,0.2); }

.player-actions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  align-items: center;
  flex-shrink: 0;
}

/* Próxima aula bar */
.next-aula-bar {
  background: var(--bg2);
  border-radius: 12px;
  padding: 12px 16px;
  margin-bottom: 16px;
  border: 1px solid var(--border);
}
.next-label { font-size: 11px; font-weight: 700; color: var(--tx3); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 10px; }
.next-link {
  display: flex;
  align-items: center;
  gap: 12px;
  text-decoration: none;
  color: var(--tx1);
  transition: all 0.2s;
}
.next-link:hover { color: var(--p1); }
.next-thumb {
  width: 80px; height: 46px;
  border-radius: 8px;
  object-fit: cover;
  flex-shrink: 0;
  background: var(--bg);
}
.next-thumb-empty {
  width: 80px; height: 46px;
  border-radius: 8px;
  background: linear-gradient(135deg, var(--p1), var(--accent));
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
  flex-shrink: 0;
}
.next-title { font-size: 13px; font-weight: 700; color: var(--tx1); }
.next-sub   { font-size: 11.5px; color: var(--tx3); margin-top: 2px; }

/* Anotações */
.notes-section { border-top: 1px solid var(--border); padding-top: 16px; }
.notes-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
  font-weight: 700;
  font-size: 13.5px;
  color: var(--tx1);
}

/* Playlist */
.playlist-section {
  background: var(--card);
  border-radius: 20px;
  border: 1px solid var(--border);
  box-shadow: var(--shadow-md);
  overflow: hidden;
  position: sticky;
  top: 80px;
  max-height: calc(100vh - 100px);
  display: flex;
  flex-direction: column;
}

.playlist-header {
  padding: 16px;
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}
.playlist-title {
  font-size: 14px;
  font-weight: 800;
  color: var(--tx1);
  font-family: 'Plus Jakarta Sans', sans-serif;
  margin-bottom: 10px;
}

.playlist-list {
  flex: 1;
  overflow-y: auto;
}

.playlist-item {
  display: flex;
  gap: 12px;
  padding: 12px 14px;
  text-decoration: none;
  border-bottom: 1px solid var(--border);
  transition: all 0.2s;
  cursor: pointer;
}
.playlist-item:hover { background: rgba(124,58,237,0.05); }
.playlist-item.active { background: rgba(124,58,237,0.1); border-left: 3px solid var(--p1); }
.playlist-item:last-child { border-bottom: none; }

.pl-thumb-wrap {
  position: relative;
  flex-shrink: 0;
  width: 90px; height: 54px;
  border-radius: 8px;
  overflow: hidden;
}
.pl-thumb {
  width: 100%; height: 100%;
  object-fit: cover;
  border-radius: 8px;
}
.pl-thumb-empty {
  width: 90px; height: 54px;
  background: linear-gradient(135deg, rgba(124,58,237,0.2), rgba(6,182,212,0.2));
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
}
.pl-playing-badge {
  position: absolute;
  inset: 0;
  background: rgba(124,58,237,0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 11px;
  font-weight: 700;
  color: #fff;
  border-radius: 8px;
}
.pl-done-badge {
  position: absolute;
  top: 3px; right: 3px;
  width: 18px; height: 18px;
  background: var(--success);
  color: #fff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  font-weight: 700;
}

.pl-info { flex: 1; min-width: 0; }
.pl-title {
  font-size: 12.5px;
  font-weight: 600;
  color: var(--tx1);
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  line-height: 1.4;
  margin-bottom: 4px;
}
.pl-title.active { color: var(--p1); }
.pl-meta {
  font-size: 11px;
  color: var(--tx3);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* Link preview no modal */
.link-preview-box {
  background: var(--bg2);
  border-radius: 10px;
  padding: 12px;
  border: 1px solid var(--border);
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 13px;
}
.link-preview-box img {
  width: 80px; height: 46px;
  object-fit: cover;
  border-radius: 6px;
}
.link-preview-type {
  display: inline-block;
  background: rgba(124,58,237,0.1);
  color: var(--p1);
  padding: 2px 8px;
  border-radius: 99px;
  font-size: 11px;
  font-weight: 700;
  margin-bottom: 4px;
}

@media(max-width:900px){
  .aulas-layout { grid-template-columns: 1fr; }
  .playlist-section { position:static; max-height:400px; }
}
</style>

<script>
/* ── Abrir edição ── */
function openEditA(a){
  document.getElementById('eAId').value      = a.id_aula;
  document.getElementById('eATitulo').value  = a.titulo;
  document.getElementById('eAMat').value     = a.materia||'';
  document.getElementById('eAProf').value    = a.professor||'';
  document.getElementById('eAData').value    = a.data||'';
  document.getElementById('eALink').value    = a.link||'';
  document.getElementById('eAAnn').value     = a.anotacoes||'';
  const prev=document.getElementById('linkPreviewEdit');
  prev.style.display='none';
  if(a.link) previewLinkEdit(a.link);
  Modal.open('mEdit');
}

/* ── Preview de link ── */
function detectVideo(url){
  if(!url) return null;
  let ytM=url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([A-Za-z0-9_\-]{11})/);
  if(ytM) return {type:'YouTube',thumb:'https://img.youtube.com/vi/'+ytM[1]+'/mqdefault.jpg'};
  let vmM=url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if(vmM) return {type:'Vimeo',thumb:'https://vumbnail.com/'+vmM[1]+'.jpg'};
  if(url.match(/drive\.google\.com/)) return {type:'Google Drive',thumb:null};
  if(url.match(/\.(mp4|webm|ogg)$/i)) return {type:'Vídeo Direto',thumb:null};
  return {type:'Link',thumb:null};
}

function renderPreview(containerId, url){
  const c=document.getElementById(containerId);
  const info=detectVideo(url);
  if(!info){ c.style.display='none'; return; }
  c.style.display='block';
  let html=`<div class="link-preview-box">`;
  if(info.thumb) html+=`<img src="${info.thumb}" onerror="this.style.display='none'" alt="">`;
  html+=`<div><span class="link-preview-type">${info.type}</span><div style="font-size:12px;color:var(--tx2);">Link detectado e pronto para reprodução</div></div></div>`;
  c.innerHTML=html;
}

function previewLink(url)     { renderPreview('linkPreview',url); }
function previewLinkEdit(url) { renderPreview('linkPreviewEdit',url); }

/* ── Salvar anotações ── */
function saveNote(id){
  const txt=document.getElementById('noteArea').value;
  const f=document.getElementById('formNote');
  document.getElementById('noteId').value=id;
  document.getElementById('noteContent').value=txt;
  /* Preenche campos ocultos com dados atuais da aula */
  document.getElementById('noteTitulo').value   = document.querySelector('.player-title')?.textContent||'';
  document.getElementById('noteMateria').value  = '';
  document.getElementById('noteProfessor').value= '';
  document.getElementById('noteData').value     = '';
  document.getElementById('noteLink').value     = '';
  f.submit();
}

/* ── Busca na playlist ── */
filterList('searchA','.aula-item');

/* ── Auto-highlight menu ── */
document.querySelectorAll('.nav-link').forEach(a=>{
  if(a.getAttribute('href')==='aulas.php') a.classList.add('active');
});
</script>

<?php
session_start();
if (isset($_SESSION['id_usuario'])) { header('Location: dashboard.php'); exit; }
require_once '../config/conexao.php';
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome  = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $conf  = $_POST['confirmar'] ?? '';

    if (!$nome || !$email || !$senha)  $erro = 'Preencha todos os campos.';
    elseif (strlen($senha) < 6)        $erro = 'Senha deve ter pelo menos 6 caracteres.';
    elseif ($senha !== $conf)           $erro = 'As senhas não coincidem.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $erro = 'Email inválido.';
    else {
        $ck = $conn->prepare("SELECT id_usuario FROM usuarios WHERE email=?");
        $ck->bind_param('s', $email); $ck->execute(); $ck->store_result();
        if ($ck->num_rows > 0) {
            $erro = 'Este email já está cadastrado.';
        } else {
            $hash = password_hash($senha, PASSWORD_DEFAULT);
            $st   = $conn->prepare("INSERT INTO usuarios (nome,email,senha) VALUES (?,?,?)");
            $st->bind_param('sss', $nome, $email, $hash);
            if ($st->execute()) {
                $uid = $conn->insert_id;
                /* Matérias padrão */
                $mats = [
                    ['Matemática','#7c3aed'],['Português','#ec4899'],['Redação','#06b6d4'],
                    ['Biologia','#10b981'],['Química','#f59e0b'],['Física','#3b82f6'],
                    ['História','#8b5cf6'],['Geografia','#14b8a6'],['Inglês','#f97316'],['Literatura','#e11d48']
                ];
                $sm = $conn->prepare("INSERT INTO materias (nome,cor,id_usuario) VALUES (?,?,?)");
                foreach ($mats as [$mn,$mc]) { $sm->bind_param('ssi',$mn,$mc,$uid); $sm->execute(); }
                header('Location: login.php?cadastro=ok'); exit;
            } else { $erro = 'Erro ao cadastrar. Tente novamente.'; }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Criar conta | Aprova+</title>
  <link rel="icon" href="../assets/img/favicon.svg" type="image/svg+xml">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/auth.css">
</head>
<body>
<div class="auth-bg">
  <div class="auth-grid"></div>
  <div class="auth-bg-blob"></div>
</div>

<div class="auth-container">

  <div class="auth-left">
    <div>
      <div class="auth-logo-wrap">
        <div class="auth-logo-icon">🎯</div>
        <div class="auth-logo-name">Aprova+</div>
      </div>
      <div class="auth-left-title">
        Junte-se a quem<br><span>estuda com foco.</span>
      </div>
      <div class="auth-left-sub">
        Crie sua conta gratuitamente e tenha acesso a todas as ferramentas que vão transformar sua preparação.
      </div>
      <ul class="auth-features-list">
        <li class="auth-feat"><span class="auth-feat-icon">🆓</span> 100% gratuito para estudantes</li>
        <li class="auth-feat"><span class="auth-feat-icon">🔒</span> Seus dados são privados e seguros</li>
        <li class="auth-feat"><span class="auth-feat-icon">📈</span> Acompanhe sua evolução em tempo real</li>
        <li class="auth-feat"><span class="auth-feat-icon">🎯</span> Defina metas e alcance resultados</li>
      </ul>
    </div>
    <div class="auth-left-footer">© 2025 Aprova+ — Todos os direitos reservados</div>
  </div>

  <div class="auth-right">
    <div class="auth-form-title">Criar conta gratuita 🚀</div>
    <div class="auth-form-sub">Preencha seus dados e comece agora mesmo.</div>

    <?php if ($erro): ?>
      <div class="auth-alert error">⚠️ <?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="auth-field">
        <label class="auth-label">Nome completo</label>
        <div class="auth-input-wrap">
          <input type="text" name="nome" class="auth-input" placeholder="Seu nome completo"
                 value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>" required>
          <span class="auth-input-icon">👤</span>
        </div>
      </div>
      <div class="auth-field">
        <label class="auth-label">Email</label>
        <div class="auth-input-wrap">
          <input type="email" name="email" class="auth-input" placeholder="seu@email.com"
                 value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
          <span class="auth-input-icon">📧</span>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
        <div class="auth-field">
          <label class="auth-label">Senha</label>
          <div class="auth-input-wrap">
            <input type="password" name="senha" class="auth-input" placeholder="Mín. 6 caracteres" required>
            <span class="auth-input-icon">🔒</span>
          </div>
        </div>
        <div class="auth-field">
          <label class="auth-label">Confirmar</label>
          <div class="auth-input-wrap">
            <input type="password" name="confirmar" class="auth-input" placeholder="Repita a senha" required>
            <span class="auth-input-icon">🔒</span>
          </div>
        </div>
      </div>
      <button type="submit" class="auth-submit">Criar minha conta grátis →</button>
    </form>

    <p class="auth-switch">
      Já tem uma conta? <a href="login.php">Fazer login</a>
    </p>
  </div>

</div>
</body>
</html>

<?php
$pageTitle = 'Cronograma';
require_once '../config/conexao.php';
require_once '../includes/header.php';

$idU = $_SESSION['id_usuario'];
$msg = '';

// CRUD Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $idMat  = intval($_POST['id_materia']);
        $data   = $conn->real_escape_string($_POST['data']);
        $hora   = $conn->real_escape_string($_POST['horario']);
        $dur    = intval($_POST['duracao'] ?? 60);
        $cont   = $conn->real_escape_string($_POST['conteudo']);
        $stmt = $conn->prepare("INSERT INTO cronograma (id_usuario, id_materia, data, horario, duracao, conteudo) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param('iissss', $idU, $idMat, $data, $hora, $dur, $cont);
        $stmt->execute();
        $msg = 'success|Estudo adicionado ao cronograma!';
    }

    if ($action === 'delete') {
        $id = intval($_POST['id']);
        $conn->query("DELETE FROM cronograma WHERE id_cronograma=$id AND id_usuario=$idU");
        $msg = 'success|Estudo removido.';
    }

    if ($action === 'toggle') {
        $id = intval($_POST['id']);
        $conn->query("UPDATE cronograma SET status = IF(status='pendente','concluido','pendente') WHERE id_cronograma=$id AND id_usuario=$idU");
        header('Location: cronograma.php');
        exit;
    }

    if ($action === 'edit') {
        $id   = intval($_POST['id']);
        $idMat = intval($_POST['id_materia']);
        $data  = $conn->real_escape_string($_POST['data']);
        $hora  = $conn->real_escape_string($_POST['horario']);
        $dur   = intval($_POST['duracao'] ?? 60);
        $cont  = $conn->real_escape_string($_POST['conteudo']);
        $conn->query("UPDATE cronograma SET id_materia=$idMat, data='$data', horario='$hora', duracao=$dur, conteudo='$cont' WHERE id_cronograma=$id AND id_usuario=$idU");
        $msg = 'success|Estudo atualizado!';
    }
}

// Semana atual
$semanaInicio = date('Y-m-d', strtotime('monday this week'));
$semanaFim = date('Y-m-d', strtotime('sunday this week'));

// Buscar semana selecionada
$semana = $_GET['semana'] ?? $semanaInicio;
$semanaIni = date('Y-m-d', strtotime($semana));
$semanaFi  = date('Y-m-d', strtotime($semana . ' +6 days'));
$semanaPrev = date('Y-m-d', strtotime($semana . ' -7 days'));
$semanaNext = date('Y-m-d', strtotime($semana . ' +7 days'));

$diasSemana = [];
for ($i = 0; $i < 7; $i++) {
    $diasSemana[] = date('Y-m-d', strtotime($semanaIni . " +$i days"));
}

// Buscar estudos da semana
$estudos = $conn->query("SELECT c.*, m.nome as materia, m.cor FROM cronograma c LEFT JOIN materias m ON c.id_materia=m.id_materia WHERE c.id_usuario=$idU AND c.data BETWEEN '$semanaIni' AND '$semanaFi' ORDER BY c.data, c.horario");
$estudosArr = [];
while ($e = $estudos->fetch_assoc()) {
    $estudosArr[$e['data']][] = $e;
}

// Matérias
$materias = $conn->query("SELECT * FROM materias WHERE id_usuario=$idU ORDER BY nome");
$materiasArr = [];
while ($m = $materias->fetch_assoc()) $materiasArr[] = $m;

// Nomes dos dias
$nomesDias = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
?>

<div class="app-wrapper">
    <?php include '../includes/menu.php'; ?>

    <div class="main-content">
        <div class="topbar">
            <button class="btn-menu-toggle" id="menuToggle">☰</button>
            <div>
                <div class="topbar-title">📅 Cronograma de Estudos</div>
                <div class="topbar-subtitle">Organize seus horários semanais</div>
            </div>
            <div class="topbar-actions">
                <button class="btn btn-primary" onclick="Modal.open('modalAddEstudo')">+ Adicionar estudo</button>
                <button class="theme-toggle" id="themeToggle" onclick="ThemeManager.toggle()">🌙</button>
            </div>
        </div>

        <div class="page-content">

            <?php if ($msg): [$tipo, $texto] = explode('|', $msg, 2); ?>
                <script>document.addEventListener('DOMContentLoaded',()=>Toast.show('<?= addslashes($texto) ?>','<?= $tipo ?>'));</script>
            <?php endif; ?>

            <!-- Navegação da semana -->
            <div class="card" style="margin-bottom:20px;">
                <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
                    <a href="?semana=<?= $semanaPrev ?>" class="btn btn-secondary">← Semana anterior</a>
                    <div style="flex:1;text-align:center;">
                        <strong style="font-size:15px;">
                            <?= date('d/m', strtotime($semanaIni)) ?> — <?= date('d/m/Y', strtotime($semanaFi)) ?>
                        </strong>
                        <?php if ($semanaIni === $semanaInicio): ?>
                            <span class="badge badge-primary" style="margin-left:8px;">Semana atual</span>
                        <?php endif; ?>
                    </div>
                    <a href="?semana=<?= $semanaNext ?>" class="btn btn-secondary">Próxima semana →</a>
                    <a href="?semana=<?= $semanaInicio ?>" class="btn btn-sm btn-secondary">Hoje</a>
                </div>
            </div>

            <!-- Grade semanal -->
            <div class="week-grid" style="margin-bottom:20px;">
                <?php foreach ($diasSemana as $dia): ?>
                    <?php
                    $ts = strtotime($dia);
                    $nomeDia = $nomesDias[date('w', $ts)];
                    $numDia = date('d/m', $ts);
                    $isHoje = $dia === date('Y-m-d') ? 'border:2px solid var(--primary);' : '';
                    $eventos = $estudosArr[$dia] ?? [];
                    ?>
                    <div class="day-column" style="<?= $isHoje ?>">
                        <div class="day-header">
                            <?= $nomeDia ?><br>
                            <span style="font-size:11px;opacity:.8"><?= $numDia ?></span>
                        </div>
                        <div class="day-events">
                            <?php if (count($eventos) === 0): ?>
                                <div style="font-size:11px;color:var(--text-muted);text-align:center;padding:10px 0;">Livre</div>
                            <?php endif; ?>
                            <?php foreach ($eventos as $ev): ?>
                                <div class="event-chip <?= $ev['status'] === 'concluido' ? 'done' : '' ?>"
                                     style="border-left-color:<?= htmlspecialchars($ev['cor'] ?? '#6c63ff') ?>;"
                                     title="<?= htmlspecialchars($ev['conteudo']) ?>">
                                    <div style="font-weight:700;font-size:11px;">
                                        <?= substr($ev['horario'],0,5) ?> · <?= htmlspecialchars($ev['materia'] ?? 'Sem matéria') ?>
                                    </div>
                                    <div style="color:var(--text-secondary);font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                        <?= htmlspecialchars($ev['conteudo']) ?>
                                    </div>
                                    <div style="display:flex;gap:4px;margin-top:4px;">
                                        <form method="POST" style="display:inline">
                                            <input type="hidden" name="action" value="toggle">
                                            <input type="hidden" name="id" value="<?= $ev['id_cronograma'] ?>">
                                            <button type="submit" class="btn btn-sm btn-<?= $ev['status'] === 'concluido' ? 'warning' : 'success' ?>" style="padding:2px 6px;font-size:10px;">
                                                <?= $ev['status'] === 'concluido' ? '↩' : '✓' ?>
                                            </button>
                                        </form>
                                        <form method="POST" style="display:inline" onsubmit="return confirmDelete()">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id" value="<?= $ev['id_cronograma'] ?>">
                                            <button type="submit" class="btn btn-sm btn-danger" style="padding:2px 6px;font-size:10px;">✕</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Lista detalhada -->
            <div class="card">
                <div class="card-header">
                    <div class="card-title">📋 Lista detalhada da semana</div>
                </div>
                <?php
                $totalSemana = 0;
                foreach ($estudosArr as $d => $evs) {
                    foreach ($evs as $ev) $totalSemana += $ev['duracao'];
                }
                ?>
                <div style="margin-bottom:16px;font-size:14px;color:var(--text-muted);">
                    Total planejado: <strong><?= round($totalSemana/60, 1) ?>h</strong> esta semana
                </div>
                <?php if (array_sum(array_map('count', $estudosArr)) === 0): ?>
                    <div class="empty-state">
                        <div class="empty-icon">📅</div>
                        <h3>Semana vazia</h3>
                        <p>Adicione estudos ao cronograma desta semana.</p>
                    </div>
                <?php else: ?>
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>Dia</th>
                                    <th>Horário</th>
                                    <th>Matéria</th>
                                    <th>Conteúdo</th>
                                    <th>Duração</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($diasSemana as $dia): ?>
                                    <?php foreach ($estudosArr[$dia] ?? [] as $ev): ?>
                                        <tr>
                                            <td><?= date('d/m (D)', strtotime($dia)) ?></td>
                                            <td><?= substr($ev['horario'],0,5) ?></td>
                                            <td>
                                                <span style="display:flex;align-items:center;gap:6px;">
                                                    <span style="width:10px;height:10px;border-radius:2px;background:<?= htmlspecialchars($ev['cor'] ?? '#6c63ff') ?>;display:inline-block"></span>
                                                    <?= htmlspecialchars($ev['materia'] ?? '—') ?>
                                                </span>
                                            </td>
                                            <td><?= htmlspecialchars($ev['conteudo']) ?></td>
                                            <td><?= $ev['duracao'] ?>min</td>
                                            <td>
                                                <span class="badge badge-<?= $ev['status'] === 'concluido' ? 'success' : 'warning' ?>">
                                                    <?= $ev['status'] === 'concluido' ? '✅ Concluído' : '⏳ Pendente' ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div style="display:flex;gap:6px;">
                                                    <form method="POST" style="display:inline">
                                                        <input type="hidden" name="action" value="toggle">
                                                        <input type="hidden" name="id" value="<?= $ev['id_cronograma'] ?>">
                                                        <button type="submit" class="btn-icon" title="<?= $ev['status'] === 'concluido' ? 'Desfazer' : 'Concluir' ?>">
                                                            <?= $ev['status'] === 'concluido' ? '↩️' : '✅' ?>
                                                        </button>
                                                    </form>
                                                    <form method="POST" style="display:inline" onsubmit="return confirmDelete()">
                                                        <input type="hidden" name="action" value="delete">
                                                        <input type="hidden" name="id" value="<?= $ev['id_cronograma'] ?>">
                                                        <button type="submit" class="btn-icon" title="Excluir">🗑️</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

        </div><!-- /.page-content -->
    </div><!-- /.main-content -->
</div><!-- /.app-wrapper -->

<?php include '../includes/footer.php'; ?>

<!-- Modal Adicionar Estudo -->
<div class="modal-overlay" id="modalAddEstudo">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title">📅 Adicionar Estudo</div>
            <button class="modal-close" onclick="Modal.close('modalAddEstudo')">✕</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Matéria *</label>
                        <select name="id_materia" class="form-control" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($materiasArr as $m): ?>
                                <option value="<?= $m['id_materia'] ?>"><?= htmlspecialchars($m['nome']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Data *</label>
                        <input type="date" name="data" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Horário *</label>
                        <input type="time" name="horario" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Duração (minutos)</label>
                        <input type="number" name="duracao" class="form-control" value="60" min="15" max="480">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Conteúdo *</label>
                    <input type="text" name="conteudo" class="form-control" placeholder="Ex: Funções do 2º grau" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="Modal.close('modalAddEstudo')">Cancelar</button>
                <button type="submit" class="btn btn-primary">Adicionar ao cronograma</button>
            </div>
        </form>
    </div>
</div>

<?php
$pageTitle = 'Dashboard';
require_once '../config/conexao.php';
require_once '../includes/header.php';

$uid  = (int)$_SESSION['id_usuario'];
$nome = $_SESSION['nome'];
$h    = (int)date('H');
$sauda= $h<12?'Bom dia':'($h<18?Boa tarde:Boa noite)';
$sauda= $h<12?'Bom dia':($h<18?'Boa tarde':'Boa noite');

/* ─ Dados ─ */
$tPend = (int)$conn->query("SELECT COUNT(*) c FROM tarefas WHERE id_usuario=$uid AND status='pendente'")->fetch_assoc()['c'];
$tConc = (int)$conn->query("SELECT COUNT(*) c FROM tarefas WHERE id_usuario=$uid AND status='concluida'")->fetch_assoc()['c'];
$aAss  = (int)$conn->query("SELECT COUNT(*) c FROM aulas WHERE id_usuario=$uid AND status='assistida'")->fetch_assoc()['c'];
$aPend = (int)$conn->query("SELECT COUNT(*) c FROM aulas WHERE id_usuario=$uid AND status='pendente'")->fetch_assoc()['c'];

$rRed  = $conn->query("SELECT COUNT(*) c, COALESCE(MAX(nota_final),0) melhor, COALESCE(AVG(nota_final),0) media FROM redacoes WHERE id_usuario=$uid")->fetch_assoc();
$uRed  = $conn->query("SELECT tema, nota_final, DATE_FORMAT(data,'%d/%m/%Y') d FROM redacoes WHERE id_usuario=$uid ORDER BY data DESC LIMIT 1")->fetch_assoc();

$minSem= (int)$conn->query("SELECT COALESCE(SUM(duracao),0) s FROM cronograma WHERE id_usuario=$uid AND status='concluido' AND data>=DATE_SUB(CURDATE(),INTERVAL 7 DAY)")->fetch_assoc()['s'];
$hSem  = round($minSem/60,1);
$metaH = (int)$conn->query("SELECT meta_horas FROM usuarios WHERE id_usuario=$uid")->fetch_assoc()['meta_horas'];
$prog  = $metaH>0 ? min(100,round($hSem/$metaH*100)) : 0;

/* Tarefas urgentes */
$qTar = $conn->query("SELECT descricao,prioridade,prazo FROM tarefas WHERE id_usuario=$uid AND status='pendente' ORDER BY FIELD(prioridade,'alta','media','baixa'),prazo ASC LIMIT 6");
$tarArr = [];
while ($r=$qTar->fetch_assoc()) $tarArr[]=$r;

/* Gráfico 7 dias */
$gl=[]; $gd=[];
for($i=6;$i>=0;$i--){
    $d=date('Y-m-d',strtotime("-$i days"));
    $gl[]=date('D',strtotime("-$i days"));
    $m=(int)$conn->query("SELECT COALESCE(SUM(duracao),0) s FROM cronograma WHERE id_usuario=$uid AND data='$d' AND status='concluido'")->fetch_assoc()['s'];
    $gd[]=round($m/60,1);
}

/* Matérias esta semana */
$qMat=$conn->query("SELECT m.nome,m.cor,COUNT(c.id_cronograma) cnt FROM cronograma c LEFT JOIN materias m ON c.id_materia=m.id_materia WHERE c.id_usuario=$uid AND c.data>=DATE_SUB(CURDATE(),INTERVAL 7 DAY) GROUP BY m.id_materia ORDER BY cnt DESC LIMIT 6");
$matArr=[];
while($r=$qMat->fetch_assoc()) $matArr[]=$r;

/* Próximas aulas */
$qAulas=$conn->query("SELECT titulo,materia,data FROM aulas WHERE id_usuario=$uid AND status='pendente' ORDER BY data ASC LIMIT 4");
$aulArr=[];
while($r=$qAulas->fetch_assoc()) $aulArr[]=$r;
?>

<div class="app-wrapper">
<?php include '../includes/menu.php'; ?>
<div class="main-content">

<!-- Topbar -->
<div class="topbar">
  <button class="menu-toggle" id="menuToggle">☰</button>
  <div class="topbar-left">
    <div class="topbar-page"><?= $sauda ?>, <?= htmlspecialchars(explode(' ',$nome)[0]) ?>! 👋</div>
    <div class="topbar-hint"><?= date('l, d \d\e F \d\e Y') ?></div>
  </div>
  <div class="topbar-right">
    <a href="tarefas.php" class="icon-btn" title="Tarefas">✅</a>
    <button class="icon-btn" id="themeBtn" onclick="Theme.toggle()" title="Tema">🌙</button>
  </div>
</div>

<div class="page-content">

  <!-- Hero -->
  <div class="hero-card anim-up">
    <div class="hero-greeting">Bem-vindo à sua central de estudos</div>
    <div class="hero-name"><?= htmlspecialchars($nome) ?> 🎓</div>
    <div class="hero-meta">
      <div class="hero-meta-item">⏱️ <?= $hSem ?>h esta semana</div>
      <div class="hero-meta-item">🎯 Meta: <?= $prog ?>%</div>
      <div class="hero-meta-item">✅ <?= $tConc ?> tarefas concluídas</div>
      <?php if($uRed): ?>
      <div class="hero-meta-item">✍️ Última nota: <?= $uRed['nota_final'] ?> pts</div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Stats -->
  <div class="stats-grid mb-24">
    <div class="stat-card anim-up">
      <div class="stat-icon-wrap si-purple">✅</div>
      <div class="stat-num" data-count="<?=$tPend?>"><?=$tPend?></div>
      <div class="stat-lbl">Tarefas pendentes</div>
      <div class="stat-hint <?=$tPend===0?'up':''?>"><?=$tPend===0?'🎉 Tudo em dia':'📋 Para fazer hoje'?></div>
    </div>
    <div class="stat-card anim-up">
      <div class="stat-icon-wrap si-cyan">🎬</div>
      <div class="stat-num" data-count="<?=$aPend?>"><?=$aPend?></div>
      <div class="stat-lbl">Aulas pendentes</div>
      <div class="stat-hint">📺 <?=$aAss?> assistidas no total</div>
    </div>
    <div class="stat-card anim-up">
      <div class="stat-icon-wrap si-green">⏱️</div>
      <div class="stat-num"><?=$hSem?>h</div>
      <div class="stat-lbl">Horas esta semana</div>
      <div class="stat-hint <?=$prog>=100?'up':''?>">🎯 Meta: <?=$metaH?>h</div>
    </div>
    <div class="stat-card anim-up">
      <div class="stat-icon-wrap si-pink">✍️</div>
      <div class="stat-num" data-count="<?=(int)$rRed['c']?>"><?=$rRed['c']?></div>
      <div class="stat-lbl">Redações escritas</div>
      <div class="stat-hint">📊 Média: <?=round($rRed['media'])?> pts</div>
    </div>
    <div class="stat-card anim-up">
      <div class="stat-icon-wrap si-orange">🏆</div>
      <div class="stat-num"><?=$rRed['melhor']?:'-'?></div>
      <div class="stat-lbl">Melhor nota ENEM</div>
      <div class="stat-hint up"><?=$rRed['melhor']>=800?'🌟 Excelente!':($rRed['melhor']>=600?'👍 Bom!':'📈 Evolua!')?></div>
    </div>
    <div class="stat-card anim-up">
      <div class="stat-icon-wrap si-purple">🎯</div>
      <div class="stat-num"><?=$prog?>%</div>
      <div class="stat-lbl">Meta semanal</div>
      <div class="stat-hint <?=$prog>=100?'up':''?>"><?=$prog>=100?'🎉 Meta atingida!':'⏳ '.$hSem.'/'.$metaH.'h'?></div>
    </div>
  </div>

  <!-- Progresso -->
  <div class="card anim-up mb-20">
    <div class="card-header">
      <div class="card-title">🎯 Meta de estudos semanal</div>
      <span class="badge badge-purple"><?=$prog?>% concluído</span>
    </div>
    <div style="font-size:13px;color:var(--tx3);margin-bottom:10px;"><?=$hSem?>h de <?=$metaH?>h planejadas esta semana</div>
    <div class="progress"><div class="progress-fill" style="width:<?=$prog?>%"></div></div>
  </div>

  <!-- Grid principal -->
  <div class="grid-2 mb-20">

    <!-- Gráfico semanal -->
    <div class="card anim-up">
      <div class="card-header">
        <div class="card-title">📈 Horas estudadas (7 dias)</div>
      </div>
      <div class="chart-wrap"><canvas id="chartWeek"></canvas></div>
    </div>

    <!-- Matérias -->
    <div class="card anim-up">
      <div class="card-header">
        <div class="card-title">📚 Matérias desta semana</div>
        <a href="cronograma.php" class="btn btn-ghost btn-sm">Ver cronograma</a>
      </div>
      <?php if(!count($matArr)): ?>
        <div class="empty-state">
          <span class="empty-emoji">📚</span>
          <div class="empty-title">Nenhuma sessão concluída</div>
          <div class="empty-desc">Marque seus estudos como concluídos no cronograma.</div>
        </div>
      <?php else: ?>
        <div style="display:flex;flex-direction:column;gap:12px;">
          <?php foreach($matArr as $m): ?>
            <div style="display:flex;align-items:center;gap:12px;">
              <div style="width:10px;height:10px;border-radius:3px;background:<?=htmlspecialchars($m['cor']??'#7c3aed')?>;flex-shrink:0"></div>
              <span style="flex:1;font-size:13.5px;font-weight:500;color:var(--tx1)"><?=htmlspecialchars($m['nome']??'Sem matéria')?></span>
              <span class="badge badge-purple"><?=$m['cnt']?> sessão(ões)</span>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="grid-2">

    <!-- Tarefas prioritárias -->
    <div class="card anim-up">
      <div class="card-header">
        <div class="card-title">⚡ Tarefas prioritárias</div>
        <a href="tarefas.php" class="btn btn-primary btn-sm">Ver todas</a>
      </div>
      <?php if(!count($tarArr)): ?>
        <div class="empty-state" style="padding:28px 0">
          <span class="empty-emoji">🎉</span>
          <div class="empty-title">Tudo em dia!</div>
          <div class="empty-desc">Sem tarefas pendentes.</div>
        </div>
      <?php else: ?>
        <?php foreach($tarArr as $t):
          $pc=['alta'=>'red','media'=>'orange','baixa'=>'green'][$t['prioridade']];
        ?>
          <div class="task-row">
            <div class="task-checkbox">○</div>
            <div style="flex:1">
              <div class="task-text" style="font-size:13.5px;font-weight:500"><?=htmlspecialchars($t['descricao'])?></div>
              <?php if($t['prazo']): ?>
                <div style="font-size:11px;color:var(--tx3);margin-top:3px;">📅 <?=date('d/m/Y',strtotime($t['prazo']))?></div>
              <?php endif; ?>
            </div>
            <span class="badge badge-<?=$pc?>"><?=ucfirst($t['prioridade'])?></span>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- Última redação / próximas aulas -->
    <div class="card anim-up">
      <div class="card-header">
        <div class="card-title">✍️ Última redação</div>
        <a href="redacoes.php" class="btn btn-ghost btn-sm">Ver redações</a>
      </div>
      <?php if($uRed): ?>
        <div style="margin-bottom:16px">
          <div style="font-weight:700;font-size:14px;color:var(--tx1);margin-bottom:4px"><?=htmlspecialchars($uRed['tema'])?></div>
          <div style="font-size:12px;color:var(--tx3)">📅 <?=$uRed['d']?></div>
        </div>
        <div class="nota-total-card">
          <div class="nota-total-num"><?=$uRed['nota_final']?></div>
          <div class="nota-total-label">pontos ENEM (máx. 1000)</div>
        </div>
      <?php else: ?>
        <div class="empty-state" style="padding:24px 0">
          <span class="empty-emoji">✍️</span>
          <div class="empty-title">Nenhuma redação ainda</div>
          <div class="empty-desc">Escreva sua primeira redação!</div>
          <a href="redacoes.php" class="btn btn-primary mt-12">Escrever agora</a>
        </div>
      <?php endif; ?>

      <?php if(count($aulArr)): ?>
        <div class="section-divider"></div>
        <div class="card-title" style="margin-bottom:12px;">🎬 Próximas aulas</div>
        <?php foreach($aulArr as $a): ?>
          <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border)">
            <div style="width:36px;height:36px;background:rgba(124,58,237,0.1);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0">🎬</div>
            <div style="flex:1;min-width:0">
              <div style="font-size:13px;font-weight:600;color:var(--tx1)" class="truncate"><?=htmlspecialchars($a['titulo'])?></div>
              <div style="font-size:11px;color:var(--tx3)"><?=htmlspecialchars($a['materia']??'')?> <?=$a['data']?'· '.date('d/m',strtotime($a['data'])):''?></div>
            </div>
            <span class="badge badge-orange">Pendente</span>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

  </div>

</div><!-- /.page-content -->
</div><!-- /.main-content -->
</div><!-- /.app-wrapper -->

<?php include '../includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const isDark=()=>document.documentElement.getAttribute('data-theme')==='dark';
const gc=()=>isDark()?'rgba(255,255,255,0.06)':'rgba(0,0,0,0.06)';
const tc=()=>isDark()?'#6b6490':'#9297b8';

new Chart(document.getElementById('chartWeek').getContext('2d'),{
  type:'bar',
  data:{
    labels:<?=json_encode($gl)?>,
    datasets:[{
      label:'Horas',
      data:<?=json_encode($gd)?>,
      backgroundColor:'rgba(124,58,237,0.65)',
      borderColor:'#7c3aed',
      borderWidth:2,
      borderRadius:8,
      hoverBackgroundColor:'#a78bfa'
    }]
  },
  options:{
    responsive:true,maintainAspectRatio:false,
    plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>c.parsed.y+'h'}}},
    scales:{
      y:{beginAtZero:true,grid:{color:gc()},ticks:{color:tc(),font:{size:11}}},
      x:{grid:{display:false},ticks:{color:tc(),font:{size:11}}}
    }
  }
});
</script>

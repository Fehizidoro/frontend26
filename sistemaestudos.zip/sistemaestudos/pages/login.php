<?php
session_start();
if (isset($_SESSION['id_usuario'])) { header('Location: dashboard.php'); exit; }
require_once '../config/conexao.php';

$erro = '';
$ok   = isset($_GET['cadastro']) ? 'Conta criada com sucesso! Faça login.' : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (!$email || !$senha) {
        $erro = 'Preencha todos os campos.';
    } else {
        $st = $conn->prepare("SELECT id_usuario, nome, senha FROM usuarios WHERE email=?");
        $st->bind_param('s', $email);
        $st->execute();
        $row = $st->get_result()->fetch_assoc();
        if ($row && password_verify($senha, $row['senha'])) {
            $_SESSION['id_usuario'] = $row['id_usuario'];
            $_SESSION['nome']       = $row['nome'];
            header('Location: dashboard.php'); exit;
        }
        $erro = 'Email ou senha incorretos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Login | Aprova+</title>
  <link rel="icon" href="../assets/img/favicon.svg" type="image/svg+xml">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/auth.css">
</head>
<body>
<div class="auth-bg">
  <div class="auth-grid"></div>
  <div class="auth-bg-blob"></div>
</div>

<div class="auth-container">

  <!-- Esquerdo -->
  <div class="auth-left">
    <div>
      <div class="auth-logo-wrap">
        <div class="auth-logo-icon">🎯</div>
        <div class="auth-logo-name">Aprova+</div>
      </div>
      <div class="auth-left-title">
        Sua aprovação<br><span>começa aqui.</span>
      </div>
      <div class="auth-left-sub">
        Organize sua rotina de estudos, acompanhe redações, gerencie aulas e chegue preparado para o ENEM e vestibulares.
      </div>
      <ul class="auth-features-list">
        <li class="auth-feat"><span class="auth-feat-icon">📅</span> Cronograma inteligente de estudos</li>
        <li class="auth-feat"><span class="auth-feat-icon">✍️</span> Correção e evolução em redações</li>
        <li class="auth-feat"><span class="auth-feat-icon">📊</span> Relatórios de desempenho</li>
        <li class="auth-feat"><span class="auth-feat-icon">🎬</span> Organização de aulas e materiais</li>
        <li class="auth-feat"><span class="auth-feat-icon">✅</span> Lista de tarefas com prioridades</li>
      </ul>
    </div>
    <div class="auth-left-footer">© 2025 Aprova+ — Todos os direitos reservados</div>
  </div>

  <!-- Direito -->
  <div class="auth-right">
    <div class="auth-form-title">Bem-vindo de volta 👋</div>
    <div class="auth-form-sub">Entre na sua conta e continue sua jornada de estudos.</div>

    <?php if ($erro): ?>
      <div class="auth-alert error">⚠️ <?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>
    <?php if ($ok): ?>
      <div class="auth-alert success">✅ <?= htmlspecialchars($ok) ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="on">
      <div class="auth-field">
        <label class="auth-label">Email</label>
        <div class="auth-input-wrap">
          <input type="email" name="email" class="auth-input"
                 placeholder="seu@email.com"
                 value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                 required autocomplete="email">
          <span class="auth-input-icon">📧</span>
        </div>
      </div>
      <div class="auth-field">
        <label class="auth-label">Senha</label>
        <div class="auth-input-wrap">
          <input type="password" name="senha" class="auth-input"
                 placeholder="Sua senha"
                 required autocomplete="current-password">
          <span class="auth-input-icon">🔒</span>
        </div>
      </div>
      <button type="submit" class="auth-submit">Entrar na plataforma →</button>
    </form>

    <p class="auth-switch">
      Ainda não tem conta? <a href="cadastro.php">Cadastre-se grátis</a>
    </p>
  </div>

</div>

<script>
  const t = localStorage.getItem('ap_theme');
  if (t === 'dark') document.documentElement.setAttribute('data-theme','dark');
</script>
</body>
</html>

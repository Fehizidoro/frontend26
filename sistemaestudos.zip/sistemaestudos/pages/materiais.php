<?php
$pageTitle = 'Materiais';
require_once '../config/conexao.php';
require_once '../includes/header.php';

$idU = $_SESSION['id_usuario'];
$msg = '';

// CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $titulo   = $conn->real_escape_string($_POST['titulo']);
        $tipo     = $conn->real_escape_string($_POST['tipo']);
        $conteudo = $conn->real_escape_string($_POST['conteudo']);
        $link     = $conn->real_escape_string($_POST['link']);
        $conn->query("INSERT INTO materiais (id_usuario, titulo, tipo, conteudo, link) VALUES ($idU, '$titulo', '$tipo', '$conteudo', '$link')");
        $msg = 'success|Material salvo com sucesso!';
    }

    if ($action === 'edit') {
        $id      = intval($_POST['id']);
        $titulo  = $conn->real_escape_string($_POST['titulo']);
        $tipo    = $conn->real_escape_string($_POST['tipo']);
        $conteudo= $conn->real_escape_string($_POST['conteudo']);
        $link    = $conn->real_escape_string($_POST['link']);
        $conn->query("UPDATE materiais SET titulo='$titulo', tipo='$tipo', conteudo='$conteudo', link='$link' WHERE id_material=$id AND id_usuario=$idU");
        $msg = 'success|Material atualizado!';
    }

    if ($action === 'delete') {
        $id = intval($_POST['id']);
        $conn->query("DELETE FROM materiais WHERE id_material=$id AND id_usuario=$idU");
        $msg = 'success|Material excluído.';
    }
}

$filtroTipo = $_GET['tipo'] ?? 'todos';
$where = "WHERE id_usuario=$idU";
if ($filtroTipo !== 'todos') $where .= " AND tipo='" . $conn->real_escape_string($filtroTipo) . "'";

$materiais = $conn->query("SELECT * FROM materiais $where ORDER BY data DESC");
$materiaisArr = [];
while ($m = $materiais->fetch_assoc()) $materiaisArr[] = $m;

// Ver material
$viewId = intval($_GET['ver'] ?? 0);
$matVer = null;
if ($viewId > 0) {
    $r = $conn->query("SELECT * FROM materiais WHERE id_material=$viewId AND id_usuario=$idU");
    if ($r && $r->num_rows > 0) $matVer = $r->fetch_assoc();
}

$tiposInfo = [
    'resumo'  => ['emoji'=>'📄','label'=>'Resumo','cor'=>'#6c63ff'],
    'link'    => ['emoji'=>'🔗','label'=>'Link','cor'=>'#4facfe'],
    'pdf'     => ['emoji'=>'📕','label'=>'PDF','cor'=>'#ef4444'],
    'anotacao'=> ['emoji'=>'📝','label'=>'Anotação','cor'=>'#10b981'],
    'outro'   => ['emoji'=>'📦','label'=>'Outro','cor'=>'#f59e0b'],
];
?>

<div class="app-wrapper">
    <?php include '../includes/menu.php'; ?>

    <div class="main-content">
        <div class="topbar">
            <button class="btn-menu-toggle" id="menuToggle">☰</button>
            <div>
                <div class="topbar-title">📚 Central de Materiais</div>
                <div class="topbar-subtitle">Organize seus resumos, links e anotações</div>
            </div>
            <div class="topbar-actions">
                <button class="btn btn-primary" onclick="Modal.open('modalAddMaterial')">+ Novo material</button>
                <button class="theme-toggle" id="themeToggle" onclick="ThemeManager.toggle()">🌙</button>
            </div>
        </div>

        <div class="page-content">
            <?php if ($msg): [$tipo2, $texto] = explode('|', $msg, 2); ?>
                <script>document.addEventListener('DOMContentLoaded',()=>Toast.show('<?= addslashes($texto) ?>','<?= $tipo2 ?>'));</script>
            <?php endif; ?>

            <!-- Stats por tipo -->
            <div class="stats-grid" style="grid-template-columns:repeat(5,1fr);margin-bottom:20px;">
                <?php foreach ($tiposInfo as $key => $info):
                    $count = $conn->query("SELECT COUNT(*) as c FROM materiais WHERE id_usuario=$idU AND tipo='$key'")->fetch_assoc()['c'];
                ?>
                    <div class="stat-card" style="padding:16px;">
                        <div style="font-size:28px;margin-bottom:8px;"><?= $info['emoji'] ?></div>
                        <div class="stat-value" style="font-size:24px;"><?= $count ?></div>
                        <div class="stat-label"><?= $info['label'] ?></div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Ver material -->
            <?php if ($matVer): ?>
                <div class="card" style="margin-bottom:20px;border:2px solid var(--primary);">
                    <div class="card-header">
                        <div class="card-title">
                            <?= $tiposInfo[$matVer['tipo']]['emoji'] ?> <?= htmlspecialchars($matVer['titulo']) ?>
                        </div>
                        <div style="display:flex;gap:8px;">
                            <button class="btn btn-sm btn-secondary" onclick="openEditMaterial(<?= htmlspecialchars(json_encode($matVer)) ?>)">✏️ Editar</button>
                            <a href="materiais.php" class="btn btn-sm btn-secondary">✕ Fechar</a>
                        </div>
                    </div>
                    <div style="margin-bottom:12px;">
                        <span class="badge badge-primary"><?= $tiposInfo[$matVer['tipo']]['label'] ?></span>
                        <span style="font-size:12px;color:var(--text-muted);margin-left:8px;">
                            📅 <?= date('d/m/Y', strtotime($matVer['data'])) ?>
                        </span>
                    </div>
                    <?php if ($matVer['link']): ?>
                        <a href="<?= htmlspecialchars($matVer['link']) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-secondary" style="margin-bottom:16px;display:inline-flex;">
                            🔗 Acessar link
                        </a>
                    <?php endif; ?>
                    <?php if ($matVer['conteudo']): ?>
                        <div style="background:var(--bg);border-radius:10px;padding:20px;font-size:14px;line-height:1.8;white-space:pre-wrap;color:var(--text-primary);">
                            <?= htmlspecialchars($matVer['conteudo']) ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Filtros -->
            <div class="card" style="margin-bottom:20px;">
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    <a href="?tipo=todos" class="btn btn-sm <?= $filtroTipo==='todos'?'btn-primary':'btn-secondary' ?>">Todos</a>
                    <?php foreach ($tiposInfo as $key => $info): ?>
                        <a href="?tipo=<?= $key ?>" class="btn btn-sm <?= $filtroTipo===$key?'btn-primary':'btn-secondary' ?>">
                            <?= $info['emoji'] ?> <?= $info['label'] ?>
                        </a>
                    <?php endforeach; ?>
                    <input type="text" id="searchMat" placeholder="🔍 Buscar material..." class="form-control" style="max-width:260px;margin-left:auto;">
                </div>
            </div>

            <!-- Grid de materiais -->
            <?php if (count($materiaisArr) === 0): ?>
                <div class="card">
                    <div class="empty-state">
                        <div class="empty-icon">📚</div>
                        <h3>Nenhum material ainda</h3>
                        <p>Salve resumos, links e anotações para acessar facilmente.</p>
                        <button class="btn btn-primary" style="margin-top:12px" onclick="Modal.open('modalAddMaterial')">+ Adicionar material</button>
                    </div>
                </div>
            <?php else: ?>
                <div class="grid-auto" id="gridMateriais">
                    <?php foreach ($materiaisArr as $m):
                        $info = $tiposInfo[$m['tipo']] ?? $tiposInfo['outro'];
                    ?>
                        <div class="material-card mat-item" data-titulo="<?= strtolower(htmlspecialchars($m['titulo'])) ?>">
                            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px;">
                                <div class="material-icon"><?= $info['emoji'] ?></div>
                                <div style="display:flex;gap:6px;">
                                    <button class="btn-icon" onclick="openEditMaterial(<?= htmlspecialchars(json_encode($m)) ?>)" title="Editar">✏️</button>
                                    <form method="POST" style="display:inline" onsubmit="return confirmDelete()">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= $m['id_material'] ?>">
                                        <button type="submit" class="btn-icon" title="Excluir">🗑️</button>
                                    </form>
                                </div>
                            </div>
                            <div class="material-title"><?= htmlspecialchars($m['titulo']) ?></div>
                            <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
                                <span class="badge" style="background:<?= $info['cor'] ?>22;color:<?= $info['cor'] ?>"><?= $info['label'] ?></span>
                                <span class="material-type">📅 <?= date('d/m/Y', strtotime($m['data'])) ?></span>
                            </div>
                            <?php if ($m['conteudo']): ?>
                                <div style="font-size:13px;color:var(--text-secondary);margin-bottom:12px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;">
                                    <?= htmlspecialchars($m['conteudo']) ?>
                                </div>
                            <?php endif; ?>
                            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                                <a href="?ver=<?= $m['id_material'] ?>" class="btn btn-sm btn-secondary">👁️ Ver</a>
                                <?php if ($m['link']): ?>
                                    <a href="<?= htmlspecialchars($m['link']) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-secondary">🔗 Link</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

        </div>
        <?php include '../includes/footer.php'; ?>
    </div>
</div>

<!-- Modal Adicionar Material -->
<div class="modal-overlay" id="modalAddMaterial">
    <div class="modal modal-lg">
        <div class="modal-header">
            <div class="modal-title">📚 Novo Material</div>
            <button class="modal-close">✕</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Título *</label>
                        <input type="text" name="titulo" class="form-control" placeholder="Nome do material" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tipo</label>
                        <select name="tipo" class="form-control">
                            <option value="resumo">📄 Resumo</option>
                            <option value="link">🔗 Link</option>
                            <option value="pdf">📕 PDF</option>
                            <option value="anotacao">📝 Anotação</option>
                            <option value="outro">📦 Outro</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Link (opcional)</label>
                    <input type="url" name="link" class="form-control" placeholder="https://...">
                </div>
                <div class="form-group">
                    <label class="form-label">Conteúdo / Anotações</label>
                    <textarea name="conteudo" class="form-control" rows="8" placeholder="Digite o conteúdo, resumo ou anotações..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary modal-close">Cancelar</button>
                <button type="submit" class="btn btn-primary">Salvar material</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Editar Material -->
<div class="modal-overlay" id="modalEditMaterial">
    <div class="modal modal-lg">
        <div class="modal-header">
            <div class="modal-title">✏️ Editar Material</div>
            <button class="modal-close">✕</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="editMatId">
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Título *</label>
                        <input type="text" name="titulo" id="editMatTitulo" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tipo</label>
                        <select name="tipo" id="editMatTipo" class="form-control">
                            <option value="resumo">📄 Resumo</option>
                            <option value="link">🔗 Link</option>
                            <option value="pdf">📕 PDF</option>
                            <option value="anotacao">📝 Anotação</option>
                            <option value="outro">📦 Outro</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Link</label>
                    <input type="url" name="link" id="editMatLink" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Conteúdo</label>
                    <textarea name="conteudo" id="editMatConteudo" class="form-control" rows="8"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary modal-close">Cancelar</button>
                <button type="submit" class="btn btn-primary">Salvar</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditMaterial(m) {
    document.getElementById('editMatId').value = m.id_material;
    document.getElementById('editMatTitulo').value = m.titulo;
    document.getElementById('editMatTipo').value = m.tipo;
    document.getElementById('editMatLink').value = m.link || '';
    document.getElementById('editMatConteudo').value = m.conteudo || '';
    Modal.open('modalEditMaterial');
}

document.getElementById('searchMat').addEventListener('input', function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll('.mat-item').forEach(el => {
        el.style.display = el.getAttribute('data-titulo').includes(q) ? '' : 'none';
    });
});
</script>

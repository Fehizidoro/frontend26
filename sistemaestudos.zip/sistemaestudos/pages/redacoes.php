<?php
$pageTitle='Redações';
require_once '../config/conexao.php';
require_once '../includes/header.php';
$uid=(int)$_SESSION['id_usuario'];
$msg='';
$compsNomes=['Norma padrão da língua','Compreensão do tema','Organização das ideias','Coesão textual','Proposta de intervenção'];

if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    if(in_array($action,['add','edit'])){
        $tema=$conn->real_escape_string($_POST['tema']);
        $texto=$conn->real_escape_string($_POST['texto']);
        $cs=[];
        for($i=1;$i<=5;$i++) $cs[]=min(200,max(0,(int)$_POST["competencia$i"]));
        if($action==='add'){
            $st=$conn->prepare("INSERT INTO redacoes (id_usuario,tema,texto,competencia1,competencia2,competencia3,competencia4,competencia5) VALUES (?,?,?,?,?,?,?,?)");
            $st->bind_param('issiiiii',$uid,$tema,$texto,...$cs);
            $st->execute();
            $msg='success|Redação salva!';
        } else {
            $id=(int)$_POST['id'];
            $conn->query("UPDATE redacoes SET tema='$tema',texto='$texto',competencia1={$cs[0]},competencia2={$cs[1]},competencia3={$cs[2]},competencia4={$cs[3]},competencia5={$cs[4]} WHERE id_redacao=$id AND id_usuario=$uid");
            $msg='success|Redação atualizada!';
        }
    }
    if($_POST['action']==='delete'){
        $conn->query("DELETE FROM redacoes WHERE id_redacao=".(int)$_POST['id']." AND id_usuario=$uid");
        $msg='success|Redação excluída.'; header('Location: redacoes.php'); exit;
    }
}

$vId=(int)($_GET['ver']??0);
$vRed=null;
if($vId>0){ $r=$conn->query("SELECT * FROM redacoes WHERE id_redacao=$vId AND id_usuario=$uid"); if($r&&$r->num_rows>0) $vRed=$r->fetch_assoc(); }

$allRed=$conn->query("SELECT * FROM redacoes WHERE id_usuario=$uid ORDER BY data DESC");
$list=[]; while($r=$allRed->fetch_assoc()) $list[]=$r;
$tot=count($list);
$media=$tot>0?round(array_sum(array_column($list,'nota_final'))/$tot):0;
$melhor=$tot>0?max(array_column($list,'nota_final')):0;

$grafL=array_map(fn($r)=>date('d/m',strtotime($r['data'])),array_slice(array_reverse($list),0,10));
$grafD=array_column(array_slice(array_reverse($list),0,10),'nota_final');
?>

<div class="app-wrapper">
<?php include '../includes/menu.php'; ?>
<div class="main-content">

<div class="topbar">
  <button class="menu-toggle" id="menuToggle">☰</button>
  <div class="topbar-left">
    <div class="topbar-page">✍️ Redações ENEM</div>
    <div class="topbar-hint">Escreva, avalie por competências e evolua</div>
  </div>
  <div class="topbar-right">
    <button class="btn btn-primary" onclick="Modal.open('mAdd')">+ Nova redação</button>
    <button class="icon-btn" id="themeBtn" onclick="Theme.toggle()">🌙</button>
  </div>
</div>

<div class="page-content">
<?php if($msg):[$t2,$tx]=explode('|',$msg,2);?>
<script>document.addEventListener('DOMContentLoaded',()=>Toast.show('<?=addslashes($tx)?>','<?=$t2?>'));</script>
<?php endif;?>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(3,1fr)">
  <div class="stat-card anim-up">
    <div class="stat-icon-wrap si-purple">📝</div>
    <div class="stat-num" data-count="<?=$tot?>"><?=$tot?></div>
    <div class="stat-lbl">Redações escritas</div>
  </div>
  <div class="stat-card anim-up">
    <div class="stat-icon-wrap si-cyan">📊</div>
    <div class="stat-num"><?=$media?></div>
    <div class="stat-lbl">Média das notas</div>
    <div class="stat-hint">Máximo: 1000 pts</div>
  </div>
  <div class="stat-card anim-up">
    <div class="stat-icon-wrap si-green">🏆</div>
    <div class="stat-num"><?=$melhor?></div>
    <div class="stat-lbl">Melhor nota</div>
    <div class="stat-hint up"><?=$melhor>=800?'🌟 Excelente!':($melhor>=600?'👍 Bom!':'📈 Continue!')?></div>
  </div>
</div>

<?php if($tot>1):?>
<div class="card anim-up mb-20">
  <div class="card-header">
    <div class="card-title">📈 Evolução das notas</div>
  </div>
  <div class="chart-wrap"><canvas id="chartRed"></canvas></div>
</div>
<?php endif;?>

<!-- Visualizar redação completa -->
<?php if($vRed):?>
<div class="card anim-up mb-20" style="border:2px solid var(--p1);">
  <div class="card-header">
    <div class="card-title">📄 <?=htmlspecialchars($vRed['tema'])?></div>
    <div style="display:flex;gap:8px;">
      <button class="btn btn-ghost btn-sm" onclick="openEditR(<?=htmlspecialchars(json_encode($vRed))?>)">✏️ Editar</button>
      <a href="redacoes.php" class="btn btn-ghost btn-sm">✕ Fechar</a>
    </div>
  </div>
  <div style="color:var(--tx3);font-size:12.5px;margin-bottom:20px;">📅 <?=date('d/m/Y H:i',strtotime($vRed['data']))?></div>
  <div class="comp-grid">
    <?php for($i=1;$i<=5;$i++):
      $n=$vRed["competencia$i"];
      $c=$n>=160?'var(--success)':($n>=120?'var(--warning)':($n>0?'var(--danger)':'var(--tx3)'));
    ?>
    <div class="comp-card">
      <div class="comp-num">C<?=$i?> — <?=$compsNomes[$i-1]?></div>
      <div class="comp-score" style="color:<?=$c?>"><?=$n?></div>
      <div class="comp-max">/ 200 pts</div>
      <div style="margin-top:8px"><div class="progress progress-sm"><div class="progress-fill" style="width:<?=$n/2?>%;background:<?=$c?>"></div></div></div>
    </div>
    <?php endfor;?>
  </div>
  <div class="nota-total-card mt-12">
    <div class="nota-total-num"><?=$vRed['nota_final']?></div>
    <div class="nota-total-label">pontos totais / máx. 1000</div>
  </div>
  <?php if($vRed['texto']):?>
  <div style="margin-top:24px">
    <div style="font-weight:700;font-size:14px;margin-bottom:10px;color:var(--tx1)">📄 Texto da redação:</div>
    <div style="background:var(--bg2);border-radius:12px;padding:20px;font-size:14px;line-height:1.9;color:var(--tx1);white-space:pre-wrap;"><?=htmlspecialchars($vRed['texto'])?></div>
  </div>
  <?php endif;?>
</div>
<?php endif;?>

<!-- Histórico -->
<div class="card anim-up">
  <div class="card-header">
    <div class="card-title">📋 Histórico de redações</div>
  </div>
  <?php if(!$tot):?>
    <div class="empty-state">
      <span class="empty-emoji">✍️</span>
      <div class="empty-title">Nenhuma redação ainda</div>
      <div class="empty-desc">Escreva sua primeira redação e comece a evoluir!</div>
      <button class="btn btn-primary mt-12" onclick="Modal.open('mAdd')">+ Escrever agora</button>
    </div>
  <?php else:?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Data</th><th>Tema</th><th>C1</th><th>C2</th><th>C3</th><th>C4</th><th>C5</th><th>Nota</th><th>Ações</th></tr></thead>
        <tbody>
          <?php foreach($list as $r):
            $n=$r['nota_final'];
            $bc=$n>=800?'green':($n>=500?'orange':'red');
          ?>
          <tr>
            <td style="font-size:12px;color:var(--tx3)"><?=date('d/m/Y',strtotime($r['data']))?></td>
            <td style="font-weight:600;max-width:200px" class="truncate"><?=htmlspecialchars($r['tema'])?></td>
            <td style="text-align:center"><?=$r['competencia1']?></td>
            <td style="text-align:center"><?=$r['competencia2']?></td>
            <td style="text-align:center"><?=$r['competencia3']?></td>
            <td style="text-align:center"><?=$r['competencia4']?></td>
            <td style="text-align:center"><?=$r['competencia5']?></td>
            <td><span class="badge badge-<?=$bc?>" style="font-size:13px;"><?=$n?> pts</span></td>
            <td>
              <div style="display:flex;gap:6px;">
                <a href="?ver=<?=$r['id_redacao']?>" class="action-btn" title="Ver">👁️</a>
                <button class="action-btn" onclick="openEditR(<?=htmlspecialchars(json_encode($r))?>)" title="Editar">✏️</button>
                <form method="POST" style="display:inline" onsubmit="return confirmDel()">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?=$r['id_redacao']?>">
                  <button class="action-btn del" type="submit" title="Excluir">🗑️</button>
                </form>
              </div>
            </td>
          </tr>
          <?php endforeach;?>
        </tbody>
      </table>
    </div>
  <?php endif;?>
</div>

</div></div></div>

<!-- Modal Adicionar -->
<div class="modal-overlay" id="mAdd">
  <div class="modal modal-lg">
    <div class="modal-header">
      <div class="modal-title">✍️ Nova Redação</div>
      <button class="modal-x">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Tema *</label>
          <input type="text" name="tema" class="form-control" placeholder="Ex: Impacto das redes sociais na educação" required autofocus>
        </div>
        <div class="form-group">
          <label class="form-label">Texto da redação</label>
          <textarea name="texto" class="form-control" rows="7" placeholder="Digite sua redação aqui..."></textarea>
        </div>
        <div style="background:var(--bg2);border-radius:14px;padding:18px;margin-bottom:8px;">
          <div style="font-weight:700;font-size:14px;margin-bottom:14px;color:var(--tx1);">📊 Avaliação por competências (0 a 200, múltiplos de 40)</div>
          <div class="comp-grid">
            <?php for($i=1;$i<=5;$i++):?>
            <div class="comp-card">
              <div class="comp-num">C<?=$i?></div>
              <div style="font-size:11px;color:var(--tx3);margin-bottom:10px;"><?=$compsNomes[$i-1]?></div>
              <input type="number" name="competencia<?=$i?>" class="form-control" value="0" min="0" max="200" step="40" onchange="calcT()" style="text-align:center;font-size:20px;font-weight:800;">
            </div>
            <?php endfor;?>
          </div>
          <div style="text-align:center;margin-top:14px;font-size:18px;font-weight:800;color:var(--p1);">
            Total: <span id="totN">0</span> / 1000 pontos
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost modal-x">Cancelar</button>
        <button type="submit" class="btn btn-primary">Salvar redação</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Editar -->
<div class="modal-overlay" id="mEdit">
  <div class="modal modal-lg">
    <div class="modal-header">
      <div class="modal-title">✏️ Editar Redação</div>
      <button class="modal-x">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="eRId">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Tema *</label>
          <input type="text" name="tema" id="eRTema" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Texto</label>
          <textarea name="texto" id="eRTexto" class="form-control" rows="6"></textarea>
        </div>
        <div class="form-row-3" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;">
          <?php for($i=1;$i<=5;$i++):?>
          <div>
            <label class="form-label" style="font-size:11px;">C<?=$i?> — <?=$compsNomes[$i-1]?></label>
            <input type="number" name="competencia<?=$i?>" id="eC<?=$i?>" class="form-control" min="0" max="200" step="40" onchange="calcTE()">
          </div>
          <?php endfor;?>
        </div>
        <div style="text-align:center;margin-top:12px;font-size:17px;font-weight:800;color:var(--p1);">
          Total: <span id="totNE">0</span> / 1000
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost modal-x">Cancelar</button>
        <button type="submit" class="btn btn-primary">Salvar</button>
      </div>
    </form>
  </div>
</div>

<?php if($tot>1):?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('chartRed').getContext('2d'),{
  type:'line',
  data:{labels:<?=json_encode($grafL)?>,datasets:[{label:'Nota',data:<?=json_encode($grafD)?>,borderColor:'#7c3aed',backgroundColor:'rgba(124,58,237,0.1)',borderWidth:3,tension:0.4,fill:true,pointRadius:5,pointBackgroundColor:'#7c3aed'}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{min:0,max:1000,grid:{color:'rgba(0,0,0,0.05)'},ticks:{color:'#9297b8',font:{size:11}}},x:{grid:{display:false},ticks:{color:'#9297b8',font:{size:11}}}}}
});
</script>
<?php endif;?>

<?php include '../includes/footer.php'; ?>
<script>
function calcT(){
  let s=0;
  document.querySelectorAll('#mAdd input[name^="competencia"]').forEach(i=>s+=parseInt(i.value)||0);
  document.getElementById('totN').textContent=Math.min(1000,s);
}
function calcTE(){
  let s=0;
  for(let i=1;i<=5;i++) s+=parseInt(document.getElementById('eC'+i).value)||0;
  document.getElementById('totNE').textContent=Math.min(1000,s);
}
function openEditR(r){
  document.getElementById('eRId').value=r.id_redacao;
  document.getElementById('eRTema').value=r.tema;
  document.getElementById('eRTexto').value=r.texto||'';
  for(let i=1;i<=5;i++) document.getElementById('eC'+i).value=r['competencia'+i]||0;
  calcTE(); Modal.open('mEdit');
}
</script>

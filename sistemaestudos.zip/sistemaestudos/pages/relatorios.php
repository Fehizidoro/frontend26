<?php
$pageTitle='Relatórios';
require_once '../config/conexao.php';
require_once '../includes/header.php';
$uid=(int)$_SESSION['id_usuario'];

$per=(int)($_GET['periodo']??30);
$ini=date('Y-m-d',strtotime("-$per days"));

/* Horas por matéria */
$qHM=$conn->query("SELECT m.nome,m.cor,SUM(c.duracao) min FROM cronograma c LEFT JOIN materias m ON c.id_materia=m.id_materia WHERE c.id_usuario=$uid AND c.status='concluido' AND c.data>='$ini' GROUP BY m.id_materia ORDER BY min DESC");
$hmA=[]; while($r=$qHM->fetch_assoc()) $hmA[]=$r;
$totalMin=array_sum(array_column($hmA,'min'));
$totalH=round($totalMin/60,1);

/* Tarefas */
$qT=$conn->query("SELECT status,COUNT(*) c FROM tarefas WHERE id_usuario=$uid GROUP BY status");
$ts=['pendente'=>0,'concluida'=>0]; while($r=$qT->fetch_assoc()) $ts[$r['status']]=$r['c'];
$totT=$ts['pendente']+$ts['concluida'];

/* Redações */
$qR=$conn->query("SELECT DATE_FORMAT(data,'%d/%m') l,nota_final FROM redacoes WHERE id_usuario=$uid ORDER BY data ASC LIMIT 15");
$rA=[]; while($r=$qR->fetch_assoc()) $rA[]=$r;
$totR=count($rA);
$medR=$totR>0?round(array_sum(array_column($rA,'nota_final'))/$totR):0;

/* Aulas */
$ass=(int)$conn->query("SELECT COUNT(*) c FROM aulas WHERE id_usuario=$uid AND status='assistida'")->fetch_assoc()['c'];
$mats=(int)$conn->query("SELECT COUNT(*) c FROM materiais WHERE id_usuario=$uid")->fetch_assoc()['c'];

/* Diário 30 dias */
$dl30=[]; $dd30=[];
for($i=29;$i>=0;$i--){
    $d=date('Y-m-d',strtotime("-$i days"));
    $dl30[]=date('d/m',strtotime("-$i days"));
    $m=(int)$conn->query("SELECT COALESCE(SUM(duracao),0) s FROM cronograma WHERE id_usuario=$uid AND data='$d' AND status='concluido'")->fetch_assoc()['s'];
    $dd30[]=round($m/60,1);
}

/* Por dia da semana */
$dsn=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
$dsd=array_fill(0,7,0);
$qDW=$conn->query("SELECT DAYOFWEEK(data)-1 d,SUM(duracao) m FROM cronograma WHERE id_usuario=$uid AND status='concluido' GROUP BY d");
while($r=$qDW->fetch_assoc()) $dsd[$r['d']]=round($r['m']/60,1);

/* Médias competências */
$compM=[];
for($i=1;$i<=5;$i++){
    $r=$conn->query("SELECT COALESCE(AVG(competencia$i),0) avg FROM redacoes WHERE id_usuario=$uid")->fetch_assoc();
    $compM[]=round($r['avg'],1);
}
?>

<div class="app-wrapper">
<?php include '../includes/menu.php'; ?>
<div class="main-content">

<div class="topbar">
  <button class="menu-toggle" id="menuToggle">☰</button>
  <div class="topbar-left">
    <div class="topbar-page">📊 Relatórios de Desempenho</div>
    <div class="topbar-hint">Acompanhe sua evolução e identifique oportunidades</div>
  </div>
  <div class="topbar-right">
    <select class="form-control" style="width:auto;padding:8px 12px;" onchange="location='?periodo='+this.value">
      <?php foreach([7=>'7 dias',15=>'15 dias',30=>'30 dias',90=>'3 meses'] as $v=>$l):?>
        <option value="<?=$v?>" <?=$per==$v?'selected':''?>><?=$l?></option>
      <?php endforeach;?>
    </select>
    <button class="icon-btn" id="themeBtn" onclick="Theme.toggle()">🌙</button>
  </div>
</div>

<div class="page-content">

<!-- Stats -->
<div class="stats-grid anim-up">
  <div class="stat-card">
    <div class="stat-icon-wrap si-green">⏱️</div>
    <div class="stat-num"><?=$totalH?>h</div>
    <div class="stat-lbl">Horas estudadas</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon-wrap si-purple">✅</div>
    <div class="stat-num" data-count="<?=$ts['concluida']?>"><?=$ts['concluida']?></div>
    <div class="stat-lbl">Tarefas concluídas</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon-wrap si-orange">⏳</div>
    <div class="stat-num" data-count="<?=$ts['pendente']?>"><?=$ts['pendente']?></div>
    <div class="stat-lbl">Tarefas pendentes</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon-wrap si-pink">✍️</div>
    <div class="stat-num" data-count="<?=$totR?>"><?=$totR?></div>
    <div class="stat-lbl">Redações</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon-wrap si-cyan">📊</div>
    <div class="stat-num"><?=$medR?></div>
    <div class="stat-lbl">Média nas redações</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon-wrap si-blue">🎬</div>
    <div class="stat-num" data-count="<?=$ass?>"><?=$ass?></div>
    <div class="stat-lbl">Aulas assistidas</div>
  </div>
</div>

<!-- Gráficos linha 1 -->
<div class="grid-2 mb-20 anim-up">
  <div class="card">
    <div class="card-header"><div class="card-title">📈 Horas estudadas por dia</div></div>
    <div class="chart-wrap"><canvas id="cDiario"></canvas></div>
  </div>
  <div class="card">
    <div class="card-header"><div class="card-title">📅 Horas por dia da semana</div></div>
    <div class="chart-wrap"><canvas id="cSemana"></canvas></div>
  </div>
</div>

<!-- Gráficos linha 2 -->
<div class="grid-2 mb-20 anim-up">
  <div class="card">
    <div class="card-header"><div class="card-title">📚 Horas por matéria</div></div>
    <?php if(!count($hmA)):?>
      <div class="empty-state" style="padding:30px"><span class="empty-emoji">📚</span><div class="empty-desc">Nenhuma sessão concluída ainda.</div></div>
    <?php else:?>
      <div class="chart-wrap chart-wrap-sm mb-16"><canvas id="cMat"></canvas></div>
      <div style="display:flex;flex-direction:column;gap:10px;">
        <?php foreach($hmA as $m):$pct=$totalMin>0?round(($m['min']/$totalMin)*100):0;?>
          <div style="display:flex;align-items:center;gap:10px;">
            <div style="width:10px;height:10px;border-radius:3px;background:<?=htmlspecialchars($m['cor']??'#7c3aed')?>;flex-shrink:0"></div>
            <span style="flex:1;font-size:13px;font-weight:500"><?=htmlspecialchars($m['nome']??'Sem matéria')?></span>
            <strong style="font-size:13px;color:var(--tx1)"><?=round($m['min']/60,1)?>h</strong>
            <div class="progress" style="width:80px;"><div class="progress-fill" style="width:<?=$pct?>%;background:<?=htmlspecialchars($m['cor']??'#7c3aed')?>"></div></div>
          </div>
        <?php endforeach;?>
      </div>
    <?php endif;?>
  </div>
  <div class="card">
    <div class="card-header"><div class="card-title">✅ Tarefas por status</div></div>
    <?php if(!$totT):?>
      <div class="empty-state" style="padding:30px"><span class="empty-emoji">✅</span><div class="empty-desc">Nenhuma tarefa ainda.</div></div>
    <?php else:?>
      <div class="chart-wrap chart-wrap-sm mb-16"><canvas id="cTar"></canvas></div>
      <div style="display:flex;justify-content:center;gap:24px;font-size:13.5px;">
        <div style="display:flex;align-items:center;gap:6px;"><div style="width:12px;height:12px;border-radius:3px;background:#10b981"></div>Concluídas: <strong><?=$ts['concluida']?></strong></div>
        <div style="display:flex;align-items:center;gap:6px;"><div style="width:12px;height:12px;border-radius:3px;background:#f59e0b"></div>Pendentes: <strong><?=$ts['pendente']?></strong></div>
      </div>
    <?php endif;?>
  </div>
</div>

<?php if($totR>0):?>
<div class="grid-2 anim-up">
  <div class="card">
    <div class="card-header"><div class="card-title">📝 Evolução nas redações</div></div>
    <div class="chart-wrap"><canvas id="cRed"></canvas></div>
  </div>
  <div class="card">
    <div class="card-header"><div class="card-title">🎯 Média por competência ENEM</div></div>
    <div class="chart-wrap"><canvas id="cComp"></canvas></div>
  </div>
</div>
<?php endif;?>

</div></div></div>

<?php include '../includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const dk=()=>document.documentElement.getAttribute('data-theme')==='dark';
const gc=()=>dk()?'rgba(255,255,255,0.06)':'rgba(0,0,0,0.05)';
const tc='#9297b8';

/* Diário */
new Chart(document.getElementById('cDiario').getContext('2d'),{
  type:'bar',
  data:{labels:<?=json_encode(array_slice($dl30,-14))?>,datasets:[{data:<?=json_encode(array_slice($dd30,-14))?>,backgroundColor:'rgba(124,58,237,0.65)',borderColor:'#7c3aed',borderWidth:2,borderRadius:8}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,grid:{color:gc()},ticks:{color:tc,font:{size:10}}},x:{grid:{display:false},ticks:{color:tc,font:{size:10}}}}}
});
/* Semana radar */
new Chart(document.getElementById('cSemana').getContext('2d'),{
  type:'radar',
  data:{labels:<?=json_encode($dsn)?>,datasets:[{data:<?=json_encode($dsd)?>,backgroundColor:'rgba(6,182,212,0.15)',borderColor:'#06b6d4',borderWidth:2,pointBackgroundColor:'#06b6d4'}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{r:{beginAtZero:true,grid:{color:gc()},ticks:{color:tc,backdropColor:'transparent',font:{size:10}},pointLabels:{color:tc,font:{size:11}}}}}
});
<?php if(count($hmA)):?>
/* Matérias doughnut */
new Chart(document.getElementById('cMat').getContext('2d'),{
  type:'doughnut',
  data:{labels:<?=json_encode(array_column($hmA,'nome'))?>,datasets:[{data:<?=json_encode(array_map(fn($h)=>round($h['min']/60,1),$hmA))?>,backgroundColor:<?=json_encode(array_column($hmA,'cor'))?>,borderWidth:3,borderColor:dk()?'#13102a':'#fff'}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},cutout:'60%'}
});
<?php endif;?>
<?php if($totT):?>
/* Tarefas */
new Chart(document.getElementById('cTar').getContext('2d'),{
  type:'doughnut',
  data:{labels:['Concluídas','Pendentes'],datasets:[{data:[<?=$ts['concluida']?>,<?=$ts['pendente']?>],backgroundColor:['#10b981','#f59e0b'],borderWidth:3,borderColor:dk()?'#13102a':'#fff'}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},cutout:'65%'}
});
<?php endif;?>
<?php if($totR>0):?>
/* Redações */
new Chart(document.getElementById('cRed').getContext('2d'),{
  type:'line',
  data:{labels:<?=json_encode(array_column($rA,'l'))?>,datasets:[{data:<?=json_encode(array_column($rA,'nota_final'))?>,borderColor:'#ec4899',backgroundColor:'rgba(236,72,153,0.1)',borderWidth:3,tension:0.4,fill:true,pointRadius:5,pointBackgroundColor:'#ec4899'}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{min:0,max:1000,grid:{color:gc()},ticks:{color:tc,font:{size:10}}},x:{grid:{display:false},ticks:{color:tc,font:{size:10}}}}}
});
/* Competências */
new Chart(document.getElementById('cComp').getContext('2d'),{
  type:'radar',
  data:{labels:['C1 — Língua','C2 — Tema','C3 — Organização','C4 — Coesão','C5 — Intervenção'],datasets:[{data:<?=json_encode($compM)?>,backgroundColor:'rgba(124,58,237,0.15)',borderColor:'#7c3aed',borderWidth:2,pointBackgroundColor:'#7c3aed'}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{r:{min:0,max:200,grid:{color:gc()},ticks:{color:tc,backdropColor:'transparent',font:{size:9}},pointLabels:{color:tc,font:{size:10}}}}}
});
<?php endif;?>
</script>

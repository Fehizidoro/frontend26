<?php
$pageTitle = 'Tarefas';
require_once '../config/conexao.php';
require_once '../includes/header.php';
$uid = (int)$_SESSION['id_usuario'];
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
        $d = $conn->real_escape_string($_POST['descricao']);
        $p = $conn->real_escape_string($_POST['prioridade']);
        $pr= $_POST['prazo'] ? "'".$conn->real_escape_string($_POST['prazo'])."'" : 'NULL';
        $conn->query("INSERT INTO tarefas (id_usuario,descricao,prioridade,prazo) VALUES ($uid,'$d','$p',$pr)");
        $msg='success|Tarefa adicionada!';
    }
    if ($action === 'edit') {
        $id=$_POST['id']; $d=$conn->real_escape_string($_POST['descricao']);
        $p=$conn->real_escape_string($_POST['prioridade']);
        $pr=$_POST['prazo']?"'".$conn->real_escape_string($_POST['prazo'])."'":'NULL';
        $conn->query("UPDATE tarefas SET descricao='$d',prioridade='$p',prazo=$pr WHERE id_tarefa=$id AND id_usuario=$uid");
        $msg='success|Tarefa atualizada!';
    }
    if ($action === 'delete') {
        $conn->query("DELETE FROM tarefas WHERE id_tarefa=".(int)$_POST['id']." AND id_usuario=$uid");
        $msg='success|Tarefa excluída.';
    }
    if ($action === 'toggle') {
        $conn->query("UPDATE tarefas SET status=IF(status='pendente','concluida','pendente') WHERE id_tarefa=".(int)$_POST['id']." AND id_usuario=$uid");
        header('Location: tarefas.php'.($_GET['f']??''?'?f='.$_GET['f']:'')); exit;
    }
    if ($action === 'clear') {
        $conn->query("DELETE FROM tarefas WHERE id_usuario=$uid AND status='concluida'");
        $msg='success|Concluídas removidas!';
    }
}

$f = $_GET['f'] ?? 'todas';
$where = "WHERE id_usuario=$uid";
if ($f==='pendente')  $where.=" AND status='pendente'";
if ($f==='concluida') $where.=" AND status='concluida'";
if ($f==='alta')      $where.=" AND prioridade='alta' AND status='pendente'";

$rows = $conn->query("SELECT * FROM tarefas $where ORDER BY FIELD(status,'pendente','concluida'),FIELD(prioridade,'alta','media','baixa'),prazo ASC");
$list=[]; while($r=$rows->fetch_assoc()) $list[]=$r;

$tP=(int)$conn->query("SELECT COUNT(*) c FROM tarefas WHERE id_usuario=$uid AND status='pendente'")->fetch_assoc()['c'];
$tC=(int)$conn->query("SELECT COUNT(*) c FROM tarefas WHERE id_usuario=$uid AND status='concluida'")->fetch_assoc()['c'];
$tA=(int)$conn->query("SELECT COUNT(*) c FROM tarefas WHERE id_usuario=$uid AND status='pendente' AND prioridade='alta'")->fetch_assoc()['c'];
$tot=$tP+$tC; $pg=$tot>0?round($tC/$tot*100):0;
?>

<div class="app-wrapper">
<?php include '../includes/menu.php'; ?>
<div class="main-content">

<div class="topbar">
  <button class="menu-toggle" id="menuToggle">☰</button>
  <div class="topbar-left">
    <div class="topbar-page">✅ Lista de Tarefas</div>
    <div class="topbar-hint">Gerencie suas tarefas e objetivos diários</div>
  </div>
  <div class="topbar-right">
    <button class="btn btn-primary" onclick="Modal.open('mAdd')">+ Nova tarefa</button>
    <button class="icon-btn" id="themeBtn" onclick="Theme.toggle()">🌙</button>
  </div>
</div>

<div class="page-content">
<?php if($msg):[$t2,$tx]=explode('|',$msg,2);?>
<script>document.addEventListener('DOMContentLoaded',()=>Toast.show('<?=addslashes($tx)?>','<?=$t2?>'));</script>
<?php endif;?>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr)">
  <div class="stat-card anim-up">
    <div class="stat-icon-wrap si-purple">📋</div>
    <div class="stat-num" data-count="<?=$tot?>"><?=$tot?></div>
    <div class="stat-lbl">Total</div>
  </div>
  <div class="stat-card anim-up">
    <div class="stat-icon-wrap si-orange">⏳</div>
    <div class="stat-num" data-count="<?=$tP?>"><?=$tP?></div>
    <div class="stat-lbl">Pendentes</div>
  </div>
  <div class="stat-card anim-up">
    <div class="stat-icon-wrap si-green">✅</div>
    <div class="stat-num" data-count="<?=$tC?>"><?=$tC?></div>
    <div class="stat-lbl">Concluídas</div>
  </div>
  <div class="stat-card anim-up">
    <div class="stat-icon-wrap si-red">🔴</div>
    <div class="stat-num" data-count="<?=$tA?>"><?=$tA?></div>
    <div class="stat-lbl">Alta prioridade</div>
  </div>
</div>

<?php if($tot>0):?>
<div class="card anim-up mb-20">
  <div class="card-header">
    <div class="card-title">📈 Progresso geral</div>
    <span class="badge badge-purple"><?=$pg?>% concluído</span>
  </div>
  <div style="font-size:13px;color:var(--tx3);margin-bottom:10px;"><?=$tC?> de <?=$tot?> tarefas concluídas</div>
  <div class="progress" style="height:10px;"><div class="progress-fill" style="width:<?=$pg?>%"></div></div>
</div>
<?php endif;?>

<!-- Filtros -->
<div class="card anim-up mb-20">
  <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
    <a href="?f=todas"    class="btn btn-sm <?=$f==='todas'?'btn-primary':'btn-ghost'?>">Todas (<?=$tot?>)</a>
    <a href="?f=pendente" class="btn btn-sm <?=$f==='pendente'?'btn-primary':'btn-ghost'?>">⏳ Pendentes</a>
    <a href="?f=concluida"class="btn btn-sm <?=$f==='concluida'?'btn-primary':'btn-ghost'?>">✅ Concluídas</a>
    <a href="?f=alta"     class="btn btn-sm <?=$f==='alta'?'btn-danger':'btn-ghost'?>">🔴 Alta prior.</a>
    <input type="text" id="searchT" placeholder="🔍 Buscar..." class="form-control" style="max-width:240px;margin-left:auto;">
    <?php if($tC>0):?>
    <form method="POST" onsubmit="return confirm('Remover todas concluídas?')">
      <input type="hidden" name="action" value="clear">
      <button class="btn btn-danger btn-sm">🗑️ Limpar concluídas</button>
    </form>
    <?php endif;?>
  </div>
</div>

<!-- Lista -->
<div class="card anim-up">
  <?php if(!count($list)):?>
    <div class="empty-state">
      <span class="empty-emoji">🎉</span>
      <div class="empty-title"><?=$f==='todas'?'Nenhuma tarefa':'Nada aqui'?></div>
      <div class="empty-desc"><?=$f==='todas'?'Adicione tarefas para começar!':'Tente outro filtro.'?></div>
      <?php if($f==='todas'):?><button class="btn btn-primary mt-12" onclick="Modal.open('mAdd')">+ Adicionar</button><?php endif;?>
    </div>
  <?php else: foreach($list as $t):
      $pc=['alta'=>'red','media'=>'orange','baixa'=>'green'][$t['prioridade']];
      $venc=$t['prazo']&&$t['prazo']<date('Y-m-d')&&$t['status']==='pendente';
  ?>
    <div class="task-row task-item" data-search="<?=strtolower(htmlspecialchars($t['descricao']))?>">
      <form method="POST" style="display:contents">
        <input type="hidden" name="action" value="toggle">
        <input type="hidden" name="id" value="<?=$t['id_tarefa']?>">
        <button type="submit" class="task-checkbox <?=$t['status']==='concluida'?'done':''?>" title="Marcar">
          <?=$t['status']==='concluida'?'✓':''?>
        </button>
      </form>
      <div style="flex:1;min-width:0;">
        <div class="task-text <?=$t['status']==='concluida'?'done':''?>" style="font-size:14px;font-weight:500;">
          <?=htmlspecialchars($t['descricao'])?>
        </div>
        <div style="display:flex;align-items:center;gap:8px;margin-top:4px;flex-wrap:wrap;">
          <span class="badge badge-<?=$pc?>"><?=ucfirst($t['prioridade'])?></span>
          <?php if($t['prazo']):?>
            <span style="font-size:11.5px;color:<?=$venc?'var(--danger)':'var(--tx3)'>">
              <?=$venc?'⚠️ Vencida: ':'📅 '?><?=date('d/m/Y',strtotime($t['prazo']))?>
            </span>
          <?php endif;?>
        </div>
      </div>
      <div style="display:flex;gap:6px;">
        <button class="action-btn" onclick="openEdit(<?=htmlspecialchars(json_encode($t))?>)" title="Editar">✏️</button>
        <form method="POST" style="display:inline" onsubmit="return confirmDel()">
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="id" value="<?=$t['id_tarefa']?>">
          <button class="action-btn del" type="submit" title="Excluir">🗑️</button>
        </form>
      </div>
    </div>
  <?php endforeach; endif;?>
</div>

</div></div></div>

<!-- Modal Adicionar -->
<div class="modal-overlay" id="mAdd">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">✅ Nova Tarefa</div>
      <button class="modal-x">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Descrição *</label>
          <input type="text" name="descricao" class="form-control" placeholder="Ex: Fazer lista de exercícios" required autofocus>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Prioridade</label>
            <select name="prioridade" class="form-control">
              <option value="baixa">🟢 Baixa</option>
              <option value="media" selected>🟡 Média</option>
              <option value="alta">🔴 Alta</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Prazo</label>
            <input type="date" name="prazo" class="form-control">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost modal-x">Cancelar</button>
        <button type="submit" class="btn btn-primary">Salvar tarefa</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Editar -->
<div class="modal-overlay" id="mEdit">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">✏️ Editar Tarefa</div>
      <button class="modal-x">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="eId">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Descrição *</label>
          <input type="text" name="descricao" id="eDesc" class="form-control" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Prioridade</label>
            <select name="prioridade" id="ePrio" class="form-control">
              <option value="baixa">🟢 Baixa</option>
              <option value="media">🟡 Média</option>
              <option value="alta">🔴 Alta</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Prazo</label>
            <input type="date" name="prazo" id="ePrazo" class="form-control">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost modal-x">Cancelar</button>
        <button type="submit" class="btn btn-primary">Salvar</button>
      </div>
    </form>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
<script>
function openEdit(t){
  document.getElementById('eId').value=t.id_tarefa;
  document.getElementById('eDesc').value=t.descricao;
  document.getElementById('ePrio').value=t.prioridade;
  document.getElementById('ePrazo').value=t.prazo||'';
  Modal.open('mEdit');
}
filterList('searchT','.task-item');
</script>

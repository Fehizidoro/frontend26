<?php
require_once 'includes/auth.php';
require_once 'includes/conexao.php';
requireLogin();

$pageTitle = 'Atividades';
$cssPath = '';
$mensagem = '';
$tipo_msg = '';

// Verifica se tabela entregas existe
$tbl = $conn->query("SHOW TABLES LIKE 'entregas'");
$tem_entregas = ($tbl && $tbl->num_rows > 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'criar' && (isProfessor() || isAdmin())) {
        $titulo     = trim($_POST['titulo'] ?? '');
        $descricao  = trim($_POST['descricao'] ?? '');
        $prazo      = $_POST['prazo'] ?? '';
        $turma      = trim($_POST['turma'] ?? '');
        $criado_por = $_SESSION['usuario_id'];

        if (empty($titulo) || empty($descricao) || empty($prazo) || empty($turma)) {
            $mensagem = 'Preencha todos os campos.'; $tipo_msg = 'error';
        } else {
            $stmt = $conn->prepare("INSERT INTO atividades (titulo, descricao, prazo, turma, criado_por) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssi", $titulo, $descricao, $prazo, $turma, $criado_por);
            if ($stmt->execute()) { $mensagem = 'Atividade cadastrada!'; $tipo_msg = 'success'; }
            else { $mensagem = 'Erro: ' . $conn->error; $tipo_msg = 'error'; }
            $stmt->close();
        }
    }

    if ($acao === 'editar' && (isProfessor() || isAdmin())) {
        $id = (int)($_POST['id'] ?? 0);
        $titulo    = trim($_POST['titulo'] ?? '');
        $descricao = trim($_POST['descricao'] ?? '');
        $prazo     = $_POST['prazo'] ?? '';
        $turma     = trim($_POST['turma'] ?? '');
        if ($id && !empty($titulo) && !empty($prazo) && !empty($turma)) {
            $stmt = $conn->prepare("UPDATE atividades SET titulo=?, descricao=?, prazo=?, turma=? WHERE id=?");
            $stmt->bind_param("ssssi", $titulo, $descricao, $prazo, $turma, $id);
            if ($stmt->execute()) { $mensagem = 'Atualizado!'; $tipo_msg = 'success'; }
            $stmt->close();
        }
    }

    if ($acao === 'excluir' && (isProfessor() || isAdmin())) {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $stmt = $conn->prepare("DELETE FROM atividades WHERE id=?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) { $mensagem = 'Excluído.'; $tipo_msg = 'success'; }
            $stmt->close();
        }
    }

    // Aluno envia arquivo
    if ($acao === 'anexar' && isAluno()) {
        $id_atv  = (int)($_POST['id_atividade'] ?? 0);
        $id_aluno = $_SESSION['usuario_id'];

        if ($id_atv && isset($_FILES['arquivo']) && $_FILES['arquivo']['error'] === 0) {
            $ext = strtolower(pathinfo($_FILES['arquivo']['name'], PATHINFO_EXTENSION));
            $permitidos = ['pdf','doc','docx','jpg','jpeg','png','zip','txt'];
            if (!in_array($ext, $permitidos)) {
                $mensagem = 'Tipo não permitido. Use: pdf, doc, docx, jpg, png, zip.'; $tipo_msg = 'error';
            } elseif ($_FILES['arquivo']['size'] > 10 * 1024 * 1024) {
                $mensagem = 'Arquivo muito grande (máx 10MB).'; $tipo_msg = 'error';
            } else {
                if (!is_dir(__DIR__ . '/uploads')) mkdir(__DIR__ . '/uploads', 0755, true);
                $novo = 'atv' . $id_atv . '_aluno' . $id_aluno . '_' . time() . '.' . $ext;
                if (move_uploaded_file($_FILES['arquivo']['tmp_name'], __DIR__ . '/uploads/' . $novo)) {
                    if ($tem_entregas) {
                        // Remove entrega anterior do mesmo aluno para essa atividade
                        $stmt = $conn->prepare("DELETE FROM entregas WHERE id_atividade=? AND id_aluno=?");
                        $stmt->bind_param("ii", $id_atv, $id_aluno);
                        $stmt->execute(); $stmt->close();
                        // Insere nova entrega
                        $stmt = $conn->prepare("INSERT INTO entregas (id_atividade, id_aluno, arquivo) VALUES (?,?,?)");
                        $stmt->bind_param("iis", $id_atv, $id_aluno, $novo);
                        $stmt->execute(); $stmt->close();
                    }
                    $mensagem = '✓ Arquivo enviado com sucesso!'; $tipo_msg = 'success';
                } else {
                    $mensagem = 'Erro ao salvar arquivo.'; $tipo_msg = 'error';
                }
            }
        } else {
            $mensagem = 'Selecione um arquivo.'; $tipo_msg = 'error';
        }
    }
}

// Buscar atividades
$filtro_turma = trim($_GET['turma'] ?? '');
$filtro_prazo = $_GET['prazo'] ?? '';
$where = []; $params = []; $types = '';
if ($filtro_turma) { $where[] = "a.turma = ?"; $params[] = $filtro_turma; $types .= 's'; }
if ($filtro_prazo === 'pendentes') { $where[] = "a.prazo >= CURDATE()"; }
$where_sql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

$stmt = $conn->prepare("SELECT a.*, u.nome as professor_nome FROM atividades a LEFT JOIN usuarios u ON a.criado_por = u.id" . $where_sql . " ORDER BY a.prazo ASC");
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$atividades = $stmt->get_result();
$stmt->close();

$editando = null;
$acao_get = $_GET['acao'] ?? '';
if ($acao_get === 'editar' && (isProfessor() || isAdmin())) {
    $id_edit = (int)($_GET['id'] ?? 0);
    $stmt = $conn->prepare("SELECT * FROM atividades WHERE id=?");
    $stmt->bind_param("i", $id_edit);
    $stmt->execute();
    $editando = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

function prazoInfo($prazo) {
    $diff = (strtotime($prazo) - time()) / 86400;
    if ($diff < 0)  return ['class'=>'prazo-urgente','label'=>'⛔ Expirado'];
    if ($diff < 2)  return ['class'=>'prazo-urgente','label'=>'🔴 Urgente'];
    if ($diff <= 7) return ['class'=>'prazo-breve',  'label'=>'🟡 Em breve'];
    return ['class'=>'prazo-ok','label'=>'🟢 No prazo'];
}

include 'includes/header.php';
?>

<div class="page-header">
  <div><h2>📚 Atividades</h2><p>Tarefas e trabalhos</p></div>
  <?php if (isProfessor() || isAdmin()): ?>
  <a href="atividades.php?acao=nova" class="btn btn-primary">+ Nova Atividade</a>
  <?php endif; ?>
</div>

<?php if ($mensagem): ?>
<div class="alert alert-<?= $tipo_msg==='success'?'success':'error' ?>">
  <?= $tipo_msg==='success'?'✓':'⚠' ?> <?= sanitize($mensagem) ?>
</div>
<?php endif; ?>

<!-- Formulário criar/editar -->
<?php if ((isProfessor()||isAdmin()) && ($acao_get==='nova'||$acao_get==='editar')): ?>
<div class="card" style="margin-bottom:2rem;">
  <div class="card-header"><h3 style="margin:0;"><?= $editando?'✏️ Editar':'+ Nova Atividade' ?></h3></div>
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="acao" value="<?= $editando?'editar':'criar' ?>">
      <?php if ($editando): ?><input type="hidden" name="id" value="<?= $editando['id'] ?>"><?php endif; ?>
      <div class="form-group">
        <label class="form-label">Título <span class="req">*</span></label>
        <input type="text" name="titulo" class="form-control" value="<?= sanitize($editando['titulo']??'') ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Descrição <span class="req">*</span></label>
        <textarea name="descricao" class="form-control" rows="4" required><?= sanitize($editando['descricao']??'') ?></textarea>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Prazo <span class="req">*</span></label>
          <input type="date" name="prazo" class="form-control" value="<?= $editando['prazo']??'' ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Turma <span class="req">*</span></label>
          <select name="turma" class="form-control" required>
            <option value="">Selecione...</option>
            <?php foreach(['1º A','1º B','2º A','2º B','3º A','3º B'] as $tf): ?>
            <option value="<?= $tf ?>" <?= ($editando['turma']??'')===$tf?'selected':'' ?>><?= $tf ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div style="display:flex;gap:.75rem;">
        <button type="submit" class="btn btn-primary"><?= $editando?'💾 Salvar':'📌 Cadastrar' ?></button>
        <a href="atividades.php" class="btn btn-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- Filtros -->
<div class="card" style="margin-bottom:1.5rem;">
  <div class="card-body" style="padding:1rem 1.5rem;">
    <form method="GET" style="display:flex;gap:.75rem;align-items:center;flex-wrap:wrap;">
      <label style="font-size:.875rem;font-weight:500;">Filtrar:</label>
      <select name="turma" class="form-control" style="width:auto;">
        <option value="">Todas as turmas</option>
        <?php foreach(['1º A','1º B','2º A','2º B','3º A','3º B'] as $tf): ?>
        <option value="<?= $tf ?>" <?= $filtro_turma===$tf?'selected':'' ?>><?= $tf ?></option>
        <?php endforeach; ?>
      </select>
      <select name="prazo" class="form-control" style="width:auto;">
        <option value="">Todas</option>
        <option value="pendentes" <?= $filtro_prazo==='pendentes'?'selected':'' ?>>Pendentes</option>
      </select>
      <button type="submit" class="btn btn-secondary btn-sm">Filtrar</button>
      <?php if ($filtro_turma||$filtro_prazo): ?>
      <a href="atividades.php" class="btn btn-secondary btn-sm">✕ Limpar</a>
      <?php endif; ?>
    </form>
  </div>
</div>

<!-- Lista -->
<?php if (!$atividades||$atividades->num_rows===0): ?>
<div class="empty-state">
  <div class="empty-icon">📂</div>
  <h3>Nenhuma atividade encontrada</h3>
</div>
<?php else: ?>
<div class="item-list">
  <?php while($atv=$atividades->fetch_assoc()):
    $pi = prazoInfo($atv['prazo']);
  ?>
  <div class="item-card teal">
    <div class="item-title"><?= sanitize($atv['titulo']) ?></div>
    <div class="item-meta">
      <span>🏫 <strong><?= sanitize($atv['turma']) ?></strong></span>
      <span>👤 <?= sanitize($atv['professor_nome']??'Professor') ?></span>
      <span class="<?= $pi['class'] ?>">📅 <?= date('d/m/Y',strtotime($atv['prazo'])) ?> — <?= $pi['label'] ?></span>
    </div>
    <div class="item-body"><?= nl2br(sanitize($atv['descricao'])) ?></div>

    <!-- ALUNO: enviar arquivo -->
    <?php if (isAluno()): ?>
    <?php
    $minha_entrega = null;
    if ($tem_entregas) {
        $id_aluno = $_SESSION['usuario_id'];
        $se = $conn->prepare("SELECT * FROM entregas WHERE id_atividade=? AND id_aluno=? ORDER BY data_envio DESC LIMIT 1");
        $se->bind_param("ii", $atv['id'], $id_aluno);
        $se->execute();
        $minha_entrega = $se->get_result()->fetch_assoc();
        $se->close();
    }
    ?>
    <div style="margin-top:1rem; padding:1rem; background:var(--gray-50); border-radius:8px; border:1px dashed var(--gray-200);">
      <?php if ($minha_entrega): ?>
      <div style="color:var(--green); font-size:.875rem; margin-bottom:.75rem;">
        ✅ Entregue em <?= date('d/m/Y H:i', strtotime($minha_entrega['data_envio'])) ?>
        — <a href="uploads/<?= sanitize($minha_entrega['arquivo']) ?>" target="_blank">Ver arquivo</a>
      </div>
      <?php endif; ?>
      <form method="POST" enctype="multipart/form-data" style="display:flex;gap:.75rem;align-items:center;flex-wrap:wrap;">
        <input type="hidden" name="acao" value="anexar">
        <input type="hidden" name="id_atividade" value="<?= $atv['id'] ?>">
        <label style="font-size:.85rem;font-weight:500;color:var(--gray-600);">📎 <?= $minha_entrega ? 'Reenviar:' : 'Enviar atividade:' ?></label>
        <input type="file" name="arquivo" style="font-size:.85rem;" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.zip,.txt">
        <button type="submit" class="btn btn-primary btn-sm">Enviar</button>
      </form>
    </div>
    <?php endif; ?>

    <!-- PROFESSOR/ADMIN: ver entregas + editar/excluir -->
    <?php if (isProfessor() || isAdmin()): ?>
    <?php if ($tem_entregas): ?>
    <?php
    $entregas = $conn->prepare("SELECT e.*, u.nome as aluno_nome FROM entregas e JOIN usuarios u ON e.id_aluno = u.id WHERE e.id_atividade=? ORDER BY e.data_envio DESC");
    $entregas->bind_param("i", $atv['id']);
    $entregas->execute();
    $lista_entregas = $entregas->get_result();
    $entregas->close();
    $qtd = $lista_entregas->num_rows;
    ?>
    <?php if ($qtd > 0): ?>
    <div style="margin-top:1rem; padding:1rem; background:#f0fdfa; border-radius:8px; border:1px solid #99f6e4;">
      <div style="font-weight:600; font-size:.875rem; color:var(--teal); margin-bottom:.75rem;">
        📬 <?= $qtd ?> entrega(s) recebida(s)
      </div>
      <?php while($ent = $lista_entregas->fetch_assoc()): ?>
      <div style="display:flex;justify-content:space-between;align-items:center;padding:.5rem 0;border-bottom:1px solid #ccfbf1;">
        <div>
          <span style="font-weight:500;">🎒 <?= sanitize($ent['aluno_nome']) ?></span>
          <span style="font-size:.75rem;color:var(--gray-400);margin-left:.5rem;"><?= date('d/m/Y H:i',strtotime($ent['data_envio'])) ?></span>
        </div>
        <a href="uploads/<?= sanitize($ent['arquivo']) ?>" target="_blank" class="btn btn-success btn-sm">⬇ Baixar</a>
      </div>
      <?php endwhile; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>

    <div class="item-actions">
      <a href="atividades.php?acao=editar&id=<?= $atv['id'] ?>" class="btn btn-secondary btn-sm">✏️ Editar</a>
      <form method="POST" style="display:inline;" onsubmit="return confirm('Excluir?')">
        <input type="hidden" name="acao" value="excluir">
        <input type="hidden" name="id" value="<?= $atv['id'] ?>">
        <button type="submit" class="btn btn-danger btn-sm">🗑 Excluir</button>
      </form>
    </div>
    <?php endif; ?>
  </div>
  <?php endwhile; ?>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>

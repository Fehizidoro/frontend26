<?php
require_once 'includes/auth.php';
require_once 'includes/conexao.php';
requireLogin();

$pageTitle = 'Avisos';
$cssPath = '';
$mensagem = '';
$tipo_msg = '';

// Verifica se tabela tem id_usuario
$col = $conn->query("SHOW COLUMNS FROM avisos LIKE 'criado_por'");
$tem_id_usuario = ($col && $col->num_rows > 0);

// ── Processar POST ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'criar' && isAdmin()) {
        $titulo    = trim($_POST['titulo'] ?? '');
        $descricao = trim($_POST['descricao'] ?? '');

        if (empty($titulo) || empty($descricao)) {
            $mensagem = 'Preencha título e descrição.';
            $tipo_msg = 'error';
        } else {
            if ($tem_id_usuario) {
                $id_usuario = $_SESSION['usuario_id'];
                $stmt = $conn->prepare("INSERT INTO avisos (titulo, descricao, criado_por) VALUES (?, ?, ?)");
                $stmt->bind_param("ssi", $titulo, $descricao, $id_usuario);
            } else {
                $stmt = $conn->prepare("INSERT INTO avisos (titulo, descricao) VALUES (?, ?)");
                $stmt->bind_param("ss", $titulo, $descricao);
            }
            if ($stmt->execute()) {
                $mensagem = 'Aviso publicado com sucesso!';
                $tipo_msg = 'success';
            } else {
                $mensagem = 'Erro ao salvar aviso.';
                $tipo_msg = 'error';
            }
            $stmt->close();
        }
    }

    if ($acao === 'editar' && isAdmin()) {
        $id        = (int)($_POST['id'] ?? 0);
        $titulo    = trim($_POST['titulo'] ?? '');
        $descricao = trim($_POST['descricao'] ?? '');
        if ($id && !empty($titulo) && !empty($descricao)) {
            $stmt = $conn->prepare("UPDATE avisos SET titulo=?, descricao=? WHERE id=?");
            $stmt->bind_param("ssi", $titulo, $descricao, $id);
            if ($stmt->execute()) { $mensagem = 'Aviso atualizado!'; $tipo_msg = 'success'; }
            $stmt->close();
        }
    }

    if ($acao === 'excluir' && isAdmin()) {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $stmt = $conn->prepare("DELETE FROM avisos WHERE id=?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) { $mensagem = 'Aviso excluído.'; $tipo_msg = 'success'; }
            $stmt->close();
        }
    }
}

// ── Buscar avisos ───────────────────────────────
if ($tem_id_usuario) {
    $avisos = $conn->query("SELECT a.*, u.nome as autor FROM avisos a JOIN usuarios u ON a.criado_por = u.id ORDER BY a.data_publicacao DESC");
} else {
    $avisos = $conn->query("SELECT a.*, 'Sistema' as autor FROM avisos a ORDER BY a.data_publicacao DESC");
}

// Aviso para edição
$editando = null;
$acao_get = $_GET['acao'] ?? '';
if ($acao_get === 'editar' && isAdmin()) {
    $id_edit = (int)($_GET['id'] ?? 0);
    $stmt = $conn->prepare("SELECT * FROM avisos WHERE id=?");
    $stmt->bind_param("i", $id_edit);
    $stmt->execute();
    $editando = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

include 'includes/header.php';
?>

<div class="page-header">
  <div>
    <h2>📢 Mural de Avisos</h2>
    <p>Comunicados e informações importantes da escola</p>
  </div>
  <?php if (isAdmin()): ?>
  <a href="avisos.php?acao=novo" class="btn btn-primary">+ Novo Aviso</a>
  <?php endif; ?>
</div>

<?php if ($mensagem): ?>
<div class="alert alert-<?= $tipo_msg === 'success' ? 'success' : 'error' ?>">
  <?= $tipo_msg === 'success' ? '✓' : '⚠' ?> <?= sanitize($mensagem) ?>
</div>
<?php endif; ?>

<?php if (isAdmin() && ($acao_get === 'novo' || $acao_get === 'editar')): ?>
<div class="card" style="margin-bottom:2rem;">
  <div class="card-header">
    <h3 style="margin:0;"><?= $editando ? '✏️ Editar Aviso' : '+ Novo Aviso' ?></h3>
  </div>
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="acao" value="<?= $editando ? 'editar' : 'criar' ?>">
      <?php if ($editando): ?>
      <input type="hidden" name="id" value="<?= $editando['id'] ?>">
      <?php endif; ?>
      <div class="form-group">
        <label class="form-label">Título <span class="req">*</span></label>
        <input type="text" name="titulo" class="form-control"
               placeholder="Título do aviso"
               value="<?= sanitize($editando['titulo'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Descrição <span class="req">*</span></label>
        <textarea name="descricao" class="form-control" rows="5"
                  placeholder="Conteúdo do aviso..." required><?= sanitize($editando['descricao'] ?? '') ?></textarea>
      </div>
      <div style="display:flex; gap:.75rem;">
        <button type="submit" class="btn btn-primary"><?= $editando ? '💾 Salvar' : '📢 Publicar' ?></button>
        <a href="avisos.php" class="btn btn-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php if (!$avisos || $avisos->num_rows === 0): ?>
<div class="empty-state">
  <div class="empty-icon">📭</div>
  <h3>Nenhum aviso publicado</h3>
  <p>Os comunicados da escola aparecerão aqui.</p>
</div>
<?php else: ?>
<div class="item-list">
  <?php while($av = $avisos->fetch_assoc()): ?>
  <div class="item-card" id="aviso-<?= $av['id'] ?>">
    <div class="item-title"><?= sanitize($av['titulo']) ?></div>
    <div class="item-meta">
      <span>📅 <?= date('d/m/Y \à\s H:i', strtotime($av['data_publicacao'])) ?></span>
      <span>👤 <?= sanitize($av['autor']) ?></span>
    </div>
    <div class="item-body"><?= nl2br(sanitize($av['descricao'])) ?></div>
    <?php if (isAdmin()): ?>
    <div class="item-actions">
      <a href="avisos.php?acao=editar&id=<?= $av['id'] ?>" class="btn btn-secondary btn-sm">✏️ Editar</a>
      <form method="POST" style="display:inline;" onsubmit="return confirm('Excluir este aviso?')">
        <input type="hidden" name="acao" value="excluir">
        <input type="hidden" name="id" value="<?= $av['id'] ?>">
        <button type="submit" class="btn btn-danger btn-sm">🗑 Excluir</button>
      </form>
    </div>
    <?php endif; ?>
  </div>
  <?php endwhile; ?>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>

<?php
session_start();

require_once 'includes/conexao.php';
require_once 'includes/auth.php';

// Se não está logado e não é cadastro público, redireciona para login
$admin_criando = isLogado() && isAdmin();

$erro = '';
$form = ['nome' => '', 'email' => '', 'tipo' => 'aluno'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome  = trim($_POST['nome']  ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $conf  = $_POST['confirma_senha'] ?? '';
    $tipo  = $_POST['tipo'] ?? 'aluno';

    $form['nome']  = sanitize($nome);
    $form['email'] = sanitize($email);
    $form['tipo']  = $tipo;

    if (empty($nome) || empty($email) || empty($senha)) {
        $erro = 'Todos os campos são obrigatórios.';
    } elseif (strlen($nome) < 3) {
        $erro = 'Nome deve ter pelo menos 3 caracteres.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'E-mail inválido.';
    } elseif (strlen($senha) < 2) {
        $erro = 'Senha muito curta.';
    } elseif ($senha !== $conf) {
        $erro = 'As senhas não conferem.';
    } elseif (!in_array($tipo, ['aluno', 'professor', 'administrador'])) {
        $erro = 'Tipo inválido.';
    } else {
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $erro = 'E-mail já cadastrado.';
            $stmt->close();
        } else {
            $stmt->close();
            $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nome, $email, $senha, $tipo);
            if ($stmt->execute()) {
                if ($admin_criando) {
                    header('Location: usuarios.php?cadastro=1');
                } else {
                    header('Location: login.php?cadastro=1');
                }
                exit;
            } else {
                $erro = 'Erro ao cadastrar: ' . $conn->error;
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro — EduGestão</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="auth-page">
  <div class="auth-box">
    <div class="auth-logo">
      <div class="logo-mark">🎓</div>
      <h1><?= $admin_criando ? 'Novo Usuário' : 'Criar Conta' ?></h1>
      <p><?= $admin_criando ? 'Cadastrar novo usuário no sistema' : 'Preencha os dados para se cadastrar' ?></p>
    </div>

    <?php if ($erro): ?>
    <div class="alert alert-error">⚠ <?= $erro ?></div>
    <?php endif; ?>

    <form method="POST" novalidate>
      <div class="form-group">
        <label class="form-label">Nome completo <span class="req">*</span></label>
        <input type="text" name="nome" class="form-control"
               placeholder="Nome completo" value="<?= $form['nome'] ?>" required autofocus>
      </div>

      <div class="form-group">
        <label class="form-label">E-mail <span class="req">*</span></label>
        <input type="email" name="email" class="form-control"
               placeholder="email@exemplo.com" value="<?= $form['email'] ?>" required>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Senha <span class="req">*</span></label>
          <input type="password" name="senha" class="form-control" placeholder="Sua senha" required>
        </div>
        <div class="form-group">
          <label class="form-label">Confirmar <span class="req">*</span></label>
          <input type="password" name="confirma_senha" class="form-control" placeholder="Repita" required>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Tipo <span class="req">*</span></label>
        <select name="tipo" class="form-control" required>
          <option value="aluno"         <?= $form['tipo']==='aluno'?'selected':'' ?>>🎒 Aluno</option>
          <option value="professor"     <?= $form['tipo']==='professor'?'selected':'' ?>>📖 Professor</option>
          <option value="administrador" <?= $form['tipo']==='administrador'?'selected':'' ?>>👑 Administrador</option>
        </select>
      </div>

      <button type="submit" class="btn btn-primary btn-lg" style="width:100%; margin-top:.5rem;">
        <?= $admin_criando ? 'Cadastrar Usuário →' : 'Criar Conta →' ?>
      </button>
    </form>

    <div class="auth-footer">
      <?php if ($admin_criando): ?>
        <a href="usuarios.php">← Voltar para usuários</a>
      <?php else: ?>
        Já tem conta? <a href="login.php">Fazer login</a>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>

<?php
require_once 'includes/auth.php';
require_once 'includes/conexao.php';
requireLogin();
requireTipo(['professor', 'administrador']);

$pageTitle = 'Chamada';
$cssPath = '';
$mensagem = '';
$tipo_msg = '';
$id_prof = $_SESSION['usuario_id'];

// Verifica tabelas
$tbl = $conn->query("SHOW TABLES LIKE 'chamadas'");
if (!$tbl || $tbl->num_rows === 0) {
    echo '<div style="padding:2rem;"><div class="alert alert-error">⚠ Execute o SQL de criação das tabelas <b>chamadas</b> e <b>chamada_alunos</b> no phpMyAdmin primeiro!</div></div>';
    include 'includes/footer.php'; exit;
}

// ── Salvar chamada ───────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao']??'') === 'salvar') {
    $turma     = trim($_POST['turma'] ?? '');
    $data_aula = $_POST['data_aula'] ?? '';
    $presencas = $_POST['presenca'] ?? []; // array [id_aluno => 'presente'|'falta']

    if (empty($turma) || empty($data_aula)) {
        $mensagem = 'Selecione a turma e a data.'; $tipo_msg = 'error';
    } else {
        // Verifica se já existe chamada dessa turma nessa data
        $stmt = $conn->prepare("SELECT id FROM chamadas WHERE turma=? AND data_aula=? AND id_professor=?");
        $stmt->bind_param("ssi", $turma, $data_aula, $id_prof);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id_chamada_ex); $stmt->fetch(); $stmt->close();
            // Atualiza existente
            $id_chamada = $id_chamada_ex;
            $conn->query("DELETE FROM chamada_alunos WHERE id_chamada=$id_chamada");
        } else {
            $stmt->close();
            $stmt = $conn->prepare("INSERT INTO chamadas (id_professor, turma, data_aula) VALUES (?,?,?)");
            $stmt->bind_param("iss", $id_prof, $turma, $data_aula);
            $stmt->execute();
            $id_chamada = $conn->insert_id;
            $stmt->close();
        }

        // Busca alunos da turma (todos alunos por enquanto)
        $alunos = $conn->query("SELECT id FROM usuarios WHERE tipo='aluno'");
        while ($al = $alunos->fetch_assoc()) {
            $id_aluno = $al['id'];
            $status = isset($presencas[$id_aluno]) ? 'presente' : 'falta';
            $stmt = $conn->prepare("INSERT INTO chamada_alunos (id_chamada, id_aluno, presenca) VALUES (?,?,?)");
            $stmt->bind_param("iis", $id_chamada, $id_aluno, $status);
            $stmt->execute(); $stmt->close();
        }

        $mensagem = 'Chamada salva com sucesso!'; $tipo_msg = 'success';
    }
}

// ── Aba ativa ───────────────────────────────
$aba = $_GET['aba'] ?? 'fazer';
$filtro_turma = trim($_GET['turma'] ?? '');
$filtro_data  = trim($_GET['data'] ?? '');

// Alunos para fazer chamada
$alunos_todos = $conn->query("SELECT id, nome, foto FROM usuarios WHERE tipo='aluno' ORDER BY nome");

// Histórico de chamadas do professor
$where_hist = ["c.id_professor = $id_prof"];
if ($filtro_turma) $where_hist[] = "c.turma = '" . $conn->real_escape_string($filtro_turma) . "'";
if ($filtro_data)  $where_hist[] = "c.data_aula = '" . $conn->real_escape_string($filtro_data) . "'";
$wh = implode(' AND ', $where_hist);

$historico = $conn->query("
    SELECT c.*,
        (SELECT COUNT(*) FROM chamada_alunos ca WHERE ca.id_chamada=c.id AND ca.presenca='presente') as presentes,
        (SELECT COUNT(*) FROM chamada_alunos ca WHERE ca.id_chamada=c.id AND ca.presenca='falta') as faltas,
        (SELECT COUNT(*) FROM chamada_alunos ca WHERE ca.id_chamada=c.id) as total
    FROM chamadas c WHERE $wh ORDER BY c.data_aula DESC
");

// Chamada selecionada para visualizar
$id_ver = isset($_GET['ver']) ? (int)$_GET['ver'] : 0;
$chamada_detalhe = null;
$alunos_chamada = null;
if ($id_ver) {
    $stmt = $conn->prepare("SELECT * FROM chamadas WHERE id=? AND id_professor=?");
    $stmt->bind_param("ii", $id_ver, $id_prof);
    $stmt->execute();
    $chamada_detalhe = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($chamada_detalhe) {
        $alunos_chamada = $conn->query("
            SELECT u.nome, u.foto, ca.presenca
            FROM chamada_alunos ca
            JOIN usuarios u ON ca.id_aluno = u.id
            WHERE ca.id_chamada = $id_ver
            ORDER BY ca.presenca ASC, u.nome ASC
        ");
    }
}

// Resumo de frequência por aluno
$resumo_aluno = isset($_GET['aluno']) ? (int)$_GET['aluno'] : 0;
$dados_aluno = null;
$freq_aluno = null;
if ($resumo_aluno) {
    $stmt = $conn->prepare("SELECT nome, foto FROM usuarios WHERE id=?");
    $stmt->bind_param("i", $resumo_aluno);
    $stmt->execute();
    $dados_aluno = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $freq_aluno = $conn->query("
        SELECT c.data_aula, c.turma, ca.presenca
        FROM chamada_alunos ca
        JOIN chamadas c ON ca.id_chamada = c.id
        WHERE ca.id_aluno = $resumo_aluno AND c.id_professor = $id_prof
        ORDER BY c.data_aula DESC
    ");
}

function avatarHtml($foto, $nome, $size=36) {
    $ini = mb_strtoupper(mb_substr($nome,0,1));
    if (!empty($foto) && file_exists(__DIR__.'/uploads/fotos/'.$foto))
        return "<img src='uploads/fotos/{$foto}' style='width:{$size}px;height:{$size}px;border-radius:50%;object-fit:cover;flex-shrink:0;'>";
    return "<div style='width:{$size}px;height:{$size}px;border-radius:50%;background:var(--primary);display:flex;align-items:center;justify-content:center;color:white;font-weight:700;font-size:".($size*.35)."px;flex-shrink:0;'>{$ini}</div>";
}

include 'includes/header.php';
?>

<div class="page-header">
  <div><h2>📋 Chamada</h2><p>Registro de presença e faltas dos alunos</p></div>
</div>

<?php if ($mensagem): ?>
<div class="alert alert-<?= $tipo_msg==='success'?'success':'error' ?>">
  <?= $tipo_msg==='success'?'✓':'⚠' ?> <?= sanitize($mensagem) ?>
</div>
<?php endif; ?>

<!-- Abas -->
<div style="display:flex; gap:.5rem; margin-bottom:1.5rem; border-bottom:2px solid var(--gray-200); padding-bottom:0;">
  <?php foreach(['fazer'=>'📝 Fazer Chamada','historico'=>'📅 Histórico','frequencia'=>'📊 Frequência'] as $k=>$label): ?>
  <a href="chamada.php?aba=<?= $k ?>"
     style="padding:.65rem 1.25rem; font-size:.875rem; font-weight:500; border-radius:8px 8px 0 0;
            text-decoration:none; margin-bottom:-2px; border:2px solid transparent;
            <?= $aba===$k ? 'background:white;border-color:var(--gray-200);border-bottom-color:white;color:var(--primary);' : 'color:var(--gray-600);' ?>">
    <?= $label ?>
  </a>
  <?php endforeach; ?>
</div>

<!-- ══════════════ ABA: FAZER CHAMADA ══════════════ -->
<?php if ($aba === 'fazer'): ?>
<div class="card">
  <div class="card-header"><h3 style="margin:0;">📝 Registrar Chamada</h3></div>
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="acao" value="salvar">
      <div class="form-row" style="margin-bottom:1.25rem;">
        <div class="form-group" style="margin:0;">
          <label class="form-label">Turma <span class="req">*</span></label>
          <select name="turma" class="form-control" required>
            <option value="">Selecione...</option>
            <?php foreach(['1º A','1º B','2º A','2º B','3º A','3º B'] as $t): ?>
            <option value="<?= $t ?>"><?= $t ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group" style="margin:0;">
          <label class="form-label">Data da Aula <span class="req">*</span></label>
          <input type="date" name="data_aula" class="form-control" value="<?= date('Y-m-d') ?>" required>
        </div>
      </div>

      <!-- Lista de alunos -->
      <?php if (!$alunos_todos || $alunos_todos->num_rows === 0): ?>
      <div class="empty-state" style="padding:2rem;">
        <div class="empty-icon">🎒</div>
        <h3>Nenhum aluno cadastrado</h3>
      </div>
      <?php else: ?>

      <!-- Botões marcar todos -->
      <div style="display:flex;gap:.75rem;margin-bottom:1rem;align-items:center;">
        <span style="font-size:.875rem;font-weight:500;color:var(--gray-600);">Marcar todos:</span>
        <button type="button" onclick="marcarTodos('presente')" class="btn btn-success btn-sm">✓ Todos Presentes</button>
        <button type="button" onclick="marcarTodos('falta')" class="btn btn-danger btn-sm">✗ Todos Faltaram</button>
      </div>

      <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(280px,1fr)); gap:.75rem;">
        <?php while($al = $alunos_todos->fetch_assoc()): ?>
        <label class="aluno-card" for="al<?= $al['id'] ?>"
               style="display:flex;align-items:center;gap:.75rem;padding:.85rem 1rem;
                      border:2px solid var(--gray-200);border-radius:10px;cursor:pointer;
                      transition:all var(--transition);background:white;">
          <input type="checkbox" id="al<?= $al['id'] ?>" name="presenca[<?= $al['id'] ?>]"
                 value="presente" class="aluno-check" style="display:none;">
          <?= avatarHtml($al['foto']??'', $al['nome']) ?>
          <span style="font-weight:500;color:var(--navy);flex:1;"><?= sanitize($al['nome']) ?></span>
          <span class="status-badge" style="font-size:.75rem;font-weight:600;padding:.2rem .6rem;border-radius:50px;background:var(--gray-100);color:var(--gray-400);">—</span>
        </label>
        <?php endwhile; ?>
      </div>

      <button type="submit" class="btn btn-primary btn-lg" style="margin-top:1.5rem;width:100%;">
        💾 Salvar Chamada
      </button>
      <?php endif; ?>
    </form>
  </div>
</div>

<style>
.aluno-card.presente { border-color:var(--green)!important; background:#f0fdf4!important; }
.aluno-card.presente .status-badge { background:#dcfce7!important; color:var(--green)!important; }
.aluno-card.falta    { border-color:#ef4444!important; background:#fef2f2!important; }
.aluno-card.falta    .status-badge { background:#fee2e2!important; color:#dc2626!important; }
</style>
<script>
document.querySelectorAll('.aluno-check').forEach(cb => {
    const label = cb.closest('.aluno-card');
    const badge = label.querySelector('.status-badge');
    // Click no card alterna presença
    label.addEventListener('click', function(e) {
        if (e.target === cb) return;
        cb.checked = !cb.checked;
        updateCard(label, cb, badge);
    });
    cb.addEventListener('change', () => updateCard(label, cb, badge));
});

function updateCard(label, cb, badge) {
    if (cb.checked) {
        label.classList.remove('falta'); label.classList.add('presente');
        badge.textContent = '✓ Presente';
    } else {
        label.classList.remove('presente'); label.classList.add('falta');
        badge.textContent = '✗ Falta';
    }
}

function marcarTodos(status) {
    document.querySelectorAll('.aluno-check').forEach(cb => {
        cb.checked = status === 'presente';
        const label = cb.closest('.aluno-card');
        const badge = label.querySelector('.status-badge');
        updateCard(label, cb, badge);
    });
}

// Inicializa todos como falta
document.querySelectorAll('.aluno-card').forEach(label => {
    const cb = label.querySelector('.aluno-check');
    const badge = label.querySelector('.status-badge');
    label.classList.add('falta');
    badge.textContent = '✗ Falta';
});
</script>

<!-- ══════════════ ABA: HISTÓRICO ══════════════ -->
<?php elseif ($aba === 'historico'): ?>

<!-- Filtros -->
<div class="card" style="margin-bottom:1.5rem;">
  <div class="card-body" style="padding:1rem 1.5rem;">
    <form method="GET" style="display:flex;gap:.75rem;align-items:center;flex-wrap:wrap;">
      <input type="hidden" name="aba" value="historico">
      <select name="turma" class="form-control" style="width:auto;">
        <option value="">Todas as turmas</option>
        <?php foreach(['1º A','1º B','2º A','2º B','3º A','3º B'] as $t): ?>
        <option value="<?= $t ?>" <?= $filtro_turma===$t?'selected':'' ?>><?= $t ?></option>
        <?php endforeach; ?>
      </select>
      <input type="date" name="data" class="form-control" style="width:auto;" value="<?= $filtro_data ?>">
      <button type="submit" class="btn btn-secondary btn-sm">Filtrar</button>
      <?php if ($filtro_turma||$filtro_data): ?>
      <a href="chamada.php?aba=historico" class="btn btn-secondary btn-sm">✕ Limpar</a>
      <?php endif; ?>
    </form>
  </div>
</div>

<?php if ($id_ver && $chamada_detalhe): ?>
<!-- Detalhe de chamada -->
<div class="card" style="margin-bottom:1.5rem;">
  <div class="card-header">
    <div>
      <h3 style="margin:0;">Chamada — <?= sanitize($chamada_detalhe['turma']) ?></h3>
      <div style="font-size:.8rem;color:var(--gray-400);margin-top:.2rem;">
        📅 <?= date('d/m/Y', strtotime($chamada_detalhe['data_aula'])) ?>
      </div>
    </div>
    <a href="chamada.php?aba=historico" class="btn btn-secondary btn-sm">← Voltar</a>
  </div>
  <div class="card-body" style="padding:1rem;">
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:.6rem;">
      <?php while($al=$alunos_chamada->fetch_assoc()): ?>
      <div style="display:flex;align-items:center;gap:.75rem;padding:.75rem;border-radius:8px;
                  background:<?= $al['presenca']==='presente'?'#f0fdf4':'#fef2f2' ?>;
                  border:1px solid <?= $al['presenca']==='presente'?'#bbf7d0':'#fecaca' ?>;">
        <?= avatarHtml($al['foto']??'', $al['nome']) ?>
        <span style="font-weight:500;color:var(--navy);flex:1;"><?= sanitize($al['nome']) ?></span>
        <span style="font-size:.75rem;font-weight:700;color:<?= $al['presenca']==='presente'?'var(--green)':'#dc2626' ?>;">
          <?= $al['presenca']==='presente'?'✓ Presente':'✗ Falta' ?>
        </span>
      </div>
      <?php endwhile; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Lista histórico -->
<?php if (!$historico || $historico->num_rows === 0): ?>
<div class="empty-state">
  <div class="empty-icon">📅</div>
  <h3>Nenhuma chamada registrada</h3>
  <p>Faça a primeira chamada na aba "Fazer Chamada".</p>
</div>
<?php else: ?>
<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Data</th><th>Turma</th><th>Presentes</th><th>Faltas</th><th>% Presença</th><th>Ações</th>
        </tr>
      </thead>
      <tbody>
        <?php while($ch=$historico->fetch_assoc()):
          $pct = $ch['total'] > 0 ? round($ch['presentes']/$ch['total']*100) : 0;
          $cor = $pct >= 75 ? 'var(--green)' : ($pct >= 50 ? 'var(--amber)' : '#dc2626');
        ?>
        <tr>
          <td><strong><?= date('d/m/Y', strtotime($ch['data_aula'])) ?></strong></td>
          <td><span class="badge badge-teal"><?= sanitize($ch['turma']) ?></span></td>
          <td><span style="color:var(--green);font-weight:600;">✓ <?= $ch['presentes'] ?></span></td>
          <td><span style="color:#dc2626;font-weight:600;">✗ <?= $ch['faltas'] ?></span></td>
          <td>
            <div style="display:flex;align-items:center;gap:.5rem;">
              <div style="flex:1;height:8px;background:var(--gray-200);border-radius:4px;overflow:hidden;">
                <div style="height:100%;width:<?= $pct ?>%;background:<?= $cor ?>;border-radius:4px;"></div>
              </div>
              <span style="font-weight:700;color:<?= $cor ?>;font-size:.85rem;"><?= $pct ?>%</span>
            </div>
          </td>
          <td>
            <a href="chamada.php?aba=historico&ver=<?= $ch['id'] ?>" class="btn btn-secondary btn-sm">👁 Ver</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- ══════════════ ABA: FREQUÊNCIA ══════════════ -->
<?php elseif ($aba === 'frequencia'): ?>

<?php if ($resumo_aluno && $dados_aluno): ?>
<!-- Detalhes do aluno -->
<div class="card" style="margin-bottom:1.5rem;">
  <div class="card-header">
    <div style="display:flex;align-items:center;gap:.75rem;">
      <?= avatarHtml($dados_aluno['foto']??'', $dados_aluno['nome'], 44) ?>
      <div>
        <h3 style="margin:0;"><?= sanitize($dados_aluno['nome']) ?></h3>
        <div style="font-size:.8rem;color:var(--gray-400);">Histórico de presença</div>
      </div>
    </div>
    <a href="chamada.php?aba=frequencia" class="btn btn-secondary btn-sm">← Voltar</a>
  </div>
  <div class="card-body" style="padding:1rem;">
    <?php
    $total_aulas = 0; $total_pres = 0;
    $linhas = [];
    while($f=$freq_aluno->fetch_assoc()) { $linhas[] = $f; $total_aulas++; if($f['presenca']==='presente') $total_pres++; }
    $pct_geral = $total_aulas > 0 ? round($total_pres/$total_aulas*100) : 0;
    $cor_geral = $pct_geral >= 75 ? 'var(--green)' : ($pct_geral >= 50 ? 'var(--amber)' : '#dc2626');
    ?>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:1.5rem;">
      <div style="text-align:center;padding:1rem;background:var(--gray-50);border-radius:10px;">
        <div style="font-size:1.8rem;font-weight:700;color:var(--navy);"><?= $total_aulas ?></div>
        <div style="font-size:.8rem;color:var(--gray-600);">Aulas registradas</div>
      </div>
      <div style="text-align:center;padding:1rem;background:#f0fdf4;border-radius:10px;">
        <div style="font-size:1.8rem;font-weight:700;color:var(--green);"><?= $total_pres ?></div>
        <div style="font-size:.8rem;color:var(--gray-600);">Presenças</div>
      </div>
      <div style="text-align:center;padding:1rem;background:#fef2f2;border-radius:10px;">
        <div style="font-size:1.8rem;font-weight:700;color:#dc2626;"><?= $total_aulas-$total_pres ?></div>
        <div style="font-size:.8rem;color:var(--gray-600);">Faltas</div>
      </div>
    </div>
    <div style="display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem;">
      <div style="flex:1;height:14px;background:var(--gray-200);border-radius:7px;overflow:hidden;">
        <div style="height:100%;width:<?= $pct_geral ?>%;background:<?= $cor_geral ?>;border-radius:7px;transition:width .5s;"></div>
      </div>
      <span style="font-size:1.2rem;font-weight:700;color:<?= $cor_geral ?>;"><?= $pct_geral ?>%</span>
      <?php if ($pct_geral < 75): ?><span class="badge badge-red">⚠ Abaixo do mínimo</span><?php endif; ?>
    </div>
    <table>
      <thead><tr><th>Data</th><th>Turma</th><th>Status</th></tr></thead>
      <tbody>
        <?php foreach($linhas as $f): ?>
        <tr>
          <td><?= date('d/m/Y', strtotime($f['data_aula'])) ?></td>
          <td><span class="badge badge-teal"><?= sanitize($f['turma']) ?></span></td>
          <td>
            <?php if ($f['presenca']==='presente'): ?>
            <span style="color:var(--green);font-weight:600;">✓ Presente</span>
            <?php else: ?>
            <span style="color:#dc2626;font-weight:600;">✗ Falta</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php else: ?>
<!-- Lista de alunos com frequência geral -->
<?php
$alunos_freq = $conn->query("SELECT u.id, u.nome, u.foto FROM usuarios u WHERE u.tipo='aluno' ORDER BY u.nome");
?>
<?php if (!$alunos_freq || $alunos_freq->num_rows === 0): ?>
<div class="empty-state"><div class="empty-icon">🎒</div><h3>Nenhum aluno cadastrado</h3></div>
<?php else: ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1rem;">
  <?php while($al=$alunos_freq->fetch_assoc()):
    $res = $conn->query("SELECT COUNT(*) as total, SUM(ca.presenca='presente') as pres FROM chamada_alunos ca JOIN chamadas c ON ca.id_chamada=c.id WHERE ca.id_aluno={$al['id']} AND c.id_professor=$id_prof");
    $r = $res->fetch_assoc();
    $tot = (int)$r['total']; $pres = (int)$r['pres'];
    $pct = $tot > 0 ? round($pres/$tot*100) : 0;
    $cor = $pct >= 75 ? 'var(--green)' : ($pct >= 50 ? 'var(--amber)' : ($tot === 0 ? 'var(--gray-400)' : '#dc2626'));
  ?>
  <a href="chamada.php?aba=frequencia&aluno=<?= $al['id'] ?>" style="text-decoration:none;">
    <div class="card" style="padding:1.25rem; transition:transform .2s,box-shadow .2s;">
      <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:.75rem;">
        <?= avatarHtml($al['foto']??'', $al['nome'], 40) ?>
        <div style="flex:1;">
          <div style="font-weight:600;color:var(--navy);"><?= sanitize($al['nome']) ?></div>
          <div style="font-size:.75rem;color:var(--gray-400);"><?= $tot ?> aulas registradas</div>
        </div>
        <span style="font-size:1.1rem;font-weight:700;color:<?= $cor ?>;"><?= $tot>0?$pct.'%':'—' ?></span>
      </div>
      <?php if ($tot > 0): ?>
      <div style="height:8px;background:var(--gray-200);border-radius:4px;overflow:hidden;">
        <div style="height:100%;width:<?= $pct ?>%;background:<?= $cor ?>;border-radius:4px;"></div>
      </div>
      <div style="display:flex;justify-content:space-between;margin-top:.4rem;font-size:.75rem;color:var(--gray-400);">
        <span style="color:var(--green);">✓ <?= $pres ?> pres.</span>
        <span style="color:#dc2626;">✗ <?= $tot-$pres ?> faltas</span>
        <?php if ($pct < 75): ?><span class="badge badge-red" style="font-size:.65rem;">Risco</span><?php endif; ?>
      </div>
      <?php else: ?>
      <div style="font-size:.8rem;color:var(--gray-400);text-align:center;">Sem chamadas ainda</div>
      <?php endif; ?>
    </div>
  </a>
  <?php endwhile; ?>
</div>
<?php endif; ?>
<?php endif; ?>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>

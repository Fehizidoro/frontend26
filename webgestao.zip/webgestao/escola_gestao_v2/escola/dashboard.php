<?php
require_once 'includes/auth.php';
require_once 'includes/conexao.php';
requireLogin();

$pageTitle = 'Dashboard';
$cssPath = '';

$tipo = $_SESSION['usuario_tipo'];
$nome = $_SESSION['usuario_nome'];
$id   = $_SESSION['usuario_id'];

// ── Dados gerais ──────────────────────────────
$total_usuarios   = $conn->query("SELECT COUNT(*) as c FROM usuarios")->fetch_assoc()['c'];
$total_avisos     = $conn->query("SELECT COUNT(*) as c FROM avisos")->fetch_assoc()['c'];
$total_atividades = $conn->query("SELECT COUNT(*) as c FROM atividades")->fetch_assoc()['c'];
$atv_pendentes    = $conn->query("SELECT COUNT(*) as c FROM atividades WHERE prazo >= CURDATE()")->fetch_assoc()['c'];

// ── Últimos avisos ────────────────────────────
$col = $conn->query("SHOW COLUMNS FROM avisos LIKE 'criado_por'");
$tem_id_usuario = ($col && $col->num_rows > 0);
if ($tem_id_usuario) {
    $ultimos_avisos = $conn->query("SELECT a.*, u.nome as autor FROM avisos a JOIN usuarios u ON a.criado_por = u.id ORDER BY a.data_publicacao DESC LIMIT 3");
} else {
    $ultimos_avisos = $conn->query("SELECT a.*, 'Sistema' as autor FROM avisos a ORDER BY a.data_publicacao DESC LIMIT 3");
}

// ── Próximas atividades ───────────────────────
$col2 = $conn->query("SHOW COLUMNS FROM atividades LIKE 'criado_por'");
$tem_professor = ($col2 && $col2->num_rows > 0);

$proximas_atv = $conn->query("SELECT * FROM atividades WHERE prazo >= CURDATE() ORDER BY prazo ASC LIMIT 5");

// ── Atividades do professor ───────────────────
$minhas_atv = null;
if ($tipo === 'professor' && $tem_professor) {
    $stmt = $conn->prepare("SELECT * FROM atividades WHERE criado_por = ? ORDER BY prazo ASC");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $minhas_atv = $stmt->get_result();
    $stmt->close();
}

// ── Total de alunos/professores para admin ────
$total_alunos    = $conn->query("SELECT COUNT(*) as c FROM usuarios WHERE tipo='aluno'")->fetch_assoc()['c'];
$total_profs     = $conn->query("SELECT COUNT(*) as c FROM usuarios WHERE tipo='professor'")->fetch_assoc()['c'];
$total_admins    = $conn->query("SELECT COUNT(*) as c FROM usuarios WHERE tipo='administrador'")->fetch_assoc()['c'];

function prazoClass($prazo) {
    $diff = (strtotime($prazo) - time()) / 86400;
    if ($diff < 2)  return 'prazo-urgente';
    if ($diff <= 7) return 'prazo-breve';
    return 'prazo-ok';
}

include 'includes/header.php';
?>

<?php if (isset($_GET['erro']) && $_GET['erro'] === 'acesso_negado'): ?>
<div class="alert alert-error">⚠ Você não tem permissão para esta área.</div>
<?php endif; ?>

<!-- BANNER -->
<div class="welcome-banner">
  <?php if ($tipo === 'administrador'): ?>
    <h2>Painel do Administrador 👑</h2>
    <p>Bem-vindo, <?= sanitize($nome) ?>! Gerencie toda a plataforma por aqui.</p>
  <?php elseif ($tipo === 'professor'): ?>
    <h2>Painel do Professor 📖</h2>
    <p>Bem-vindo, <?= sanitize($nome) ?>! Gerencie suas turmas e atividades.</p>
  <?php else: ?>
    <h2>Olá, <?= sanitize($nome) ?>! 🎒</h2>
    <p>Acompanhe seus avisos e atividades por aqui.</p>
  <?php endif; ?>
</div>

<!-- ════════════════════════════════════════
     ADMINISTRADOR
════════════════════════════════════════ -->
<?php if ($tipo === 'administrador'): ?>

<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-icon blue">🎒</div>
    <div class="stat-info"><div class="num"><?= $total_alunos ?></div><div class="label">Alunos</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon teal">📖</div>
    <div class="stat-info"><div class="num"><?= $total_profs ?></div><div class="label">Professores</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon amber">📢</div>
    <div class="stat-info"><div class="num"><?= $total_avisos ?></div><div class="label">Avisos publicados</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green">📚</div>
    <div class="stat-info"><div class="num"><?= $total_atividades ?></div><div class="label">Atividades cadastradas</div></div>
  </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; margin-bottom:1.5rem;">
  <div class="card">
    <div class="card-header">
      <h3 style="margin:0;">📢 Últimos Avisos</h3>
      <a href="avisos.php" class="btn btn-secondary btn-sm">Ver todos</a>
    </div>
    <div class="card-body" style="padding:1rem;">
      <?php if (!$ultimos_avisos || $ultimos_avisos->num_rows === 0): ?>
        <p style="color:var(--gray-400); font-size:.875rem;">Nenhum aviso ainda.</p>
      <?php else: while($av = $ultimos_avisos->fetch_assoc()): ?>
        <div style="padding:.75rem 0; border-bottom:1px solid var(--gray-100);">
          <div style="font-weight:500; color:var(--navy);"><?= sanitize($av['titulo']) ?></div>
          <div style="font-size:.75rem; color:var(--gray-400);"><?= date('d/m/Y', strtotime($av['data_publicacao'])) ?></div>
        </div>
      <?php endwhile; endif; ?>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <h3 style="margin:0;">👥 Usuários do Sistema</h3>
      <a href="usuarios.php" class="btn btn-secondary btn-sm">Gerenciar</a>
    </div>
    <div class="card-body" style="padding:1.5rem;">
      <div style="display:flex; flex-direction:column; gap:1rem;">
        <div style="display:flex; justify-content:space-between; align-items:center; padding:.75rem; background:var(--primary-bg); border-radius:8px;">
          <span>🎒 Alunos</span><strong><?= $total_alunos ?></strong>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; padding:.75rem; background:#f0fdfa; border-radius:8px;">
          <span>📖 Professores</span><strong><?= $total_profs ?></strong>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; padding:.75rem; background:#fffbeb; border-radius:8px;">
          <span>👑 Administradores</span><strong><?= $total_admins ?></strong>
        </div>
      </div>
    </div>
  </div>
</div>

<div style="display:flex; gap:1rem; flex-wrap:wrap;">
  <a href="avisos.php?acao=novo" class="btn btn-primary">+ Novo Aviso</a>
  <a href="avisos.php" class="btn btn-secondary">📢 Ver Avisos</a>
  <a href="usuarios.php" class="btn btn-secondary">👥 Gerenciar Usuários</a>
  <a href="atividades.php" class="btn btn-secondary">📚 Ver Atividades</a>
</div>

<!-- ════════════════════════════════════════
     PROFESSOR
════════════════════════════════════════ -->
<?php elseif ($tipo === 'professor'): ?>

<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-icon blue">📚</div>
    <div class="stat-info">
      <div class="num"><?= $minhas_atv ? $minhas_atv->num_rows : $total_atividades ?></div>
      <div class="label">Minhas atividades</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green">⏰</div>
    <div class="stat-info"><div class="num"><?= $atv_pendentes ?></div><div class="label">Pendentes</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon amber">📢</div>
    <div class="stat-info"><div class="num"><?= $total_avisos ?></div><div class="label">Avisos publicados</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon teal">🎒</div>
    <div class="stat-info"><div class="num"><?= $total_alunos ?></div><div class="label">Alunos na escola</div></div>
  </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; margin-bottom:1.5rem;">
  <div class="card">
    <div class="card-header">
      <h3 style="margin:0;">📚 Minhas Atividades</h3>
      <a href="atividades.php?acao=nova" class="btn btn-primary btn-sm">+ Nova</a>
    </div>
    <div class="card-body" style="padding:1rem;">
      <?php
      // Rebusca para não ter ponteiro zerado
      if ($tem_professor) {
          $stmt2 = $conn->prepare("SELECT * FROM atividades WHERE criado_por = ? ORDER BY prazo ASC LIMIT 5");
          $stmt2->bind_param("i", $id);
          $stmt2->execute();
          $atv_prof = $stmt2->get_result();
          $stmt2->close();
      } else {
          $atv_prof = $conn->query("SELECT * FROM atividades ORDER BY prazo ASC LIMIT 5");
      }
      if (!$atv_prof || $atv_prof->num_rows === 0): ?>
        <p style="color:var(--gray-400); font-size:.875rem;">Nenhuma atividade cadastrada.</p>
      <?php else: while($atv = $atv_prof->fetch_assoc()): ?>
        <div style="padding:.75rem 0; border-bottom:1px solid var(--gray-100);">
          <div style="font-weight:500; color:var(--navy);"><?= sanitize($atv['titulo']) ?></div>
          <div style="font-size:.75rem; display:flex; gap:.5rem; margin-top:.2rem;">
            <span class="badge badge-teal"><?= sanitize($atv['turma']) ?></span>
            <span class="<?= prazoClass($atv['prazo']) ?>">📅 <?= date('d/m/Y', strtotime($atv['prazo'])) ?></span>
          </div>
        </div>
      <?php endwhile; endif; ?>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <h3 style="margin:0;">📢 Avisos da Escola</h3>
      <a href="avisos.php" class="btn btn-secondary btn-sm">Ver todos</a>
    </div>
    <div class="card-body" style="padding:1rem;">
      <?php
      if ($tem_id_usuario) {
          $av2 = $conn->query("SELECT a.*, u.nome as autor FROM avisos a JOIN usuarios u ON a.criado_por = u.id ORDER BY a.data_publicacao DESC LIMIT 3");
      } else {
          $av2 = $conn->query("SELECT *, 'Sistema' as autor FROM avisos ORDER BY data_publicacao DESC LIMIT 3");
      }
      if (!$av2 || $av2->num_rows === 0): ?>
        <p style="color:var(--gray-400); font-size:.875rem;">Nenhum aviso ainda.</p>
      <?php else: while($av = $av2->fetch_assoc()): ?>
        <div style="padding:.75rem 0; border-bottom:1px solid var(--gray-100);">
          <div style="font-weight:500; color:var(--navy);"><?= sanitize($av['titulo']) ?></div>
          <div style="font-size:.75rem; color:var(--gray-400);"><?= date('d/m/Y', strtotime($av['data_publicacao'])) ?></div>
        </div>
      <?php endwhile; endif; ?>
    </div>
  </div>
</div>

<div style="display:flex; gap:1rem; flex-wrap:wrap;">
  <a href="atividades.php?acao=nova" class="btn btn-primary">+ Nova Atividade</a>
  <a href="atividades.php" class="btn btn-secondary">📚 Minhas Atividades</a>
  <a href="avisos.php" class="btn btn-secondary">📢 Ver Avisos</a>
</div>

<!-- ════════════════════════════════════════
     ALUNO
════════════════════════════════════════ -->
<?php else: ?>

<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-icon blue">📚</div>
    <div class="stat-info"><div class="num"><?= $total_atividades ?></div><div class="label">Atividades</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green">⏰</div>
    <div class="stat-info"><div class="num"><?= $atv_pendentes ?></div><div class="label">Pendentes</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon amber">📢</div>
    <div class="stat-info"><div class="num"><?= $total_avisos ?></div><div class="label">Avisos</div></div>
  </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; margin-bottom:1.5rem;">
  <div class="card">
    <div class="card-header">
      <h3 style="margin:0;">📚 Próximas Entregas</h3>
      <a href="atividades.php" class="btn btn-secondary btn-sm">Ver todas</a>
    </div>
    <div class="card-body" style="padding:1rem;">
      <?php if (!$proximas_atv || $proximas_atv->num_rows === 0): ?>
        <p style="color:var(--gray-400); font-size:.875rem;">Nenhuma atividade pendente.</p>
      <?php else: while($atv = $proximas_atv->fetch_assoc()): ?>
        <div style="padding:.75rem 0; border-bottom:1px solid var(--gray-100);">
          <div style="font-weight:500; color:var(--navy);"><?= sanitize($atv['titulo']) ?></div>
          <div style="font-size:.75rem; display:flex; gap:.5rem; margin-top:.2rem;">
            <span class="badge badge-teal"><?= sanitize($atv['turma']) ?></span>
            <span class="<?= prazoClass($atv['prazo']) ?>">📅 <?= date('d/m/Y', strtotime($atv['prazo'])) ?></span>
          </div>
        </div>
      <?php endwhile; endif; ?>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <h3 style="margin:0;">📢 Avisos da Escola</h3>
      <a href="avisos.php" class="btn btn-secondary btn-sm">Ver todos</a>
    </div>
    <div class="card-body" style="padding:1rem;">
      <?php
      if ($tem_id_usuario) {
          $av3 = $conn->query("SELECT a.*, u.nome as autor FROM avisos a JOIN usuarios u ON a.criado_por = u.id ORDER BY a.data_publicacao DESC LIMIT 3");
      } else {
          $av3 = $conn->query("SELECT *, 'Sistema' as autor FROM avisos ORDER BY data_publicacao DESC LIMIT 3");
      }
      if (!$av3 || $av3->num_rows === 0): ?>
        <p style="color:var(--gray-400); font-size:.875rem;">Nenhum aviso ainda.</p>
      <?php else: while($av = $av3->fetch_assoc()): ?>
        <div style="padding:.75rem 0; border-bottom:1px solid var(--gray-100);">
          <div style="font-weight:500; color:var(--navy);"><?= sanitize($av['titulo']) ?></div>
          <div style="font-size:.75rem; color:var(--gray-400);"><?= date('d/m/Y', strtotime($av['data_publicacao'])) ?></div>
        </div>
      <?php endwhile; endif; ?>
    </div>
  </div>
</div>

<div style="display:flex; gap:1rem; flex-wrap:wrap;">
  <a href="atividades.php" class="btn btn-primary">📚 Ver Atividades</a>
  <a href="avisos.php" class="btn btn-secondary">📢 Ver Avisos</a>
</div>

<?php endif; ?>

<?php include 'includes/footer.php'; ?>

<?php
// ============================================
// Arquivo: includes/auth.php
// Funções de autenticação e controle de sessão
// ============================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLogado() {
    return isset($_SESSION['usuario_id']) && !empty($_SESSION['usuario_id']);
}

function requireLogin() {
    if (!isLogado()) {
        header('Location: login.php');
        exit;
    }
}

function requireTipo($tipos) {
    requireLogin();
    if (!is_array($tipos)) $tipos = [$tipos];
    if (!in_array($_SESSION['usuario_tipo'], $tipos)) {
        header('Location: dashboard.php?erro=acesso_negado');
        exit;
    }
}

function isAdmin() {
    return isLogado() && $_SESSION['usuario_tipo'] === 'administrador';
}

function isProfessor() {
    return isLogado() && $_SESSION['usuario_tipo'] === 'professor';
}

function isAluno() {
    return isLogado() && $_SESSION['usuario_tipo'] === 'aluno';
}

function getTipoLabel($tipo) {
    $labels = [
        'aluno'          => 'Aluno',
        'professor'      => 'Professor',
        'administrador'  => 'Administrador'
    ];
    return $labels[$tipo] ?? $tipo;
}

function sanitize($str) {
    return htmlspecialchars(strip_tags(trim($str)), ENT_QUOTES, 'UTF-8');
}

<?php
// ============================================
// Arquivo: includes/conexao.php
// Responsável pela conexão com o banco MySQL
// ============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'gestao_escolar');
define('DB_CHARSET', 'utf8mb4');

function getConexao() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die(json_encode([
            'erro' => true,
            'mensagem' => 'Falha na conexão com o banco de dados: ' . $conn->connect_error
        ]));
    }
    
    $conn->set_charset(DB_CHARSET);
    return $conn;
}

$conn = getConexao();

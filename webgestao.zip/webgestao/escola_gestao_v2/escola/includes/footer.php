<?php // includes/footer.php ?>
</main>
<footer class="app-footer">
  &copy; <?= date('Y') ?> EduGestão — Plataforma de Gestão Escolar
</footer>
</div>
</body>
</html>

<?php
// includes/header.php — Topbar e início do layout
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $pageTitle ?? 'EduGestão' ?> — EduGestão</title>
  <link rel="stylesheet" href="<?= $cssPath ?? '' ?>css/style.css">
</head>
<body>
<div class="app-wrapper">

<?php if (isset($_SESSION['usuario_id'])): ?>
<header class="topbar">
  <a href="dashboard.php" class="topbar-brand">
    <div class="logo-icon">🎓</div>
    EduGestão
  </a>

  <nav class="topbar-nav">
    <a href="dashboard.php" <?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'class="active"' : '' ?>>
      🏠 Dashboard
    </a>
    <a href="avisos.php" <?= basename($_SERVER['PHP_SELF']) === 'avisos.php' ? 'class="active"' : '' ?>>
      📢 Avisos
    </a>
    <a href="mensagens.php" <?= basename($_SERVER['PHP_SELF']) === 'mensagens.php' ? 'class="active"' : '' ?>>
      <?php
      // Badge de não lidas
      $uid = $_SESSION['usuario_id'];
      $nr = $conn->query("SELECT COUNT(*) as c FROM mensagens WHERE id_destinatario=$uid AND lida=0");
      $nrc = $nr ? $nr->fetch_assoc()['c'] : 0;
      ?>
      💬 Mensagens<?= $nrc > 0 ? ' <span style="background:white;color:var(--primary);border-radius:50px;padding:.1rem .4rem;font-size:.7rem;font-weight:700;margin-left:.2rem;">'.$nrc.'</span>' : '' ?>
    </a>
    <a href="atividades.php" <?= basename($_SERVER['PHP_SELF']) === 'atividades.php' ? 'class="active"' : '' ?>>
      📚 Atividades
    </a>
    <?php if (isProfessor() || isAdmin()): ?>
    <a href="chamada.php" <?= basename($_SERVER['PHP_SELF']) === 'chamada.php' ? 'class="active"' : '' ?>>
      📋 Chamada
    </a>
    <?php endif; ?>
    <?php if (isProfessor()): ?>
    <a href="professor_entregas.php" <?= basename($_SERVER['PHP_SELF']) === 'professor_entregas.php' ? 'class="active"' : '' ?>>
      📬 Entregas
    </a>
    <?php endif; ?>
    <?php if (isAdmin()): ?>
    <a href="usuarios.php" <?= basename($_SERVER['PHP_SELF']) === 'usuarios.php' ? 'class="active"' : '' ?>>
      👥 Usuários
    </a>
    <?php endif; ?>
  </nav>

  <div class="topbar-right">
    <a href="perfil.php" class="user-chip" style="text-decoration:none;">
      <?php
      $foto_sess = $_SESSION['usuario_foto'] ?? '';
      if (!empty($foto_sess) && file_exists(__DIR__.'/../uploads/fotos/'.$foto_sess)):
      ?>
      <img src="uploads/fotos/<?= $foto_sess ?>" style="width:28px;height:28px;border-radius:50%;object-fit:cover;">
      <?php else: ?>
      <div class="avatar"><?= mb_strtoupper(mb_substr($_SESSION['usuario_nome'], 0, 1)) ?></div>
      <?php endif; ?>
      <?= sanitize($_SESSION['usuario_nome']) ?>
      <span class="badge-tipo <?= $_SESSION['usuario_tipo'] === 'administrador' ? 'admin' : $_SESSION['usuario_tipo'] ?>">
        <?= getTipoLabel($_SESSION['usuario_tipo']) ?>
      </span>
    </a>
    <a href="logout.php" class="btn btn-secondary btn-sm">Sair</a>
  </div>
</header>
<?php endif; ?>

<main class="main-content">

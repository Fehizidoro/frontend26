<?php
session_start();
if (isset($_SESSION['usuario_id'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EduGestão — Plataforma Escolar</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .hero {
      min-height: 100vh;
      background: var(--navy);
      display: flex; flex-direction: column;
      align-items: center; justify-content: center;
      text-align: center; padding: 2rem;
      position: relative; overflow: hidden;
    }
    .hero::before {
      content: '';
      position: absolute; inset: 0;
      background: radial-gradient(ellipse at 20% 50%, rgba(37,99,235,.35) 0%, transparent 55%),
                  radial-gradient(ellipse at 80% 30%, rgba(13,148,136,.25) 0%, transparent 50%),
                  radial-gradient(ellipse at 60% 90%, rgba(37,99,235,.2) 0%, transparent 45%);
    }
    .hero-content { position: relative; z-index: 1; max-width: 640px; }
    .hero-icon {
      width: 80px; height: 80px;
      background: rgba(255,255,255,.1);
      border: 2px solid rgba(255,255,255,.2);
      border-radius: 20px;
      display: flex; align-items: center; justify-content: center;
      font-size: 2.5rem; margin: 0 auto 1.5rem;
    }
    .hero h1 { color: white; font-size: clamp(2rem, 5vw, 3rem); margin-bottom: .75rem; }
    .hero p  { color: rgba(255,255,255,.65); font-size: 1.1rem; margin-bottom: 2.5rem; line-height: 1.7; }
    .hero-btns { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }
    .btn-white  { background: white; color: var(--navy); font-weight: 600; }
    .btn-white:hover { background: var(--gray-100); color: var(--navy); transform: translateY(-1px); box-shadow: 0 8px 24px rgba(0,0,0,.2); }
    .btn-outline-white {
      background: transparent; color: white;
      border: 1.5px solid rgba(255,255,255,.4);
    }
    .btn-outline-white:hover { background: rgba(255,255,255,.1); color: white; }
    .features-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 1rem; margin-top: 3rem;
    }
    .feature-pill {
      background: rgba(255,255,255,.06);
      border: 1px solid rgba(255,255,255,.1);
      border-radius: 12px;
      padding: 1.25rem;
      text-align: center;
      color: rgba(255,255,255,.8);
      font-size: .85rem;
    }
    .feature-pill .fi { font-size: 1.5rem; margin-bottom: .5rem; }
  </style>
</head>
<body>
<div class="hero">
  <div class="hero-content">
    <div class="hero-icon">🎓</div>
    <h1>EduGestão</h1>
    <p>Plataforma de gestão escolar que centraliza avisos, atividades e comunicação entre alunos, professores e administração.</p>

    <div class="hero-btns">
      <a href="login.php" class="btn btn-white btn-lg">→ Entrar no Sistema</a>
      <a href="cadastro.php" class="btn btn-outline-white btn-lg">Criar Conta</a>
    </div>

    <div class="features-grid">
      <div class="feature-pill">
        <div class="fi">📢</div>
        Mural de Avisos
      </div>
      <div class="feature-pill">
        <div class="fi">📚</div>
        Gestão de Atividades
      </div>
      <div class="feature-pill">
        <div class="fi">👥</div>
        Multi-usuário
      </div>
      <div class="feature-pill">
        <div class="fi">📅</div>
        Controle de Prazos
      </div>
    </div>
  </div>
</div>
</body>
</html>

<?php
session_start();
if (isset($_SESSION['usuario_id'])) {
    header('Location: dashboard.php');
    exit;
}

require_once 'includes/conexao.php';
require_once 'includes/auth.php';

$erro = '';
$email_value = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $email_value = sanitize($email);

    if (empty($email) || empty($senha)) {
        $erro = 'Preencha todos os campos.';
    } else {
        $stmt = $conn->prepare("SELECT id, nome, email, senha, tipo, foto FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $usuario = $result->fetch_assoc();
        $stmt->close();

        if ($usuario) {
            $ok = ($senha === $usuario['senha']) || password_verify($senha, $usuario['senha']);
            if ($ok) {
                $_SESSION['usuario_id']    = $usuario['id'];
                $_SESSION['usuario_nome']  = $usuario['nome'];
                $_SESSION['usuario_tipo']  = $usuario['tipo'];
                $_SESSION['usuario_email'] = $usuario['email'];
                $_SESSION['usuario_foto']  = $usuario['foto'] ?? '';
                header('Location: dashboard.php');
                exit;
            }
        }
        $erro = 'E-mail ou senha incorretos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login — EduGestão</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="auth-page">
  <div class="auth-box">
    <div class="auth-logo">
      <div class="logo-mark">🎓</div>
      <h1>EduGestão</h1>
      <p>Entre com sua conta para continuar</p>
    </div>

    <?php if ($erro): ?>
    <div class="alert alert-error">⚠ <?= $erro ?></div>
    <?php endif; ?>

    <?php if (isset($_GET['cadastro'])): ?>
    <div class="alert alert-success">✓ Conta criada! Faça login.</div>
    <?php endif; ?>

    <form method="POST" novalidate>
      <div class="form-group">
        <label class="form-label">E-mail <span class="req">*</span></label>
        <input type="email" name="email" class="form-control"
               placeholder="seu@email.com" value="<?= $email_value ?>" required autofocus>
      </div>
      <div class="form-group">
        <label class="form-label">Senha <span class="req">*</span></label>
        <input type="password" name="senha" class="form-control" placeholder="••••••" required>
      </div>
      <button type="submit" class="btn btn-primary btn-lg" style="width:100%; margin-top:.5rem;">
        Entrar no Sistema →
      </button>
    </form>

    <div class="auth-footer">
      Não tem conta? <a href="cadastro.php">Criar conta</a>
    </div>
  </div>
</div>
</body>
</html>

<?php
require_once 'includes/auth.php';
require_once 'includes/conexao.php';
requireLogin();

$pageTitle = 'Mensagens';
$cssPath = '';
$msg_ok = '';
$erro = '';
$meu_id = $_SESSION['usuario_id'];

// Verifica tabelas
$tbl = $conn->query("SHOW TABLES LIKE 'mensagens'");
if (!$tbl || $tbl->num_rows === 0) {
    echo '<div style="padding:2rem;"><div class="alert alert-error">⚠ Execute o SQL de criação da tabela <b>mensagens</b> no phpMyAdmin primeiro!</div></div>';
    include 'includes/footer.php'; exit;
}

// Enviar mensagem
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao']??'') === 'enviar') {
    $id_dest = (int)($_POST['id_destinatario'] ?? 0);
    $texto   = trim($_POST['mensagem'] ?? '');
    if (!$id_dest || empty($texto)) {
        $erro = 'Selecione um destinatário e escreva algo.';
    } elseif ($id_dest === $meu_id) {
        $erro = 'Você não pode enviar mensagem para si mesmo.';
    } else {
        $stmt = $conn->prepare("INSERT INTO mensagens (id_remetente, id_destinatario, mensagem) VALUES (?,?,?)");
        $stmt->bind_param("iis", $meu_id, $id_dest, $texto);
        $stmt->execute() ? ($msg_ok = 'Mensagem enviada!') : ($erro = 'Erro ao enviar.');
        $stmt->close();
    }
}

// Marcar como lida
$id_conv = isset($_GET['conv']) ? (int)$_GET['conv'] : 0;
if ($id_conv) {
    $stmt = $conn->prepare("UPDATE mensagens SET lida=1 WHERE id_destinatario=? AND id_remetente=?");
    $stmt->bind_param("ii", $meu_id, $id_conv);
    $stmt->execute(); $stmt->close();
}

// Lista conversas
$conversas = $conn->prepare("
    SELECT u.id, u.nome, u.tipo, u.foto,
        (SELECT m2.mensagem FROM mensagens m2 
         WHERE (m2.id_remetente=? AND m2.id_destinatario=u.id) 
            OR (m2.id_remetente=u.id AND m2.id_destinatario=?)
         ORDER BY m2.data_envio DESC LIMIT 1) as ultima_msg,
        (SELECT m3.data_envio FROM mensagens m3 
         WHERE (m3.id_remetente=? AND m3.id_destinatario=u.id) 
            OR (m3.id_remetente=u.id AND m3.id_destinatario=?)
         ORDER BY m3.data_envio DESC LIMIT 1) as ultima_data,
        (SELECT COUNT(*) FROM mensagens m4 
         WHERE m4.id_remetente=u.id AND m4.id_destinatario=? AND m4.lida=0) as nao_lidas
    FROM usuarios u WHERE u.id != ?
    HAVING ultima_msg IS NOT NULL
    ORDER BY ultima_data DESC
");
$conversas->bind_param("iiiiii", $meu_id,$meu_id,$meu_id,$meu_id,$meu_id,$meu_id);
$conversas->execute();
$lista_conv = $conversas->get_result();
$conversas->close();

// Todos usuários p/ nova conversa
$todos = $conn->prepare("SELECT id, nome, tipo, foto FROM usuarios WHERE id != ? ORDER BY tipo, nome");
$todos->bind_param("i", $meu_id);
$todos->execute();
$lista_todos = $todos->get_result();
$todos->close();

// Conversa aberta
$usuario_conv = null;
$msgs_conv = null;
if ($id_conv) {
    $stmt = $conn->prepare("SELECT id, nome, tipo, foto FROM usuarios WHERE id=?");
    $stmt->bind_param("i", $id_conv);
    $stmt->execute();
    $usuario_conv = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $stmt = $conn->prepare("
        SELECT m.*, u.nome as rem_nome, u.foto as rem_foto
        FROM mensagens m JOIN usuarios u ON m.id_remetente=u.id
        WHERE (m.id_remetente=? AND m.id_destinatario=?)
           OR (m.id_remetente=? AND m.id_destinatario=?)
        ORDER BY m.data_envio ASC
    ");
    $stmt->bind_param("iiii", $meu_id,$id_conv,$id_conv,$meu_id);
    $stmt->execute();
    $msgs_conv = $stmt->get_result();
    $stmt->close();
}

// Total não lidas
$nr = $conn->query("SELECT COUNT(*) as c FROM mensagens WHERE id_destinatario=$meu_id AND lida=0");
$total_nl = $nr ? $nr->fetch_assoc()['c'] : 0;

$icons = ['administrador'=>'👑','professor'=>'📖','aluno'=>'🎒'];

function avatarHtml($foto, $nome, $size=40) {
    $inicial = mb_strtoupper(mb_substr($nome, 0, 1));
    if (!empty($foto) && file_exists(__DIR__ . '/uploads/fotos/' . $foto)) {
        return "<img src='uploads/fotos/{$foto}' style='width:{$size}px;height:{$size}px;border-radius:50%;object-fit:cover;'>";
    }
    return "<div style='width:{$size}px;height:{$size}px;border-radius:50%;background:var(--primary);
            display:flex;align-items:center;justify-content:center;color:white;font-weight:700;
            font-size:" . ($size*0.35) . "px;flex-shrink:0;'>{$inicial}</div>";
}

include 'includes/header.php';
?>

<div class="page-header">
  <div><h2>💬 Mensagens</h2><p>Comunicação entre alunos, professores e administração</p></div>
</div>

<?php if ($erro): ?><div class="alert alert-error">⚠ <?= sanitize($erro) ?></div><?php endif; ?>
<?php if ($msg_ok): ?><div class="alert alert-success">✓ <?= sanitize($msg_ok) ?></div><?php endif; ?>

<div style="display:grid; grid-template-columns:320px 1fr; gap:1.5rem; height:calc(100vh - 230px); min-height:520px;">

  <!-- SIDEBAR -->
  <div style="display:flex; flex-direction:column; gap:1rem; overflow:hidden;">

    <!-- Nova mensagem -->
    <div class="card">
      <div class="card-header" style="cursor:pointer;" onclick="var d=document.getElementById('nova-form');d.style.display=d.style.display==='none'?'block':'none'">
        <h3 style="margin:0;font-size:.95rem;">✉️ Nova Mensagem</h3>
        <span style="color:var(--gray-400); font-size:1.2rem;">+</span>
      </div>
      <div id="nova-form" style="display:none;">
        <div class="card-body" style="padding:1rem;">
          <form method="POST">
            <input type="hidden" name="acao" value="enviar">
            <div class="form-group">
              <select name="id_destinatario" class="form-control" required>
                <option value="">— Selecione o destinatário —</option>
                <?php
                $lista_todos->data_seek(0);
                $tipo_atual = '';
                while($u = $lista_todos->fetch_assoc()) {
                    if ($u['tipo'] !== $tipo_atual) {
                        if ($tipo_atual) echo '</optgroup>';
                        echo '<optgroup label="' . ucfirst($u['tipo']) . 's">';
                        $tipo_atual = $u['tipo'];
                    }
                    echo '<option value="'.$u['id'].'">' . ($icons[$u['tipo']]??'') . ' ' . htmlspecialchars($u['nome']) . '</option>';
                }
                if ($tipo_atual) echo '</optgroup>';
                ?>
              </select>
            </div>
            <div class="form-group">
              <textarea name="mensagem" class="form-control" rows="3" placeholder="Escreva aqui..." required></textarea>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;">Enviar →</button>
          </form>
        </div>
      </div>
    </div>

    <!-- Conversas -->
    <div class="card" style="flex:1; overflow-y:auto;">
      <div class="card-header">
        <h3 style="margin:0;font-size:.95rem;">💬 Conversas</h3>
        <?php if ($total_nl > 0): ?>
        <span class="badge badge-red"><?= $total_nl ?></span>
        <?php endif; ?>
      </div>
      <?php if ($lista_conv->num_rows === 0): ?>
      <div style="padding:1.5rem;text-align:center;color:var(--gray-400);font-size:.875rem;">
        Nenhuma conversa ainda.<br>Clique em + para começar!
      </div>
      <?php else: while($conv = $lista_conv->fetch_assoc()): ?>
      <a href="mensagens.php?conv=<?= $conv['id'] ?>"
         style="display:flex;align-items:center;gap:.75rem;padding:.9rem 1rem;
                border-bottom:1px solid var(--gray-100);text-decoration:none;
                background:<?= $id_conv==$conv['id']?'var(--primary-bg)':'white' ?>;
                transition:background var(--transition);">
        <?= avatarHtml($conv['foto']??'', $conv['nome'], 40) ?>
        <div style="flex:1;min-width:0;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <span style="font-weight:<?= $conv['nao_lidas']>0?'700':'500' ?>;color:var(--navy);font-size:.875rem;">
              <?= sanitize($conv['nome']) ?>
            </span>
            <?php if ($conv['nao_lidas'] > 0): ?>
            <span class="badge badge-red"><?= $conv['nao_lidas'] ?></span>
            <?php else: ?>
            <span style="font-size:.7rem;color:var(--gray-400);"><?= date('d/m', strtotime($conv['ultima_data'])) ?></span>
            <?php endif; ?>
          </div>
          <div style="font-size:.75rem;color:var(--gray-400);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:.1rem;">
            <?= mb_strimwidth(sanitize($conv['ultima_msg']), 0, 38, '...') ?>
          </div>
        </div>
      </a>
      <?php endwhile; endif; ?>
    </div>
  </div>

  <!-- ÁREA CHAT -->
  <div class="card" style="display:flex;flex-direction:column;overflow:hidden;">
    <?php if ($usuario_conv): ?>
    <!-- Header -->
    <div style="padding:1rem 1.5rem;border-bottom:2px solid var(--gray-100);display:flex;align-items:center;gap:.75rem;background:white;">
      <?= avatarHtml($usuario_conv['foto']??'', $usuario_conv['nome'], 44) ?>
      <div>
        <div style="font-weight:600;color:var(--navy);"><?= sanitize($usuario_conv['nome']) ?></div>
        <div style="font-size:.75rem;color:var(--gray-400);"><?= $icons[$usuario_conv['tipo']]??'' ?> <?= getTipoLabel($usuario_conv['tipo']) ?></div>
      </div>
    </div>

    <!-- Mensagens -->
    <div id="chat" style="flex:1;overflow-y:auto;padding:1.25rem;display:flex;flex-direction:column;gap:.75rem;background:var(--gray-50);">
      <?php if ($msgs_conv->num_rows === 0): ?>
      <div style="text-align:center;color:var(--gray-400);margin:auto;font-size:.875rem;">
        Nenhuma mensagem ainda. Diga olá! 👋
      </div>
      <?php else: while($msg = $msgs_conv->fetch_assoc()):
        $minha = ($msg['id_remetente'] == $meu_id);
      ?>
      <div style="display:flex;flex-direction:column;align-items:<?= $minha?'flex-end':'flex-start' ?>;">
        <?php if (!$minha): ?>
        <div style="display:flex;align-items:center;gap:.4rem;margin-bottom:.25rem;">
          <?= avatarHtml($msg['rem_foto']??'', $msg['rem_nome'], 22) ?>
          <span style="font-size:.72rem;color:var(--gray-400);"><?= sanitize($msg['rem_nome']) ?></span>
        </div>
        <?php endif; ?>
        <div style="
          max-width:70%;padding:.65rem 1rem;
          border-radius:<?= $minha?'16px 16px 4px 16px':'16px 16px 16px 4px' ?>;
          background:<?= $minha?'var(--primary)':'white' ?>;
          color:<?= $minha?'white':'var(--gray-800)' ?>;
          box-shadow:var(--shadow-sm);font-size:.9rem;line-height:1.5;
        ">
          <?= nl2br(sanitize($msg['mensagem'])) ?>
        </div>
        <div style="font-size:.7rem;color:var(--gray-400);margin-top:.2rem;padding:0 .25rem;">
          <?= date('d/m H:i', strtotime($msg['data_envio'])) ?>
          <?= $minha && $msg['lida'] ? ' · ✓ lida' : '' ?>
        </div>
      </div>
      <?php endwhile; endif; ?>
    </div>

    <!-- Input -->
    <div style="padding:1rem;border-top:1px solid var(--gray-200);background:white;">
      <form method="POST" style="display:flex;gap:.75rem;align-items:flex-end;">
        <input type="hidden" name="acao" value="enviar">
        <input type="hidden" name="id_destinatario" value="<?= $usuario_conv['id'] ?>">
        <textarea name="mensagem" class="form-control" rows="2"
                  placeholder="Escreva uma mensagem... (Enter para enviar)"
                  style="flex:1;resize:none;"
                  onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();this.form.submit();}"
                  required></textarea>
        <button type="submit" class="btn btn-primary" style="height:52px;padding:0 1.25rem;">➤</button>
      </form>
    </div>

    <?php else: ?>
    <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:var(--gray-400);">
      <div style="font-size:4rem;margin-bottom:1rem;">💬</div>
      <h3 style="color:var(--gray-600);">Selecione uma conversa</h3>
      <p style="font-size:.875rem;">ou clique em + para nova mensagem</p>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
const chat = document.getElementById('chat');
if (chat) chat.scrollTop = chat.scrollHeight;
</script>

<?php include 'includes/footer.php'; ?>

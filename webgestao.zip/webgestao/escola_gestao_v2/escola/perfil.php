<?php
require_once 'includes/auth.php';
require_once 'includes/conexao.php';
requireLogin();

$pageTitle = 'Meu Perfil';
$cssPath = '';
$mensagem = '';
$tipo_msg = '';
$meu_id = $_SESSION['usuario_id'];

// Busca dados atuais
$stmt = $conn->prepare("SELECT * FROM usuarios WHERE id=?");
$stmt->bind_param("i", $meu_id);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    // Upload de foto
    if ($acao === 'foto' && isset($_FILES['foto']) && $_FILES['foto']['error'] === 0) {
        $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
            $mensagem = 'Apenas imagens são permitidas (jpg, png, gif).'; $tipo_msg = 'error';
        } elseif ($_FILES['foto']['size'] > 5 * 1024 * 1024) {
            $mensagem = 'Imagem muito grande (máx 5MB).'; $tipo_msg = 'error';
        } else {
            if (!is_dir(__DIR__ . '/uploads/fotos')) mkdir(__DIR__ . '/uploads/fotos', 0755, true);
            // Remove foto antiga
            if (!empty($usuario['foto']) && file_exists(__DIR__ . '/uploads/fotos/' . $usuario['foto'])) {
                unlink(__DIR__ . '/uploads/fotos/' . $usuario['foto']);
            }
            $novo = 'user_' . $meu_id . '_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['foto']['tmp_name'], __DIR__ . '/uploads/fotos/' . $novo)) {
                $stmt = $conn->prepare("UPDATE usuarios SET foto=? WHERE id=?");
                $stmt->bind_param("si", $novo, $meu_id);
                $stmt->execute(); $stmt->close();
                $_SESSION['usuario_foto'] = $novo;
                $usuario['foto'] = $novo;
                $mensagem = 'Foto atualizada!'; $tipo_msg = 'success';
            } else {
                $mensagem = 'Erro ao salvar foto.'; $tipo_msg = 'error';
            }
        }
    }

    // Atualizar dados
    if ($acao === 'dados') {
        $nome  = trim($_POST['nome'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $senha_atual = $_POST['senha_atual'] ?? '';
        $nova_senha  = $_POST['nova_senha'] ?? '';

        if (empty($nome) || empty($email)) {
            $mensagem = 'Nome e e-mail são obrigatórios.'; $tipo_msg = 'error';
        } else {
            // Verifica email duplicado
            $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email=? AND id!=?");
            $stmt->bind_param("si", $email, $meu_id);
            $stmt->execute(); $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $mensagem = 'E-mail já em uso.'; $tipo_msg = 'error';
                $stmt->close();
            } else {
                $stmt->close();
                if (!empty($nova_senha)) {
                    // Verifica senha atual
                    if ($senha_atual !== $usuario['senha'] && !password_verify($senha_atual, $usuario['senha'])) {
                        $mensagem = 'Senha atual incorreta.'; $tipo_msg = 'error';
                    } else {
                        $stmt = $conn->prepare("UPDATE usuarios SET nome=?, email=?, senha=? WHERE id=?");
                        $stmt->bind_param("sssi", $nome, $email, $nova_senha, $meu_id);
                        $stmt->execute(); $stmt->close();
                        $_SESSION['usuario_nome']  = $nome;
                        $_SESSION['usuario_email'] = $email;
                        $mensagem = 'Dados e senha atualizados!'; $tipo_msg = 'success';
                        $usuario['nome'] = $nome; $usuario['email'] = $email;
                    }
                } else {
                    $stmt = $conn->prepare("UPDATE usuarios SET nome=?, email=? WHERE id=?");
                    $stmt->bind_param("ssi", $nome, $email, $meu_id);
                    $stmt->execute(); $stmt->close();
                    $_SESSION['usuario_nome']  = $nome;
                    $_SESSION['usuario_email'] = $email;
                    $mensagem = 'Dados atualizados!'; $tipo_msg = 'success';
                    $usuario['nome'] = $nome; $usuario['email'] = $email;
                }
            }
        }
    }
}

function getFotoUrl($foto) {
    if (!empty($foto) && file_exists(__DIR__ . '/uploads/fotos/' . $foto)) {
        return 'uploads/fotos/' . $foto;
    }
    return null;
}

include 'includes/header.php';
?>

<div class="page-header">
  <div><h2>👤 Meu Perfil</h2><p>Gerencie suas informações e foto</p></div>
</div>

<?php if ($mensagem): ?>
<div class="alert alert-<?= $tipo_msg==='success'?'success':'error' ?>">
  <?= $tipo_msg==='success'?'✓':'⚠' ?> <?= sanitize($mensagem) ?>
</div>
<?php endif; ?>

<div style="display:grid; grid-template-columns:280px 1fr; gap:1.5rem;">

  <!-- Foto de perfil -->
  <div class="card" style="text-align:center;">
    <div class="card-body">
      <?php $fotoUrl = getFotoUrl($usuario['foto'] ?? ''); ?>
      <div style="width:120px; height:120px; border-radius:50%; margin:0 auto 1rem;
                  background:var(--primary); overflow:hidden; border:4px solid var(--primary-bg);
                  display:flex; align-items:center; justify-content:center;">
        <?php if ($fotoUrl): ?>
        <img src="<?= $fotoUrl ?>" alt="Foto" style="width:100%; height:100%; object-fit:cover;">
        <?php else: ?>
        <span style="font-size:2.5rem; color:white; font-weight:700;">
          <?= mb_strtoupper(mb_substr($usuario['nome'], 0, 1)) ?>
        </span>
        <?php endif; ?>
      </div>

      <div style="font-family:'Instrument Serif',serif; font-size:1.2rem; color:var(--navy); margin-bottom:.25rem;">
        <?= sanitize($usuario['nome']) ?>
      </div>
      <div style="margin-bottom:1.5rem;">
        <?php $bm = ['administrador'=>'amber','professor'=>'teal','aluno'=>'blue']; ?>
        <span class="badge badge-<?= $bm[$usuario['tipo']]??'blue' ?>"><?= getTipoLabel($usuario['tipo']) ?></span>
      </div>

      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="acao" value="foto">
        <label style="display:block; cursor:pointer;">
          <div class="btn btn-secondary" style="width:100%; margin-bottom:.5rem;">📷 Escolher Foto</div>
          <input type="file" name="foto" accept="image/*" style="display:none;"
                 onchange="this.form.submit()">
        </label>
      </form>

      <?php if ($fotoUrl): ?>
      <div style="font-size:.75rem; color:var(--gray-400);">Clique para trocar a foto</div>
      <?php else: ?>
      <div style="font-size:.75rem; color:var(--gray-400);">JPG, PNG ou GIF · máx 5MB</div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Dados do perfil -->
  <div class="card">
    <div class="card-header"><h3 style="margin:0;">✏️ Editar Informações</h3></div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="acao" value="dados">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Nome completo <span class="req">*</span></label>
            <input type="text" name="nome" class="form-control"
                   value="<?= sanitize($usuario['nome']) ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">E-mail <span class="req">*</span></label>
            <input type="email" name="email" class="form-control"
                   value="<?= sanitize($usuario['email']) ?>" required>
          </div>
        </div>

        <hr style="border:none; border-top:1px solid var(--gray-200); margin:1rem 0;">
        <p style="font-size:.85rem; color:var(--gray-600); margin-bottom:1rem;">
          Deixe em branco para não alterar a senha.
        </p>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Senha atual</label>
            <input type="password" name="senha_atual" class="form-control" placeholder="Senha atual">
          </div>
          <div class="form-group">
            <label class="form-label">Nova senha</label>
            <input type="password" name="nova_senha" class="form-control" placeholder="Nova senha">
          </div>
        </div>

        <button type="submit" class="btn btn-primary">💾 Salvar Alterações</button>
      </form>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>

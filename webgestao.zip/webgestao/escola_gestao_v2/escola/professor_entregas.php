<?php
require_once 'includes/auth.php';
require_once 'includes/conexao.php';
requireLogin();
requireTipo(['professor','administrador']);

$pageTitle = 'Entregas dos Alunos';
$cssPath = '';

$id_prof = $_SESSION['usuario_id'];

// Busca atividades do professor com suas entregas
$sql = "SELECT a.*, 
        (SELECT COUNT(*) FROM entregas e WHERE e.id_atividade = a.id) as total_entregas
        FROM atividades a 
        WHERE a.criado_por = ?
        ORDER BY a.prazo ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_prof);
$stmt->execute();
$atividades = $stmt->get_result();
$stmt->close();

include 'includes/header.php';
?>

<div class="page-header">
  <div>
    <h2>📬 Entregas dos Alunos</h2>
    <p>Arquivos enviados pelos alunos nas suas atividades</p>
  </div>
  <a href="atividades.php" class="btn btn-secondary">← Voltar</a>
</div>

<?php if (!$atividades || $atividades->num_rows === 0): ?>
<div class="empty-state">
  <div class="empty-icon">📭</div>
  <h3>Nenhuma atividade cadastrada</h3>
  <p>Crie atividades para que os alunos possam enviar arquivos.</p>
</div>
<?php else: ?>
<div class="item-list">
  <?php while($atv = $atividades->fetch_assoc()): ?>
  <div class="item-card teal">
    <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:.5rem;">
      <div>
        <div class="item-title"><?= sanitize($atv['titulo']) ?></div>
        <div class="item-meta">
          <span>🏫 <?= sanitize($atv['turma']) ?></span>
          <span>📅 Prazo: <?= date('d/m/Y', strtotime($atv['prazo'])) ?></span>
        </div>
      </div>
      <span class="badge <?= $atv['total_entregas'] > 0 ? 'badge-green' : 'badge-amber' ?>" style="font-size:.85rem; padding:.3rem .8rem;">
        <?= $atv['total_entregas'] ?> entrega(s)
      </span>
    </div>

    <?php
    // Busca entregas desta atividade
    $stmt2 = $conn->prepare("SELECT e.*, u.nome as aluno_nome, u.email as aluno_email 
                              FROM entregas e 
                              JOIN usuarios u ON e.id_aluno = u.id 
                              WHERE e.id_atividade = ? 
                              ORDER BY e.data_envio DESC");
    $stmt2->bind_param("i", $atv['id']);
    $stmt2->execute();
    $entregas = $stmt2->get_result();
    $stmt2->close();
    ?>

    <?php if ($entregas->num_rows === 0): ?>
    <div style="margin-top:1rem; padding:.75rem; background:var(--gray-50); border-radius:8px; font-size:.875rem; color:var(--gray-400); text-align:center;">
      Nenhum aluno enviou esta atividade ainda.
    </div>
    <?php else: ?>
    <div style="margin-top:1rem;">
      <table style="width:100%; border-collapse:collapse;">
        <thead>
          <tr style="background:var(--gray-50);">
            <th style="padding:.6rem 1rem; font-size:.75rem; text-align:left; color:var(--gray-600); border-bottom:2px solid var(--gray-200);">Aluno</th>
            <th style="padding:.6rem 1rem; font-size:.75rem; text-align:left; color:var(--gray-600); border-bottom:2px solid var(--gray-200);">E-mail</th>
            <th style="padding:.6rem 1rem; font-size:.75rem; text-align:left; color:var(--gray-600); border-bottom:2px solid var(--gray-200);">Enviado em</th>
            <th style="padding:.6rem 1rem; font-size:.75rem; text-align:left; color:var(--gray-600); border-bottom:2px solid var(--gray-200);">Arquivo</th>
          </tr>
        </thead>
        <tbody>
          <?php while($ent = $entregas->fetch_assoc()): ?>
          <tr style="border-bottom:1px solid var(--gray-100);">
            <td style="padding:.75rem 1rem; font-weight:500;">🎒 <?= sanitize($ent['aluno_nome']) ?></td>
            <td style="padding:.75rem 1rem; font-size:.85rem; color:var(--gray-600);"><?= sanitize($ent['aluno_email']) ?></td>
            <td style="padding:.75rem 1rem; font-size:.85rem; color:var(--gray-400);"><?= date('d/m/Y H:i', strtotime($ent['data_envio'])) ?></td>
            <td style="padding:.75rem 1rem;">
              <a href="uploads/<?= sanitize($ent['arquivo']) ?>" target="_blank" class="btn btn-success btn-sm">⬇ Baixar</a>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
  <?php endwhile; ?>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>

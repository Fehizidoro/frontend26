-- ============================================
-- Banco de Dados: Plataforma Gestão Escolar
-- ============================================

CREATE DATABASE IF NOT EXISTS escola_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE escola_db;

-- Tabela de Usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('aluno', 'professor', 'administrador') NOT NULL DEFAULT 'aluno',
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabela de Avisos
CREATE TABLE IF NOT EXISTS avisos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT NOT NULL,
    data_publicacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    id_usuario INT NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Tabela de Atividades
CREATE TABLE IF NOT EXISTS atividades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT NOT NULL,
    prazo DATE NOT NULL,
    turma VARCHAR(50) NOT NULL,
    id_professor INT NOT NULL,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_professor) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- Dados de Exemplo (Seeds)
-- ============================================

-- Senha padrão para todos: "senha123" (hash bcrypt)
INSERT INTO usuarios (nome, email, senha, tipo) VALUES
('Admin Escolar', 'admin@escola.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'administrador'),
('Prof. Ana Lima', 'ana@escola.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'professor'),
('João Silva', 'joao@escola.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'aluno');

-- Avisos de exemplo
INSERT INTO avisos (titulo, descricao, id_usuario) VALUES
('Reunião de Pais e Mestres', 'Informamos que a reunião de pais e mestres será realizada no dia 20/03/2025, às 19h, no auditório da escola. A presença é fundamental!', 1),
('Semana Cultural 2025', 'A Semana Cultural deste ano acontecerá entre os dias 24 e 28 de março. Haverá apresentações de teatro, música e exposições artísticas. Participação aberta a todos os alunos.', 1),
('Recesso de Páscoa', 'Lembramos que nos dias 17 e 18 de abril não haverá aulas em virtude do feriado de Páscoa. As aulas retornam normalmente na segunda-feira, dia 21.', 1);

-- Atividades de exemplo
INSERT INTO atividades (titulo, descricao, prazo, turma, id_professor) VALUES
('Redação: Meio Ambiente', 'Escreva uma redação dissertativo-argumentativa sobre os impactos das mudanças climáticas no cotidiano das pessoas. Mínimo de 25 linhas.', '2025-03-25', '3º A', 2),
('Lista de Exercícios - Equações', 'Resolver os exercícios 1 ao 20 da lista distribuída em sala sobre equações do 2º grau. Entregar no caderno.', '2025-03-20', '2º B', 2),
('Trabalho em Grupo - História', 'Pesquisar e apresentar em grupo (4 alunos) sobre a Segunda Guerra Mundial. Apresentação de 15 minutos com slides.', '2025-04-05', '3º A', 2);

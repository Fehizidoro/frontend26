<?php
require_once 'includes/auth.php';
require_once 'includes/conexao.php';
requireLogin();
requireTipo('administrador');

$pageTitle = 'Usuários';
$cssPath = '';
$mensagem = '';
$tipo_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'alterar_tipo') {
        $id   = (int)($_POST['id'] ?? 0);
        $tipo = $_POST['tipo'] ?? '';
        if ($id && in_array($tipo, ['aluno','professor','administrador']) && $id !== (int)$_SESSION['usuario_id']) {
            $stmt = $conn->prepare("UPDATE usuarios SET tipo=? WHERE id=?");
            $stmt->bind_param("si", $tipo, $id);
            if ($stmt->execute()) { $mensagem = 'Tipo atualizado!'; $tipo_msg = 'success'; }
            $stmt->close();
        } else {
            $mensagem = 'Não é possível alterar o próprio tipo.'; $tipo_msg = 'error';
        }
    }

    if ($acao === 'excluir') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id && $id !== (int)$_SESSION['usuario_id']) {
            $stmt = $conn->prepare("DELETE FROM usuarios WHERE id=?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) { $mensagem = 'Usuário removido.'; $tipo_msg = 'success'; }
            $stmt->close();
        } else {
            $mensagem = 'Não pode remover sua própria conta.'; $tipo_msg = 'error';
        }
    }
}

$usuarios = $conn->query("SELECT * FROM usuarios ORDER BY tipo, nome");
$icons = ['administrador' => '👑', 'professor' => '📖', 'aluno' => '🎒'];

include 'includes/header.php';
?>

<div class="page-header">
  <div>
    <h2>👥 Gerenciar Usuários</h2>
    <p>Visualize e gerencie as contas do sistema</p>
  </div>
  <a href="cadastro.php" class="btn btn-primary">+ Novo Usuário</a>
</div>

<?php if (isset($_GET['cadastro'])): ?>
<div class="alert alert-success">✓ Novo usuário cadastrado com sucesso!</div>
<?php endif; ?>

<?php if ($mensagem): ?>
<div class="alert alert-<?= $tipo_msg === 'success' ? 'success' : 'error' ?>">
  <?= $tipo_msg === 'success' ? '✓' : '⚠' ?> <?= sanitize($mensagem) ?>
</div>
<?php endif; ?>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th><th>Nome</th><th>E-mail</th><th>Tipo</th><th>Cadastro</th><th>Ações</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($usuarios->num_rows === 0): ?>
        <tr><td colspan="6" style="text-align:center; color:var(--gray-400); padding:2rem;">Nenhum usuário.</td></tr>
        <?php else: while($u = $usuarios->fetch_assoc()): ?>
        <tr>
          <td style="color:var(--gray-400);"><?= $u['id'] ?></td>
          <td>
            <div style="display:flex; align-items:center; gap:.5rem;">
              <?= $icons[$u['tipo']] ?? '👤' ?>
              <strong><?= sanitize($u['nome']) ?></strong>
              <?php if ($u['id'] == $_SESSION['usuario_id']): ?>
              <span class="badge badge-blue">Você</span>
              <?php endif; ?>
            </div>
          </td>
          <td style="color:var(--gray-600);"><?= sanitize($u['email']) ?></td>
          <td>
            <?php $bm = ['administrador'=>'amber','professor'=>'teal','aluno'=>'blue']; ?>
            <span class="badge badge-<?= $bm[$u['tipo']] ?? 'blue' ?>"><?= getTipoLabel($u['tipo']) ?></span>
          </td>
          <td style="font-size:.8rem; color:var(--gray-400);"><?= date('d/m/Y', strtotime($u['criado_em'])) ?></td>
          <td>
            <?php if ($u['id'] != $_SESSION['usuario_id']): ?>
            <div style="display:flex; gap:.4rem; align-items:center;">
              <form method="POST" style="display:flex; gap:.4rem; align-items:center;">
                <input type="hidden" name="acao" value="alterar_tipo">
                <input type="hidden" name="id" value="<?= $u['id'] ?>">
                <select name="tipo" class="form-control" style="padding:.3rem .6rem; font-size:.8rem; width:auto;">
                  <option value="aluno"         <?= $u['tipo']==='aluno'?'selected':'' ?>>Aluno</option>
                  <option value="professor"     <?= $u['tipo']==='professor'?'selected':'' ?>>Professor</option>
                  <option value="administrador" <?= $u['tipo']==='administrador'?'selected':'' ?>>Admin</option>
                </select>
                <button type="submit" class="btn btn-success btn-sm">✓</button>
              </form>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Excluir este usuário?')">
                <input type="hidden" name="acao" value="excluir">
                <input type="hidden" name="id" value="<?= $u['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm">🗑</button>
              </form>
            </div>
            <?php else: ?>
            <span style="font-size:.8rem; color:var(--gray-400);">—</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endwhile; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
